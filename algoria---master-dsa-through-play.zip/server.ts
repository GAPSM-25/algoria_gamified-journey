import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { MongoClient, Db, Collection } from 'mongodb';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// MongoDB Atlas State
let mongoClient: MongoClient | null = null;
let db: Db | null = null;
let usersCollection: Collection | null = null;
let dbStatus = {
  connected: false,
  status: 'initializing',
  message: 'Connecting to MongoDB Atlas...',
  cluster: 'cluster0.lpoe18o.mongodb.net',
  database: 'algoria'
};

// Default real user 'pallavi'
const defaultPallaviUser = {
  username: 'pallavi',
  password: 'password123',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  progress: {
    characterId: 'bit_byte',
    xp: 0,
    coins: 50,
    streak: 1,
    lastLoginDate: new Date().toISOString(),
    algoriaDust: 150,
    hasClaimedDailyStreakToday: false,
    completedLevels: {},
    unlockedWorlds: ['loop_forest'],
    badges: ['code_initiate']
  }
};

// In-memory fallback cache seeded with only real user 'pallavi'
const inMemoryUsers: Record<string, any> = {
  pallavi: { ...defaultPallaviUser }
};

async function initMongo() {
  const uri = process.env.MONGODB_URI || 'mongodb+srv://pallaviligade05_db_user:<db_password>@cluster0.lpoe18o.mongodb.net/algoria?retryWrites=true&w=majority';

  if (!uri || uri.includes('<db_password>')) {
    dbStatus = {
      connected: false,
      status: 'pending_password',
      message: 'MongoDB URI is configured with <db_password> placeholder. Provide your database user password in .env to activate live MongoDB Atlas connection.',
      cluster: 'cluster0.lpoe18o.mongodb.net',
      database: 'algoria'
    };
    console.log(`[MongoDB Atlas] Notice: ${dbStatus.message}`);
    return;
  }

  try {
    console.log('[MongoDB Atlas] Connecting to cluster0...');
    mongoClient = new MongoClient(uri, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 10000
    });

    await mongoClient.connect();
    db = mongoClient.db('algoria');
    usersCollection = db.collection('users');

    // Create unique index on username
    await usersCollection.createIndex({ username: 1 }, { unique: true });

    // Purge any fake or generated guest accounts from MongoDB Atlas
    await usersCollection.deleteMany({
      username: { $regex: /^player_|^guest_|^test_|^fake_/i }
    });

    // Ensure real user 'pallavi' exists in MongoDB Atlas
    const existingPallavi = await usersCollection.findOne({ username: 'pallavi' });
    if (!existingPallavi) {
      await usersCollection.insertOne({ ...defaultPallaviUser });
      console.log('[MongoDB Atlas] Seeded real user: pallavi');
    }

    dbStatus = {
      connected: true,
      status: 'connected',
      message: 'Successfully connected to MongoDB Atlas (cluster0.lpoe18o.mongodb.net / database: algoria)! Only real user pallavi and registered explorers active.',
      cluster: 'cluster0.lpoe18o.mongodb.net',
      database: 'algoria'
    };
    console.log(`[MongoDB Atlas] ${dbStatus.message}`);
  } catch (err: any) {
    dbStatus = {
      connected: false,
      status: 'error',
      message: `Failed to connect to MongoDB Atlas: ${err?.message || err}. Running with resilient fallback.`,
      cluster: 'cluster0.lpoe18o.mongodb.net',
      database: 'algoria'
    };
    console.warn(`[MongoDB Atlas] ${dbStatus.message}`);
  }
}

// -------------------------------------------------------------
// REST API Routes
// -------------------------------------------------------------

// DB Connection Status Check
app.get('/api/db/status', (req, res) => {
  res.json({
    ...dbStatus,
    timestamp: new Date().toISOString()
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', dbConnected: dbStatus.connected });
});

// Signup Route
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { username, password, characterId = 'bit_byte' } = req.body;
    const cleanName = (username || '').trim().toLowerCase();

    if (!cleanName || cleanName.length < 2) {
      return res.status(400).json({ error: 'Username must be at least 2 characters.' });
    }
    if (!password || password.length < 4) {
      return res.status(400).json({ error: 'Password must be at least 4 characters.' });
    }

    const defaultProgress = {
      characterId,
      xp: 0,
      coins: 0,
      streak: 1,
      lastLoginDate: new Date().toISOString(),
      algoriaDust: 10,
      hasClaimedDailyStreakToday: false,
      completedLevels: {},
      badges: ['code_initiate']
    };

    const newUser = {
      username: cleanName,
      password,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      progress: defaultProgress
    };

    if (usersCollection && dbStatus.connected) {
      const existing = await usersCollection.findOne({ username: cleanName });
      if (existing) {
        return res.status(409).json({ error: 'Username already exists. Please choose another or login.' });
      }
      await usersCollection.insertOne(newUser);
    } else {
      if (inMemoryUsers[cleanName]) {
        return res.status(409).json({ error: 'Username already exists.' });
      }
      inMemoryUsers[cleanName] = newUser;
    }

    res.json({
      success: true,
      user: {
        username: cleanName,
        createdAt: newUser.createdAt,
        progress: newUser.progress
      }
    });
  } catch (err: any) {
    console.error('Signup error:', err);
    res.status(500).json({ error: err?.message || 'Failed to sign up.' });
  }
});

// Login Route
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const cleanName = (username || '').trim().toLowerCase();

    let user: any = null;

    if (usersCollection && dbStatus.connected) {
      user = await usersCollection.findOne({ username: cleanName });
    } else {
      user = inMemoryUsers[cleanName];
    }

    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    // Update streak check on login
    const today = new Date().toISOString().split('T')[0];
    const lastLogin = user.progress?.lastLoginDate ? user.progress.lastLoginDate.split('T')[0] : '';

    if (lastLogin !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      const streak = lastLogin === yesterday ? (user.progress?.streak || 1) + 1 : 1;

      user.progress = {
        ...user.progress,
        streak,
        lastLoginDate: new Date().toISOString(),
        hasClaimedDailyStreakToday: false
      };

      if (usersCollection && dbStatus.connected) {
        await usersCollection.updateOne({ username: cleanName }, { $set: { progress: user.progress } });
      }
    }

    res.json({
      success: true,
      user: {
        username: user.username,
        createdAt: user.createdAt,
        progress: user.progress
      }
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: err?.message || 'Failed to login.' });
  }
});

// Get User by Username
app.get('/api/users/:username', async (req, res) => {
  try {
    const cleanName = req.params.username.trim().toLowerCase();
    let user: any = null;

    if (usersCollection && dbStatus.connected) {
      user = await usersCollection.findOne({ username: cleanName });
    } else {
      user = inMemoryUsers[cleanName];
    }

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    res.json({
      username: user.username,
      createdAt: user.createdAt,
      progress: user.progress
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to fetch user.' });
  }
});

// Update Progress
app.put('/api/users/:username/progress', async (req, res) => {
  try {
    const cleanName = req.params.username.trim().toLowerCase();
    const progressUpdates = req.body.progress || req.body;

    let user: any = null;

    if (usersCollection && dbStatus.connected) {
      user = await usersCollection.findOne({ username: cleanName });
      if (!user) return res.status(404).json({ error: 'User not found.' });

      const updatedProgress = { ...user.progress, ...progressUpdates };
      await usersCollection.updateOne(
        { username: cleanName },
        { $set: { progress: updatedProgress, updatedAt: new Date().toISOString() } }
      );
      res.json({ success: true, progress: updatedProgress });
    } else {
      user = inMemoryUsers[cleanName];
      if (!user) return res.status(404).json({ error: 'User not found.' });

      user.progress = { ...user.progress, ...progressUpdates };
      res.json({ success: true, progress: user.progress });
    }
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to update progress.' });
  }
});

// Record Level Completion
app.post('/api/levels/complete', async (req, res) => {
  try {
    const { username, worldId, levelId, stars, xpGained, coinsGained, stats } = req.body;
    const cleanName = (username || '').trim().toLowerCase();

    let user: any = null;
    if (usersCollection && dbStatus.connected) {
      user = await usersCollection.findOne({ username: cleanName });
    } else {
      user = inMemoryUsers[cleanName];
    }

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const progress = user.progress || {};
    const completedLevels = progress.completedLevels || {};
    const levelKey = `${worldId}_${levelId}`;
    const previous = completedLevels[levelKey];

    const bestStars = previous ? Math.max(previous.stars, stars) : stars;

    completedLevels[levelKey] = {
      stars: bestStars,
      firstCompleted: previous ? previous.firstCompleted : new Date().toISOString(),
      lastCompleted: new Date().toISOString(),
      stats: stats || {}
    };

    progress.completedLevels = completedLevels;
    progress.xp = (progress.xp || 0) + (xpGained || 0);
    progress.coins = (progress.coins || 0) + (coinsGained || 0);

    // Award badges
    const badges: string[] = progress.badges || ['code_initiate'];
    let newlyAwardedBadge: string | null = null;

    if (worldId === 'loop_forest' && [1, 2, 3, 4, 5].every((l) => completedLevels[`loop_forest_${l}`]?.stars > 0)) {
      if (!badges.includes('loop_master')) {
        badges.push('loop_master');
        newlyAwardedBadge = 'loop_master';
      }
    }
    if (worldId === 'stack_volcano' && [1, 2, 3, 4, 5].every((l) => completedLevels[`stack_volcano_${l}`]?.stars > 0)) {
      if (!badges.includes('stack_climber')) {
        badges.push('stack_climber');
        newlyAwardedBadge = 'stack_climber';
      }
    }
    if (worldId === 'queue_river' && [1, 2, 3, 4, 5].every((l) => completedLevels[`queue_river_${l}`]?.stars > 0)) {
      if (!badges.includes('queue_captain')) {
        badges.push('queue_captain');
        newlyAwardedBadge = 'queue_captain';
      }
    }
    if (worldId === 'tree_valley' && [1, 2, 3, 4, 5].every((l) => completedLevels[`tree_valley_${l}`]?.stars > 0)) {
      if (!badges.includes('tree_whisperer')) {
        badges.push('tree_whisperer');
        newlyAwardedBadge = 'tree_whisperer';
      }
    }
    if (worldId === 'graph_city' && [1, 2, 3, 4, 5].every((l) => completedLevels[`graph_city_${l}`]?.stars > 0)) {
      if (!badges.includes('graph_navigator')) {
        badges.push('graph_navigator');
        newlyAwardedBadge = 'graph_navigator';
      }
    }
    if (worldId === 'array_arena' && [1, 2, 3, 4, 5].every((l) => completedLevels[`array_arena_${l}`]?.stars > 0)) {
      if (!badges.includes('array_gladiator')) {
        badges.push('array_gladiator');
        newlyAwardedBadge = 'array_gladiator';
      }
    }
    progress.badges = badges;

    if (usersCollection && dbStatus.connected) {
      await usersCollection.updateOne(
        { username: cleanName },
        { $set: { progress, updatedAt: new Date().toISOString() } }
      );
    } else {
      user.progress = progress;
    }

    res.json({
      success: true,
      progress,
      newlyAwardedBadge
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to record completion.' });
  }
});

// Leaderboard Route (Sorted by XP & Stars from MongoDB Atlas - Real Users Only)
app.get('/api/leaderboard', async (req, res) => {
  try {
    let topUsers: any[] = [];

    if (usersCollection && dbStatus.connected) {
      topUsers = await usersCollection
        .find(
          { username: { $not: { $regex: /^player_|^guest_|^test_|^fake_/i } } },
          { projection: { username: 1, 'progress.characterId': 1, 'progress.xp': 1, 'progress.completedLevels': 1, 'progress.badges': 1 } }
        )
        .sort({ 'progress.xp': -1 })
        .limit(50)
        .toArray();
    } else {
      topUsers = Object.values(inMemoryUsers)
        .filter((u: any) => !u.username.match(/^player_|^guest_|^test_|^fake_/i))
        .sort((a, b) => (b.progress?.xp || 0) - (a.progress?.xp || 0))
        .slice(0, 50);
    }

    const leaderboard = topUsers.map((u, idx) => {
      const comp = u.progress?.completedLevels || {};
      const totalStars = Object.values(comp).reduce((acc: number, item: any) => acc + (item?.stars || 0), 0);
      return {
        rank: idx + 1,
        username: u.username,
        characterId: u.progress?.characterId || 'bit_byte',
        xp: u.progress?.xp || 0,
        stars: totalStars,
        badgesCount: u.progress?.badges?.length || 1
      };
    });

    res.json({ leaderboard, dbConnected: dbStatus.connected });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to fetch leaderboard.' });
  }
});

// Purge Fake Users API Route
app.post('/api/admin/purge-fake-users', async (req, res) => {
  try {
    let deletedMongoCount = 0;

    // Purge in-memory fake users
    Object.keys(inMemoryUsers).forEach((uname) => {
      if (uname !== 'pallavi' && uname.match(/^player_|^guest_|^test_|^fake_/i)) {
        delete inMemoryUsers[uname];
      }
    });

    if (usersCollection && dbStatus.connected) {
      const result = await usersCollection.deleteMany({
        $and: [
          { username: { $ne: 'pallavi' } },
          { username: { $regex: /^player_|^guest_|^test_|^fake_/i } }
        ]
      });
      deletedMongoCount = result.deletedCount;
    }

    res.json({
      success: true,
      deletedMongoCount,
      activeUsers: usersCollection && dbStatus.connected
        ? (await usersCollection.find({}, { projection: { username: 1 } }).toArray()).map((u) => u.username)
        : Object.keys(inMemoryUsers)
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to purge fake users.' });
  }
});

// -------------------------------------------------------------
// Vite Dev Server / Static File Serving
// -------------------------------------------------------------
async function startServer() {
  await initMongo();

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Algoria Server] Running at http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Algoria Server] Critical startup error:', err);
});
