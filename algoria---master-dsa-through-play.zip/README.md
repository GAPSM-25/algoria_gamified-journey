# Algoria - Learn DSA Exclusively Through Playable Graphic Games

**Algoria** is an adventure web game that teaches Data Structures and Algorithms exclusively through playable graphic game mechanics. No multiple-choice quizzes, no trivia, and no dry flashcards. Every concept is embodied directly in game physics and visual execution.

---

## 🌟 Tech Stack & Architecture

- **Frontend**: React 19 + TypeScript + Vite 8
- **Game Engine**: Phaser 3 (Arcade physics, procedural geometry, parallax rendering)
- **Audio**: Web Audio API (Synthesizer generating pure electronic sound effects; zero external audio files required)
- **Styling**: Tailwind CSS v4 (Dark neon purple/cyan adventure theme, custom glow, responsive layout)
- **Persistence Layer**: `src/api/gameApi.js` (localStorage backing with async Promises, structured for drop-in replacement with Django REST Framework + MySQL)
- **Visuals**: 100% procedurally drawn shapes, graphics, and SVG vectors (no external images, 0 network latency, runs instantly anywhere)

---

## 📁 Project Folder Structure

```
├── /index.html                    # Application HTML shell with fonts and metadata
├── /metadata.json                 # Studio app configuration
├── /package.json                  # Dependencies (Phaser 3, React 19, Lucide, Canvas Confetti)
├── /src/
│   ├── /api/
│   │   └── gameApi.js             # LocalStorage & Django/MySQL-ready persistence layer
│   ├── /components/
│   │   ├── CharacterAvatar.tsx    # Procedural SVG avatars for 4 companions
│   │   ├── CodeRecapModal.tsx     # Animated line-by-line recap with dual Python/JS
│   │   ├── GameHUD.tsx            # Live stats header: Hearts, XP, Coins, Stars, Hint, Retry
│   │   ├── LoopControlPanel.tsx   # Interactive loop builder & mobile touch controls
│   │   ├── NovaDialogue.tsx       # Reusable guide robot dialogue bubble with typewriter effect
│   │   └── NovaRobot.tsx          # Procedural SVG robot companion with expressive visor eyes
│   ├── /game/
│   │   └── /scenes/
│   │       └── LoopForestScene.ts # Phaser 3 scene with Subway Surfers-style side runner physics
│   ├── /levels/
│   │   └── loopForest.js          # Configurable level definitions (Levels 1 to 5)
│   ├── /screens/
│   │   ├── AuthScreen.tsx         # Login, Sign Up, and instant Guest play
│   │   ├── CharacterSelectScreen.tsx # 4 distinct companion avatars with perks
│   │   ├── GameScreen.tsx         # Connects Phaser scene, HUD, Nova, and Control Panels
│   │   ├── HomeScreen.tsx         # Hero introduction and Start Adventure
│   │   └── WorldMapScreen.tsx     # 6 DSA worlds + Object Kingdom (OOP) castle
│   ├── /utils/
│   │   └── audio.ts               # Web Audio API pure synthesizer (jumps, coins, fanfare, chimes)
│   ├── App.tsx                    # Top-level screen router
│   ├── index.css                  # Tailwind styles, dark theme, and neon glow utilities
│   └── main.tsx                   # React root mount
└── README.md
```

---

## 🗺️ Algoria World Map & Curriculum

1. **Loop Forest (Unlocked & Fully Playable)**
   - **Level 1 (Manual Jump)**: Vault 5 trees using Space or on-screen button. Realize the fatigue of repetition.
   - **Level 2 (For Loop)**: Automate 20 jumps with a `repeat [20] times: jump()` block.
   - **Level 3 (Compound Loop Body)**: Execute multiple instructions per iteration: `repeat 10: [jump(), collect_coin()]`.
   - **Level 4 (Nested Loops)**: Navigate 3 forest groves with 4 trees each: `repeat 3: repeat 4: jump()`.
   - **Level 5 (While Loop & Dynamic Break)**: Jump dynamically while `tree_ahead()` is true, and safely stop and deploy a bridge when the cyber river appears.
   - **Reward**: Earn 1-3 Stars per level, gain XP and crystals, unlock the **Loop Master Badge**, and unlock Sector 02!

2. **Stack Volcano (Unlocked & Fully Playable after Loop Forest)**
   - **Level 1 (Push Basics)**: Push 3 cooling basalt boulders onto the containment pedestal (`stack.push()`).
   - **Level 2 (Pop to Remove Top)**: Magma surge! Pop the unstable top rock to vent pressure before rising lava reaches the platform (`stack.pop()`).
   - **Level 3 (Thermal Peek)**: Inspect the energy signature of the top rock without altering stack size or removing items (`stack.peek()` / `stack[-1]`).
   - **Level 4 (Undo History Puzzle)**: Revert an accidental "Toxic Slag" placement using the LIFO Undo stack pattern (Ctrl+Z mechanism).
   - **Level 5 (Word Reversal with Stack)**: Push letters `N -> O -> V -> A`, then pop them all out to unlock the Caldera Gate with the reversed sequence `A -> V -> O -> N`.
   - **Reward**: Earn 1-3 Stars per level, gain XP and crystals, unlock the **Stack Climber Badge**, and unlock Sector 03!

3. **Queue River (Locked - Coming Next)**
   - FIFO (First-In, First-Out) raft dispatch navigation.

4. **Tree Valley (Locked - Coming Soon)**
   - Binary Search Tree branch balance and traversal mechanics.

5. **Graph City (Locked - Coming Soon)**
   - Dijkstra Shortest Path hyperloop routing.

6. **Array Arena (Locked - Coming Soon)**
   - Zero-indexed colosseum battles and two-pointer brawls.

7. **Object Kingdom (OOP Castle)**
   - Interactive fortress modal: *"Object Kingdom is not ready yet! Continue with DSA. We will prepare it soon."* with a **"Back to DSA"** button.

---

## 🎮 How to Run

1. **Install dependencies**:
   ```bash
   npm install
   ```
2. **Start the development server**:
   ```bash
   npm run dev
   ```
3. Open your browser at `http://localhost:3000`.

---

## 🔌 Replacing LocalStorage with Django + MySQL Backend

All API calls are concentrated inside `src/api/gameApi.js`. To connect to a live Django backend:
1. Update `login()`, `signup()`, and `getCurrentUser()` to call your Django REST `/api/auth/` endpoints.
2. Update `recordLevelCompletion()` to `POST /api/progress/level-complete/`.
3. In Django, map `models.Model` to a MySQL database table matching the JSON schema defined in `createDefaultProgress()`.
