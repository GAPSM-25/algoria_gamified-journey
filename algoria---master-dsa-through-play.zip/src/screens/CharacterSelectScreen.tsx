import React, { useState } from 'react';
import { CHARACTERS, selectCharacter } from '../api/gameApi.js';
import { CharacterAvatar } from '../components/CharacterAvatar.tsx';
import { NovaRobot } from '../components/NovaRobot.tsx';
import { Shield, Coins, Sparkles, Gauge, ArrowRight, ArrowLeft, Bot, User, CheckCircle2, Home } from 'lucide-react';
import { playButtonClick, playSuccessSound } from '../utils/audio.ts';

interface CharacterSelectScreenProps {
  currentUser: any;
  onCharacterConfirmed: (charId: string) => void;
  onBack: () => void;
  onGoHome?: () => void;
}

export const CharacterSelectScreen: React.FC<CharacterSelectScreenProps> = ({
  currentUser,
  onCharacterConfirmed,
  onBack,
  onGoHome
}) => {
  const initialCharId = currentUser?.progress?.characterId || 'bit_byte';
  const [selectedId, setSelectedId] = useState<string>(initialCharId);
  const [previewMood, setPreviewMood] = useState<'happy' | 'excited' | 'curious' | 'proud' | 'surprised'>('excited');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const selectedChar = CHARACTERS.find((c) => c.id === selectedId) || CHARACTERS[0];

  const handleSelect = (id: string) => {
    playButtonClick();
    setSelectedId(id);
  };

  const handleConfirm = async () => {
    setIsSaving(true);
    try {
      if (currentUser?.username) {
        await selectCharacter(currentUser.username, selectedId);
      }
      playSuccessSound();
      onCharacterConfirmed(selectedId);
    } catch (e) {
      console.error(e);
      onCharacterConfirmed(selectedId);
    } finally {
      setIsSaving(false);
    }
  };

  const getPerkIcon = (charId: string) => {
    switch (charId) {
      case 'bit_byte':
        return <Shield className="w-4 h-4 text-cyan-400" />;
      case 'algo_fox':
        return <Coins className="w-4 h-4 text-amber-400" />;
      case 'cyber_nova':
        return <Sparkles className="w-4 h-4 text-purple-400" />;
      case 'pixel_knight':
      default:
        return <Gauge className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-[#050814] text-slate-100 flex flex-col justify-between p-4 sm:p-8 overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950">
      {/* Background Ambient Glows matching reference */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full opacity-25 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(6, 182, 212, 0.4) 0%, rgba(168, 85, 247, 0.2) 50%, transparent 75%)'
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full opacity-15 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(168, 85, 247, 0.35) 0%, transparent 70%)'
          }}
        />
      </div>

      {/* Top Nav */}
      <header className="relative z-10 max-w-6xl w-full mx-auto flex items-center justify-between pb-4 border-b border-cyan-500/20">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              playButtonClick();
              onBack();
            }}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Realm</span>
          </button>

          {onGoHome && (
            <button
              onClick={() => {
                playButtonClick();
                onGoHome();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-cyan-300 hover:text-white bg-slate-900/90 hover:bg-slate-800 rounded-xl border border-cyan-500/40 hover:border-cyan-400 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Return to Home Page"
            >
              <Home className="w-3.5 h-3.5 text-cyan-400" />
              <span>Home</span>
            </button>
          )}
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Explorer: <strong className="text-cyan-300 font-sans">{currentUser?.username || 'Guest'}</strong>
        </div>
      </header>

      {/* Main Select Arena */}
      <main className="relative z-10 max-w-6xl w-full mx-auto my-auto py-6">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#081734] border border-cyan-500/50 text-cyan-300 text-xs font-semibold mb-3 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>CHOOSE YOUR HERO COMPANION</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            Choose Your Favorite Avatar
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-xl mx-auto leading-relaxed">
            Your chosen companion will be your <strong className="text-cyan-300">playable hero</strong> across all 6 DSA sectors and will also power <strong className="text-purple-300">Nova, your robotic AI guide</strong>!
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 mb-8">
          {CHARACTERS.map((char) => {
            const isSelected = char.id === selectedId;
            return (
              <div
                key={char.id}
                onClick={() => handleSelect(char.id)}
                className={`relative p-5 rounded-2xl sm:rounded-3xl cursor-pointer transition-all duration-300 flex flex-col items-center text-center overflow-hidden backdrop-blur-xl ${
                  isSelected
                    ? 'border-2 border-cyan-400 bg-[#09152e]/90 shadow-[0_0_30px_rgba(6,182,212,0.45)] ring-2 ring-cyan-400/20 scale-[1.02]'
                    : 'border border-blue-900/40 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-900/80 hover:scale-[1.01]'
                }`}
              >
                {/* Selected Indicator Checkmark */}
                {isSelected && (
                  <span className="absolute top-3 right-3 z-10 w-6 h-6 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-md">
                    <CheckCircle2 className="w-4 h-4 fill-current stroke-slate-950" />
                  </span>
                )}

                {/* Avatar Preview */}
                <div className="my-3">
                  <CharacterAvatar characterId={char.id} size={90} isSelected={isSelected} />
                </div>

                {/* Name & Title */}
                <h3 className="text-lg font-bold text-white mt-1">{char.name}</h3>
                <span className="text-xs text-slate-400 mb-3">{char.title}</span>

                {/* Perk Box */}
                <div className="w-full mt-auto p-3 bg-slate-900/80 border border-slate-800 rounded-xl text-left">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300 mb-1">
                    {getPerkIcon(char.id)}
                    <span>{char.perk}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-tight">
                    {char.perkDescription}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Dual Live Preview: Player & Nova Form */}
        <div className="max-w-2xl mx-auto mb-8 p-5 bg-slate-950/70 border border-blue-900/40 rounded-2xl sm:rounded-3xl shadow-2xl backdrop-blur-xl">
          <div className="text-center mb-3">
            <span className="text-xs font-black text-cyan-300 uppercase tracking-widest">
              Dual Form Preview: {selectedChar.name}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            {/* Player Character Form */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-center gap-4">
              <div className="p-1.5 bg-slate-950 rounded-2xl border border-cyan-500/40">
                <CharacterAvatar characterId={selectedId} size={60} />
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                  <User className="w-3.5 h-3.5" />
                  <span>As Player</span>
                </div>
                <h4 className="text-sm font-bold text-white mt-0.5">{selectedChar.name}</h4>
                <p className="text-[11px] text-slate-400">Controls algorithms in sectors</p>
              </div>
            </div>

            {/* Nova Robot Form */}
            <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-center gap-4">
              <div className="p-1.5 bg-slate-950 rounded-2xl border border-purple-500/40">
                <NovaRobot characterId={selectedId} mood={previewMood} size={60} isFloating={true} />
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300">
                  <Bot className="w-3.5 h-3.5" />
                  <span>As Guide Nova</span>
                </div>
                <h4 className="text-sm font-bold text-white mt-0.5">Nova ({selectedChar.name})</h4>
                <div className="flex items-center gap-1 mt-1">
                  {(['happy', 'excited', 'curious', 'proud'] as const).map((mood) => (
                    <button
                      key={mood}
                      onClick={() => {
                        playButtonClick();
                        setPreviewMood(mood);
                      }}
                      className={`text-[9px] px-1.5 py-0.5 rounded capitalize transition-all cursor-pointer ${
                        previewMood === mood
                          ? 'bg-purple-600 text-white font-bold'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {mood}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Confirm Button */}
        <div className="flex justify-center">
          <button
            onClick={handleConfirm}
            disabled={isSaving}
            className="px-8 py-3.5 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-fuchsia-500 hover:brightness-110 active:scale-95 text-slate-950 font-black text-sm sm:text-base flex items-center gap-2.5 shadow-lg shadow-cyan-500/25 transition cursor-pointer disabled:opacity-50"
          >
            <span>{isSaving ? 'Synchronizing Avatar...' : `Confirm & Play with ${selectedChar.name}`}</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </main>

      <footer className="text-center text-xs text-slate-500 py-2 border-t border-slate-900">
        You can switch companions anytime from your world map or game header
      </footer>
    </div>
  );
};
