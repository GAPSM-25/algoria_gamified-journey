import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  Activity,
  CheckCircle2,
  TrendingDown,
  Unlock,
  RotateCcw,
  Heart,
  Zap,
  ArrowLeft,
  Server,
  Terminal,
  Database,
  RefreshCw,
  AlertTriangle,
  Key,
  HardDrive,
  Check,
  Home
} from 'lucide-react';
import { getAdminStats, adminUnlockAll, adminResetProgress, getDbStatus, purgeFakeUsers, getCurrentUser } from '../api/gameApi.js';
import { playButtonClick } from '../utils/audio.ts';

interface AdminScreenProps {
  currentUser: any;
  onExit: () => void;
  onGoHome?: () => void;
  onUserDataUpdated: (user: any) => void;
}

export const AdminScreen: React.FC<AdminScreenProps> = ({
  currentUser,
  onExit,
  onGoHome,
  onUserDataUpdated
}) => {
  const [stats, setStats] = useState(() => getAdminStats());
  const [adminNotice, setAdminNotice] = useState<string | null>(null);
  const [dbState, setDbState] = useState<{
    connected: boolean;
    status: string;
    message: string;
    cluster: string;
    database: string;
  }>({
    connected: false,
    status: 'checking',
    message: 'Testing connection to MongoDB Atlas...',
    cluster: 'cluster0.lpoe18o.mongodb.net',
    database: 'algoria'
  });
  const [isRefreshingDb, setIsRefreshingDb] = useState(false);

  const checkDb = async () => {
    setIsRefreshingDb(true);
    try {
      const res = await getDbStatus();
      setDbState(res);
    } catch (err: any) {
      setDbState({
        connected: false,
        status: 'error',
        message: err?.message || 'Could not reach server',
        cluster: 'cluster0.lpoe18o.mongodb.net',
        database: 'algoria'
      });
    } finally {
      setIsRefreshingDb(false);
    }
  };

  useEffect(() => {
    checkDb();
  }, []);

  const handleUnlockAll = () => {
    playButtonClick();
    if (!currentUser?.username) return;
    const updated = adminUnlockAll(currentUser.username);
    if (updated) {
      onUserDataUpdated(updated);
      setAdminNotice('Success: All 6 DSA Worlds and Badges have been unlocked for ' + currentUser.username);
      setStats(getAdminStats());
    }
  };

  const handleResetProgress = () => {
    playButtonClick();
    if (!currentUser?.username) return;
    const updated = adminResetProgress(currentUser.username);
    if (updated) {
      onUserDataUpdated(updated);
      setAdminNotice('Progress reset to Sector 01 for ' + currentUser.username);
      setStats(getAdminStats());
    }
  };

  const handlePurgeFakeUsers = async () => {
    playButtonClick();
    await purgeFakeUsers();
    const active = await getCurrentUser();
    if (active) {
      onUserDataUpdated(active);
    }
    setStats(getAdminStats());
    setAdminNotice('Cleaned: All fake & placeholder accounts removed. Only real user pallavi and real registered data active!');
  };

  return (
    <div className="min-h-screen w-full bg-[#050814] text-slate-100 p-4 sm:p-8 font-sans selection:bg-cyan-500 selection:text-slate-950">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Admin Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-950 border border-red-500/50 rounded-2xl text-red-400">
              <Terminal className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-black text-white">Algoria Core Admin Console</h1>
                <span className="text-[10px] bg-red-950 text-red-400 border border-red-500/40 px-2 py-0.5 rounded-full font-mono font-bold">
                  RESTRICTED / DEV MODE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                System telemetry, user drop-off funnel analytics, and runtime developer tools.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onGoHome && (
              <button
                onClick={() => {
                  playButtonClick();
                  onGoHome();
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/50 hover:border-cyan-400 text-cyan-300 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md active:scale-95"
                title="Return to Home Screen"
              >
                <Home className="w-4 h-4 text-cyan-400" />
                <span>Return to Home</span>
              </button>
            )}

            <button
              onClick={() => {
                playButtonClick();
                onExit();
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to World Map</span>
            </button>
          </div>
        </div>

        {/* Notice alert */}
        {adminNotice && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-xs font-mono text-emerald-300 flex items-center justify-between">
            <span>{adminNotice}</span>
            <button
              onClick={() => setAdminNotice(null)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
        )}

        {/* MongoDB Atlas Database Connection Card */}
        <div className={`p-5 rounded-2xl border transition-all ${
          dbState.connected
            ? 'bg-gradient-to-r from-emerald-950/40 to-slate-900 border-emerald-500/50'
            : dbState.status === 'pending_password'
            ? 'bg-gradient-to-r from-amber-950/40 to-slate-900 border-amber-500/50'
            : 'bg-gradient-to-r from-slate-900 to-indigo-950/40 border-slate-800'
        }`}>
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl border ${
                dbState.connected
                  ? 'bg-emerald-900/50 border-emerald-500/50 text-emerald-400'
                  : dbState.status === 'pending_password'
                  ? 'bg-amber-900/50 border-amber-500/50 text-amber-400'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}>
                <Database className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white">MongoDB Atlas Cloud Database</h2>
                  <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1 border ${
                    dbState.connected
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                      : dbState.status === 'pending_password'
                      ? 'bg-amber-950 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    {dbState.connected ? (
                      <>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        LIVE ATLAS CONNECTED
                      </>
                    ) : dbState.status === 'pending_password' ? (
                      <>
                        <Key className="w-3 h-3" />
                        PENDING PASSWORD SETUP
                      </>
                    ) : (
                      <>
                        <HardDrive className="w-3 h-3" />
                        OFFLINE / FALLBACK MODE
                      </>
                    )}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Target Cluster: <span className="text-cyan-300">cluster0.lpoe18o.mongodb.net</span> · Database: <span className="text-amber-300">algoria</span> · Collection: <span className="text-purple-300">users</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                playButtonClick();
                checkDb();
              }}
              disabled={isRefreshingDb}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 text-xs font-mono transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingDb ? 'animate-spin text-cyan-400' : ''}`} />
              <span>{isRefreshingDb ? 'Testing Connection...' : 'Test / Refresh Ping'}</span>
            </button>
          </div>

          <div className="mt-3.5 space-y-2">
            <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300">
              <div className="flex items-start gap-2">
                <span className="text-slate-500 font-bold shrink-0">URI:</span>
                <span className="break-all text-slate-300 select-all">
                  mongodb+srv://pallaviligade05_db_user:<span className="text-amber-400 font-bold">&lt;db_password&gt;</span>@cluster0.lpoe18o.mongodb.net/algoria?retryWrites=true&amp;w=majority
                </span>
              </div>
              <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1.5">
                <span className="text-cyan-400">Status message:</span>
                <span className="text-slate-200">{dbState.message}</span>
              </div>
            </div>

            {dbState.status === 'pending_password' && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-amber-300 font-bold">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>How to connect your MongoDB Atlas live database:</span>
                </div>
                <ol className="list-decimal list-inside text-slate-300 text-[11px] space-y-1 font-sans">
                  <li>Open the <span className="font-mono text-amber-300 bg-amber-950/80 px-1 py-0.5 rounded">.env</span> file in the project root.</li>
                  <li>Replace <span className="font-mono text-amber-300">&lt;db_password&gt;</span> with your actual MongoDB user password for <span className="font-mono text-cyan-300">pallaviligade05_db_user</span>.</li>
                  <li>Save the file and click <span className="font-bold text-white">Test / Refresh Ping</span> above to connect live.</li>
                </ol>
                <p className="text-[10px] text-slate-400 italic">
                  Note: While in setup mode, Algoria seamlessly persists state and user records locally so all gameplay, level saves, streaks, and characters function normally without interruptions.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Top Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Total Explorers</span>
              <Users className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-extrabold text-white mt-2 font-mono">
              {stats.metrics.totalExplorers.toLocaleString()}
            </div>
            <div className="text-[10px] text-emerald-400 mt-1 font-mono">+12.4% this week</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Active Today</span>
              <Activity className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-extrabold text-emerald-400 mt-2 font-mono">
              {stats.metrics.activeToday}
            </div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Concurrently online</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Avg Completion</span>
              <CheckCircle2 className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-extrabold text-purple-300 mt-2 font-mono">
              {stats.metrics.avgCompletionRate}
            </div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Across all 6 sectors</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Levels Cleared Today</span>
              <Zap className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-extrabold text-amber-300 mt-2 font-mono">
              {stats.metrics.levelsCompletedToday.toLocaleString()}
            </div>
            <div className="text-[10px] text-amber-400/80 mt-1 font-mono">Avg 16.5m / session</div>
          </div>
        </div>

        {/* Developer God-Mode Testing Controls */}
        <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-red-950/40 border border-red-500/30">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-red-300 flex items-center gap-2">
              <Database className="w-4 h-4 text-red-400" />
              <span>Developer Sandbox Controls (Active Player: {currentUser?.username || 'Guest'})</span>
            </h2>
            <div className="flex items-center gap-3 text-xs font-mono bg-slate-950/80 px-3 py-1 rounded-lg border border-slate-800">
              <span className="text-orange-400 flex items-center gap-1">
                🔥 Streak: {currentUser?.progress?.streak || 1}d
              </span>
              <span className="text-cyan-300 flex items-center gap-1">
                ✨ Dust: {currentUser?.progress?.algoriaDust ?? 50}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleUnlockAll}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>Instant Unlock All 6 Worlds &amp; Badges</span>
            </button>

            <button
              onClick={handleResetProgress}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-2 border border-slate-700 transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span>Reset Current Account to Sector 01</span>
            </button>

            <button
              onClick={handlePurgeFakeUsers}
              className="px-4 py-2.5 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-500/50 active:scale-95 text-purple-200 hover:text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md"
              title="Deletes all generated guest/placeholder accounts, keeping only real user pallavi and real registered accounts"
            >
              <ShieldAlert className="w-4 h-4 text-purple-400" />
              <span>Purge All Fake Users (Real Data Only)</span>
            </button>
          </div>
        </div>

        {/* Sector Funnel Analytics */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 mb-4">
            <TrendingDown className="w-4 h-4 text-cyan-400" />
            <span>Sector Progression &amp; Drop-off Funnel</span>
          </h2>

          <div className="space-y-3 font-mono text-xs">
            {stats.funnel.map((item) => {
              const pct = Math.round((item.cleared / item.started) * 100);

              return (
                <div key={item.sector} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{item.sector}</span>
                    <span className="text-slate-400">
                      Started: <span className="text-cyan-300">{item.started}</span> · Cleared:{' '}
                      <span className="text-emerald-400">{item.cleared}</span> · Drop-off:{' '}
                      <span className="text-rose-400 font-bold">{item.dropoff}</span>
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Player Telemetry Log */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 overflow-x-auto">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 mb-4">
            <Server className="w-4 h-4 text-purple-400" />
            <span>Live Session Telemetry</span>
          </h2>

          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="text-slate-400 border-b border-slate-800 pb-2">
                <th className="pb-2">Explorer</th>
                <th className="pb-2">Current Sector</th>
                <th className="pb-2">Level</th>
                <th className="pb-2">Stars</th>
                <th className="pb-2">Latency</th>
                <th className="pb-2">Client Platform</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {stats.recentExplorers.map((row) => (
                <tr key={row.name} className="hover:bg-slate-950/60 transition-colors">
                  <td className="py-2.5 font-bold text-white">{row.name}</td>
                  <td className="py-2.5 text-cyan-300">{row.sector}</td>
                  <td className="py-2.5 text-slate-300">Level {row.level}</td>
                  <td className="py-2.5 text-yellow-400">★ {row.stars}</td>
                  <td className="py-2.5 text-emerald-400">{row.ping}</td>
                  <td className="py-2.5 text-slate-400">{row.os}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
