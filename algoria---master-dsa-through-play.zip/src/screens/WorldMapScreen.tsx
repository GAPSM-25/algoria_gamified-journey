import React, { useState } from 'react';
import { WORLDS, LOOP_FOREST_LEVELS, OBJECT_KINGDOM_INFO } from '../levels/loopForest.js';
import { STACK_VOLCANO_LEVELS } from '../levels/stackVolcano.js';
import { QUEUE_RIVER_LEVELS } from '../levels/queueRiver.js';
import { TREE_VALLEY_LEVELS } from '../levels/treeValley.js';
import { GRAPH_CITY_LEVELS } from '../levels/graphCity.js';
import { ARRAY_ARENA_LEVELS } from '../levels/arrayArena.js';
import { LeaderboardModal } from '../components/LeaderboardModal.tsx';
import { BadgesModal } from '../components/BadgesModal.tsx';
import { StreakModal } from '../components/StreakModal.tsx';
import { CharacterAvatar } from '../components/CharacterAvatar.tsx';
import confetti from 'canvas-confetti';
import { claimDailyStreakReward, getDustRewardForStreak } from '../api/gameApi.js';
import {
  Lock,
  Star,
  Zap,
  Coins,
  Award,
  Play,
  Volume2,
  VolumeX,
  X,
  Castle,
  Trees,
  Flame,
  Waves,
  GitBranch,
  Network,
  Boxes,
  ArrowRight,
  User,
  Trophy,
  Terminal,
  Sparkles,
  CheckCircle2,
  Calendar,
  Compass,
  Home
} from 'lucide-react';
import { playButtonClick, playErrorSound, playDustRewardSound } from '../utils/audio.ts';

interface WorldMapScreenProps {
  currentUser: any;
  onSelectLevel: (worldId: string, levelId: number) => void;
  onChangeCharacter: () => void;
  onLogout: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenAdmin?: () => void;
  onUserDataUpdated?: (user: any) => void;
  onOpenObjectKingdom?: () => void;
  onOpenRealmSelect?: () => void;
  onGoHome?: () => void;
}

export const WorldMapScreen: React.FC<WorldMapScreenProps> = ({
  currentUser,
  onSelectLevel,
  onChangeCharacter,
  onLogout,
  isMuted,
  onToggleMute,
  onOpenAdmin,
  onUserDataUpdated,
  onOpenObjectKingdom,
  onOpenRealmSelect,
  onGoHome
}) => {
  const [selectedWorldForLevels, setSelectedWorldForLevels] = useState<string | null>(null);
  const [showObjectKingdomModal, setShowObjectKingdomModal] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);
  const [showBadges, setShowBadges] = useState<boolean>(false);
  const [showStreak, setShowStreak] = useState<boolean>(false);

  const progress = currentUser?.progress || {};
  const completedLevels = progress.completedLevels || {};
  const badges = progress.badges || [];
  const unlockedWorlds = progress.unlockedWorlds || ['loop_forest'];

  // Check if Stack Volcano, Queue River, Tree Valley, Graph City, and Array Arena are unlocked
  const isStackUnlocked = unlockedWorlds.includes('stack_volcano') || badges.includes('loop_master');
  const isQueueUnlocked = unlockedWorlds.includes('queue_river') || badges.includes('stack_climber');
  const isTreeUnlocked = unlockedWorlds.includes('tree_valley') || badges.includes('queue_captain');
  const isGraphUnlocked = unlockedWorlds.includes('graph_city') || badges.includes('tree_whisperer');
  const isArenaUnlocked = unlockedWorlds.includes('array_arena') || badges.includes('graph_navigator');

  // Daily Streak & Algoria Dust state
  const today = new Date().toISOString().split('T')[0];
  const currentStreak = progress.streak || 1;
  const algoriaDust = progress.algoriaDust ?? 50;
  const hasClaimedToday = progress.lastStreakClaimDate === today;
  const todaysDustReward = getDustRewardForStreak(currentStreak);

  const handleClaimStreakDust = async () => {
    if (!currentUser?.username) return;
    try {
      const res = await claimDailyStreakReward(currentUser.username);
      if (res && res.user && onUserDataUpdated) {
        onUserDataUpdated(res.user);
        playDustRewardSound();
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#06b6d4', '#38bdf8', '#fbbf24', '#f97316']
          });
        } catch {}
      }
    } catch (e) {
      console.error('Failed to claim streak reward', e);
    }
  };

  const getWorldIcon = (worldId: string) => {
    switch (worldId) {
      case 'loop_forest':
        return <Trees className="w-6 h-6 text-emerald-400" />;
      case 'stack_volcano':
        return <Flame className="w-6 h-6 text-red-400" />;
      case 'queue_river':
        return <Waves className="w-6 h-6 text-cyan-400" />;
      case 'tree_valley':
        return <GitBranch className="w-6 h-6 text-purple-400" />;
      case 'graph_city':
        return <Network className="w-6 h-6 text-pink-400" />;
      case 'array_arena':
      default:
        return <Boxes className="w-6 h-6 text-amber-400" />;
    }
  };

  const handleWorldClick = (world: any) => {
    playButtonClick();
    if (world.id === 'loop_forest') {
      setSelectedWorldForLevels('loop_forest');
    } else if (world.id === 'stack_volcano') {
      if (isStackUnlocked) {
        setSelectedWorldForLevels('stack_volcano');
      } else {
        playErrorSound();
        alert('Stack Volcano is locked! Complete all 5 levels in Loop Forest to unlock it.');
      }
    } else if (world.id === 'queue_river') {
      if (isQueueUnlocked) {
        setSelectedWorldForLevels('queue_river');
      } else {
        playErrorSound();
        alert('Queue River is locked! Complete all 5 levels in Stack Volcano to unlock it.');
      }
    } else if (world.id === 'tree_valley') {
      if (isTreeUnlocked) {
        setSelectedWorldForLevels('tree_valley');
      } else {
        playErrorSound();
        alert('Tree Valley is locked! Complete all 5 levels in Queue River to unlock it.');
      }
    } else if (world.id === 'graph_city') {
      if (isGraphUnlocked) {
        setSelectedWorldForLevels('graph_city');
      } else {
        playErrorSound();
        alert('Graph City is locked! Complete all 5 levels in Tree Valley to unlock it.');
      }
    } else if (world.id === 'array_arena') {
      if (isArenaUnlocked) {
        setSelectedWorldForLevels('array_arena');
      } else {
        playErrorSound();
        alert('Array Arena is locked! Complete all 5 levels in Graph City to unlock it.');
      }
    } else {
      playErrorSound();
      alert(`${world.name} is coming next! Complete the preceding DSA worlds to venture here.`);
    }
  };

  const calculateTotalStars = () => {
    return Object.values(completedLevels).reduce(
      (sum: number, lvl: any) => sum + (lvl.stars || 0),
      0
    );
  };

  return (
    <div className="relative min-h-screen w-full bg-[#050814] text-slate-100 flex flex-col justify-between overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Map Header */}
      <header className="sticky top-0 z-30 bg-slate-950/90 border-b border-cyan-500/20 px-4 sm:px-8 py-3 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Left: User & Companion Profile */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                playButtonClick();
                onChangeCharacter();
              }}
              className="relative group p-1 bg-slate-900 border border-purple-500/40 rounded-xl hover:border-cyan-400 transition-colors cursor-pointer"
              title="Change Companion"
            >
              <CharacterAvatar characterId={progress.characterId || 'bit_byte'} size={36} />
              <span className="absolute -bottom-1 -right-1 p-0.5 bg-cyan-500 rounded-full text-slate-950">
                <User className="w-2.5 h-2.5" />
              </span>
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-bold text-white tracking-wide">
                  {currentUser?.username || 'Explorer'}
                </span>
                {badges.includes('loop_master') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-yellow-300 bg-yellow-950/70 border border-yellow-500/40 px-2 py-0.5 rounded-full">
                    <Award className="w-3 h-3 text-yellow-400" />
                    Loop Master
                  </span>
                )}
                {badges.includes('stack_climber') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-300 bg-red-950/70 border border-red-500/40 px-2 py-0.5 rounded-full">
                    <Flame className="w-3 h-3 text-red-400" />
                    Stack Climber
                  </span>
                )}
                {badges.includes('queue_captain') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-cyan-300 bg-cyan-950/70 border border-cyan-500/40 px-2 py-0.5 rounded-full">
                    <Waves className="w-3 h-3 text-cyan-400" />
                    Queue Captain
                  </span>
                )}
                {badges.includes('tree_whisperer') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-purple-300 bg-purple-950/70 border border-purple-500/40 px-2 py-0.5 rounded-full">
                    <GitBranch className="w-3 h-3 text-purple-400" />
                    Tree Whisperer
                  </span>
                )}
                {badges.includes('graph_navigator') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-pink-300 bg-pink-950/70 border border-pink-500/40 px-2 py-0.5 rounded-full">
                    <Network className="w-3 h-3 text-pink-400" />
                    Graph Navigator
                  </span>
                )}
                {badges.includes('array_gladiator') && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-950/70 border border-amber-500/40 px-2 py-0.5 rounded-full">
                    <Boxes className="w-3 h-3 text-amber-400" />
                    Array Gladiator
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-400">Algoria DSA Expedition</span>
            </div>
          </div>

          {/* Center Stats */}
          <div className="flex items-center gap-2 sm:gap-4 text-xs sm:text-sm">
            {/* Daily Streak Button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowStreak(true);
              }}
              className="flex items-center gap-1 px-2.5 py-1 bg-orange-950/70 hover:bg-orange-900/80 border border-orange-500/40 rounded-lg text-orange-300 text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Daily Streak Momentum"
            >
              <Flame className="w-3.5 h-3.5 fill-orange-400 text-orange-400 animate-pulse" />
              <span>{progress.streak || 1}d Streak</span>
            </button>

            <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-purple-500/30">
              <Zap className="w-4 h-4 text-purple-400" />
              <span className="font-mono font-bold text-purple-300 tabular-nums">
                {progress.xp || 0}
              </span>
              <span className="text-[10px] text-slate-500 hidden sm:inline">XP</span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-amber-500/30">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="font-mono font-bold text-amber-300 tabular-nums">
                {progress.coins || 0}
              </span>
            </div>

            <div className="flex items-center gap-1 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-yellow-500/30">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="font-mono font-bold text-yellow-300 tabular-nums">
                {calculateTotalStars()}
              </span>
            </div>
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-2">
            {/* Return to Home Screen Button */}
            {onGoHome && (
              <button
                onClick={() => {
                  playButtonClick();
                  onGoHome();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-950/80 to-slate-900 hover:from-cyan-900/90 hover:to-slate-800 border border-cyan-500/50 hover:border-cyan-400 rounded-xl text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm active:scale-95 group"
                title="Return to Home Page"
              >
                <Home className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                <span>Home</span>
              </button>
            )}

            {/* Badges Gallery Button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowBadges(true);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500/40 rounded-xl text-purple-200 text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Hall of Badges"
            >
              <Award className="w-4 h-4 text-purple-400" />
              <span className="hidden sm:inline">Badges</span>
            </button>

            {/* Leaderboard Button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowLeaderboard(true);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/40 rounded-xl text-amber-200 text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Global Leaderboard"
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Ranks</span>
            </button>

            {/* Switch Realm Button */}
            <button
              onClick={() => {
                playButtonClick();
                if (onOpenRealmSelect) onOpenRealmSelect();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-slate-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Switch Realm (DSA vs OOP)"
            >
              <Compass className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">Realms</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                onToggleMute();
              }}
              className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => {
                playButtonClick();
                onLogout();
              }}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-800 transition-colors cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        </div>
      </header>

      {/* Main Map Canvas Area */}
      <main className="max-w-7xl w-full mx-auto p-4 sm:p-8 flex-1">
        {/* Title & Castle Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              World Map · Algoria Realm
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Follow the algorithm trail. Complete each world to master DSA mechanics.
            </p>
          </div>

          {/* Object Kingdom (OOP) Castle Banner - LOCKED */}
          <button
            onClick={() => {
              playErrorSound();
              setShowObjectKingdomModal(true);
            }}
            className="flex items-center gap-3 px-4 py-3 bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 rounded-2xl shadow-lg transition-all cursor-pointer text-left group"
          >
            <div className="relative p-2 bg-slate-800 rounded-xl text-slate-400 group-hover:scale-105 transition-transform">
              <Castle className="w-6 h-6 stroke-[2]" />
              <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 rounded-full p-0.5 border border-slate-900">
                <Lock className="w-2.5 h-2.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <span>Object Kingdom (OOP)</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold flex items-center gap-1">
                  <Lock className="w-2.5 h-2.5 text-amber-400" />
                  <span>Locked</span>
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                Under Construction · Coming Soon
              </span>
            </div>
          </button>
        </div>

        {/* Daily Streak & Algoria Dust Mission Banner */}
        <div className="mb-8 rounded-2xl border border-orange-500/30 bg-gradient-to-r from-orange-950/40 via-slate-900/90 to-cyan-950/40 p-4 sm:p-5 shadow-xl relative overflow-hidden backdrop-blur-sm">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            {/* Left: Streak Status & Lore */}
            <div className="flex items-center gap-4">
              <div className="relative p-3.5 bg-gradient-to-br from-orange-500/20 to-amber-500/20 border border-orange-500/50 rounded-2xl text-orange-400 shadow-md">
                <Flame className="w-8 h-8 fill-orange-400 animate-pulse" />
                <span className="absolute -bottom-1 -right-1 bg-orange-500 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full border border-orange-300">
                  {currentStreak}d
                </span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                    {currentStreak}-Day Login Streak
                  </h2>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    <span>{algoriaDust} Algoria Dust</span>
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">
                  Keep your algorithm momentum active. Return daily to earn shimmering Algoria Dust and unlock realm artifacts.
                </p>
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-start md:justify-end">
              {!hasClaimedToday ? (
                <button
                  onClick={handleClaimStreakDust}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-orange-500/25 transition-all transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-slate-950" />
                  <span>Claim +{todaysDustReward} Dust</span>
                </button>
              ) : (
                <div className="flex items-center gap-1.5 px-3 py-2 bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-xl">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Today Claimed (+{todaysDustReward} Dust)</span>
                </div>
              )}

              <button
                onClick={() => {
                  playButtonClick();
                  setShowStreak(true);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-xs font-bold text-slate-200 hover:text-white rounded-xl transition-colors cursor-pointer"
                title="Open 7-Day Rewards Calendar"
              >
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>7-Day Rewards</span>
              </button>
            </div>
          </div>
        </div>

        {/* 6 Worlds Map Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WORLDS.map((world, index) => {
            const isUnlocked =
              world.id === 'loop_forest' ||
              (world.id === 'stack_volcano' && isStackUnlocked) ||
              (world.id === 'queue_river' && isQueueUnlocked) ||
              (world.id === 'tree_valley' && isTreeUnlocked) ||
              (world.id === 'graph_city' && isGraphUnlocked) ||
              (world.id === 'array_arena' && isArenaUnlocked);

            const isLoopForest = world.id === 'loop_forest';
            const isStackVolcano = world.id === 'stack_volcano';
            const isQueueRiver = world.id === 'queue_river';
            const isTreeValley = world.id === 'tree_valley';
            const isGraphCity = world.id === 'graph_city';
            const isArrayArena = world.id === 'array_arena';

            let completedCount = 0;
            if (isLoopForest) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`loop_forest_${l}`]?.stars > 0
              ).length;
            } else if (isStackVolcano) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`stack_volcano_${l}`]?.stars > 0
              ).length;
            } else if (isQueueRiver) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`queue_river_${l}`]?.stars > 0
              ).length;
            } else if (isTreeValley) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`tree_valley_${l}`]?.stars > 0
              ).length;
            } else if (isGraphCity) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`graph_city_${l}`]?.stars > 0
              ).length;
            } else if (isArrayArena) {
              completedCount = [1, 2, 3, 4, 5].filter(
                (l) => completedLevels[`array_arena_${l}`]?.stars > 0
              ).length;
            }

            return (
              <div
                key={world.id}
                onClick={() => handleWorldClick(world)}
                className={`relative p-6 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                  isUnlocked
                    ? world.id === 'stack_volcano'
                      ? 'bg-slate-900/90 border-red-500/40 hover:border-red-400 hover:shadow-xl hover:shadow-red-500/15'
                      : world.id === 'queue_river'
                      ? 'bg-slate-900/90 border-cyan-500/40 hover:border-cyan-400 hover:shadow-xl hover:shadow-cyan-500/15'
                      : world.id === 'tree_valley'
                      ? 'bg-slate-900/90 border-purple-500/40 hover:border-purple-400 hover:shadow-xl hover:shadow-purple-500/15'
                      : world.id === 'graph_city'
                      ? 'bg-slate-900/90 border-pink-500/40 hover:border-pink-400 hover:shadow-xl hover:shadow-pink-500/15'
                      : world.id === 'array_arena'
                      ? 'bg-slate-900/90 border-amber-500/40 hover:border-amber-400 hover:shadow-xl hover:shadow-amber-500/15'
                      : 'bg-slate-900/90 border-emerald-500/40 hover:border-emerald-400 hover:shadow-xl hover:shadow-emerald-500/15'
                    : 'bg-slate-950/70 border-slate-800 opacity-80 hover:border-slate-700'
                }`}
              >
                {/* World Number Tag */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div
                      className={`p-2.5 rounded-xl ${
                        isUnlocked
                          ? world.id === 'stack_volcano'
                            ? 'bg-red-950/80 text-red-400'
                            : world.id === 'queue_river'
                            ? 'bg-cyan-950/80 text-cyan-300'
                            : world.id === 'tree_valley'
                            ? 'bg-purple-950/80 text-purple-400'
                            : world.id === 'graph_city'
                            ? 'bg-pink-950/80 text-pink-400'
                            : world.id === 'array_arena'
                            ? 'bg-amber-950/80 text-amber-400'
                            : 'bg-emerald-950/80 text-emerald-400'
                          : 'bg-slate-900 text-slate-600'
                      }`}
                    >
                      {getWorldIcon(world.id)}
                    </div>
                    <div>
                      <span className="text-[11px] font-mono text-slate-400">
                        Sector 0{index + 1}
                      </span>
                      <h3 className="text-lg font-bold text-white">{world.name}</h3>
                    </div>
                  </div>

                  {isUnlocked ? (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        world.id === 'stack_volcano'
                          ? 'text-red-400 bg-red-950/80 border border-red-500/40'
                          : world.id === 'queue_river'
                          ? 'text-cyan-400 bg-cyan-950/80 border border-cyan-500/40'
                          : world.id === 'tree_valley'
                          ? 'text-purple-400 bg-purple-950/80 border border-purple-500/40'
                          : world.id === 'graph_city'
                          ? 'text-pink-400 bg-pink-950/80 border border-pink-500/40'
                          : world.id === 'array_arena'
                          ? 'text-amber-400 bg-amber-950/80 border border-amber-500/40'
                          : 'text-emerald-400 bg-emerald-950/80 border border-emerald-500/40'
                      }`}
                    >
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] font-bold text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">
                      <Lock className="w-3 h-3" />
                      COMING NEXT
                    </span>
                  )}
                </div>

                {/* DSA Topic & Description */}
                <div className="mb-4">
                  <div
                    className={`text-xs font-semibold mb-1 ${
                      world.id === 'stack_volcano'
                        ? 'text-red-300'
                        : world.id === 'queue_river'
                        ? 'text-cyan-300'
                        : world.id === 'tree_valley'
                        ? 'text-purple-300'
                        : world.id === 'graph_city'
                        ? 'text-pink-300'
                        : world.id === 'array_arena'
                        ? 'text-amber-300'
                        : 'text-emerald-300'
                    }`}
                  >
                    {world.dsaTopic}
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {world.description}
                  </p>
                </div>

                {/* Progress or Unlock Requirement */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  {isUnlocked ? (
                    <>
                      <div className="text-xs text-slate-400">
                        Levels:{' '}
                        <strong
                          className={
                            world.id === 'stack_volcano'
                              ? 'text-red-400'
                              : world.id === 'queue_river'
                              ? 'text-cyan-300'
                              : world.id === 'tree_valley'
                              ? 'text-purple-300'
                              : world.id === 'graph_city'
                              ? 'text-pink-300'
                              : world.id === 'array_arena'
                              ? 'text-amber-300'
                              : 'text-emerald-400'
                          }
                        >
                          {completedCount}/5
                        </strong>
                      </div>
                      <button
                        className={`flex items-center gap-1 text-xs font-bold ${
                          world.id === 'stack_volcano'
                            ? 'text-red-400 hover:text-red-300'
                            : world.id === 'queue_river'
                            ? 'text-cyan-400 hover:text-cyan-300'
                            : world.id === 'tree_valley'
                            ? 'text-purple-400 hover:text-purple-300'
                            : world.id === 'graph_city'
                            ? 'text-pink-400 hover:text-pink-300'
                            : world.id === 'array_arena'
                            ? 'text-amber-400 hover:text-amber-300'
                            : 'text-emerald-400 hover:text-emerald-300'
                        }`}
                      >
                        <span>Enter Sector</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </>
                  ) : (
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                      <Lock className="w-3 h-3 text-slate-600" />
                      <span>{world.unlockRequirement || 'Locked by Sector Sequence'}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* Footer with Secret Admin Link */}
      <footer className="mt-8 border-t border-slate-800/60 bg-slate-950/70 px-4 py-3 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>Algoria DSA Expedition · 6 Sectors · Master Data Structures & Algorithms Through Play</span>
        </div>
        <div className="flex items-center gap-3">
          {onOpenAdmin && (
            <button
              onClick={() => {
                playButtonClick();
                onOpenAdmin();
              }}
              className="flex items-center gap-1.5 text-slate-400 hover:text-cyan-400 px-2 py-1 rounded bg-slate-900/60 hover:bg-slate-900 border border-slate-800 transition-colors cursor-pointer"
              title="Secret Admin Console"
            >
              <Terminal className="w-3 h-3 text-cyan-400" />
              <span>Admin Console (/admin)</span>
            </button>
          )}
          <span>v2.5.0</span>
        </div>
      </footer>

      {/* Modal: Object Kingdom (OOP) locked dialog */}
      {showObjectKingdomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border-2 border-amber-500/50 rounded-2xl p-6 shadow-2xl text-center">
            {/* Close button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowObjectKingdomModal(false);
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-16 h-16 mx-auto mb-4 bg-amber-950/80 border-2 border-amber-500/60 rounded-2xl flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/20">
              <Lock className="w-8 h-8 stroke-[2.5]" />
            </div>

            <h3 className="text-xl font-black text-white mb-2">Object Kingdom is Locked</h3>
            <p className="text-sm text-amber-200/90 leading-relaxed mb-6 font-medium bg-amber-950/40 p-3 rounded-xl border border-amber-500/30">
              We are still working on that! Continue with world map.
            </p>

            <button
              onClick={() => {
                playButtonClick();
                setShowObjectKingdomModal(false);
              }}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 active:scale-95 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-500/30 transition-all cursor-pointer"
            >
              Continue with World Map
            </button>
          </div>
        </div>
      )}

      {/* Drawer: World Level Selector */}
      {selectedWorldForLevels && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div
            className={`relative w-full max-w-2xl bg-slate-900 border rounded-2xl p-6 shadow-2xl overflow-hidden ${
              selectedWorldForLevels === 'stack_volcano'
                ? 'border-red-500/40'
                : selectedWorldForLevels === 'queue_river'
                ? 'border-cyan-500/40'
                : selectedWorldForLevels === 'tree_valley'
                ? 'border-purple-500/40'
                : selectedWorldForLevels === 'graph_city'
                ? 'border-pink-500/40'
                : selectedWorldForLevels === 'array_arena'
                ? 'border-amber-500/40'
                : 'border-emerald-500/40'
            }`}
          >
            {/* Close Button */}
            <button
              onClick={() => {
                playButtonClick();
                setSelectedWorldForLevels(null);
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
              <div
                className={`p-3 rounded-xl ${
                  selectedWorldForLevels === 'stack_volcano'
                    ? 'bg-red-950/80 border border-red-500/40 text-red-400'
                    : selectedWorldForLevels === 'queue_river'
                    ? 'bg-cyan-950/80 border border-cyan-500/40 text-cyan-300'
                    : selectedWorldForLevels === 'tree_valley'
                    ? 'bg-purple-950/80 border border-purple-500/40 text-purple-400'
                    : selectedWorldForLevels === 'graph_city'
                    ? 'bg-pink-950/80 border border-pink-500/40 text-pink-400'
                    : selectedWorldForLevels === 'array_arena'
                    ? 'bg-amber-950/80 border border-amber-500/40 text-amber-400'
                    : 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-400'
                }`}
              >
                {selectedWorldForLevels === 'stack_volcano' ? (
                  <Flame className="w-7 h-7" />
                ) : selectedWorldForLevels === 'queue_river' ? (
                  <Waves className="w-7 h-7" />
                ) : selectedWorldForLevels === 'tree_valley' ? (
                  <GitBranch className="w-7 h-7" />
                ) : selectedWorldForLevels === 'graph_city' ? (
                  <Network className="w-7 h-7" />
                ) : selectedWorldForLevels === 'array_arena' ? (
                  <Boxes className="w-7 h-7" />
                ) : (
                  <Trees className="w-7 h-7" />
                )}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {selectedWorldForLevels === 'stack_volcano'
                    ? 'Stack Volcano'
                    : selectedWorldForLevels === 'queue_river'
                    ? 'Queue River'
                    : selectedWorldForLevels === 'tree_valley'
                    ? 'Tree Valley'
                    : selectedWorldForLevels === 'graph_city'
                    ? 'Graph City'
                    : selectedWorldForLevels === 'array_arena'
                    ? 'Array Arena'
                    : 'Loop Forest'}
                </h2>
                <p className="text-xs text-slate-400">
                  {selectedWorldForLevels === 'stack_volcano'
                    ? 'LIFO Operations · Push, Pop, Peek, Undo, and Word Reversal'
                    : selectedWorldForLevels === 'queue_river'
                    ? 'FIFO Operations · Enqueue, Dequeue, River Docks, and Priority VIP Scheduling'
                    : selectedWorldForLevels === 'tree_valley'
                    ? 'Binary Trees & BST · Preorder, Inorder, Postorder, BST Insertion, Search & Tree Height'
                    : selectedWorldForLevels === 'graph_city'
                    ? 'Graph Networks & Safe Zone Survival · Edges, BFS Waves, DFS Deep Paths, Dijkstra & Visited Sets'
                    : selectedWorldForLevels === 'array_arena'
                    ? '0-Indexed Memory, Bubble Sort, Race Tracks O(N) vs O(log N), Halving & Two Pointers'
                    : 'Subway Surfers-style side runner · Master loops through continuous motion'}
                </p>
              </div>
            </div>

            {/* Levels List */}
            <div className="space-y-3 mb-6 max-h-[50vh] overflow-y-auto pr-1">
              {(selectedWorldForLevels === 'stack_volcano'
                ? STACK_VOLCANO_LEVELS
                : selectedWorldForLevels === 'queue_river'
                ? QUEUE_RIVER_LEVELS
                : selectedWorldForLevels === 'tree_valley'
                ? TREE_VALLEY_LEVELS
                : selectedWorldForLevels === 'graph_city'
                ? GRAPH_CITY_LEVELS
                : selectedWorldForLevels === 'array_arena'
                ? ARRAY_ARENA_LEVELS
                : LOOP_FOREST_LEVELS
              ).map((lvl) => {
                const prefix = selectedWorldForLevels;
                const record = completedLevels[`${prefix}_${lvl.id}`];
                const starsEarned = record?.stars || 0;
                const isCleared = starsEarned > 0;

                const isUnlocked =
                  lvl.id === 1 || completedLevels[`${prefix}_${lvl.id - 1}`]?.stars > 0;

                return (
                  <div
                    key={lvl.id}
                    onClick={() => {
                      if (isUnlocked) {
                        playButtonClick();
                        const worldId = selectedWorldForLevels;
                        setSelectedWorldForLevels(null);
                        onSelectLevel(worldId, lvl.id);
                      } else {
                        playErrorSound();
                      }
                    }}
                    className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all cursor-pointer ${
                      isUnlocked
                        ? selectedWorldForLevels === 'stack_volcano'
                          ? 'bg-slate-950/80 border-slate-800 hover:border-red-500/50 hover:bg-slate-950'
                          : selectedWorldForLevels === 'queue_river'
                          ? 'bg-slate-950/80 border-slate-800 hover:border-cyan-500/50 hover:bg-slate-950'
                          : selectedWorldForLevels === 'tree_valley'
                          ? 'bg-slate-950/80 border-slate-800 hover:border-purple-500/50 hover:bg-slate-950'
                          : selectedWorldForLevels === 'graph_city'
                          ? 'bg-slate-950/80 border-slate-800 hover:border-pink-500/50 hover:bg-slate-950'
                          : selectedWorldForLevels === 'array_arena'
                          ? 'bg-slate-950/80 border-slate-800 hover:border-amber-500/50 hover:bg-slate-950'
                          : 'bg-slate-950/80 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-950'
                        : 'bg-slate-950/40 border-slate-900 opacity-60 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold font-mono text-sm ${
                          isCleared
                            ? selectedWorldForLevels === 'stack_volcano'
                              ? 'bg-red-950 border border-red-500/40 text-red-400'
                              : selectedWorldForLevels === 'queue_river'
                              ? 'bg-cyan-950 border border-cyan-500/40 text-cyan-300'
                              : selectedWorldForLevels === 'tree_valley'
                              ? 'bg-purple-950 border border-purple-500/40 text-purple-400'
                              : selectedWorldForLevels === 'graph_city'
                              ? 'bg-pink-950 border border-pink-500/40 text-pink-400'
                              : selectedWorldForLevels === 'array_arena'
                              ? 'bg-amber-950 border border-amber-500/40 text-amber-300'
                              : 'bg-emerald-950 border border-emerald-500/40 text-emerald-400'
                            : isUnlocked
                            ? 'bg-slate-800 text-white'
                            : 'bg-slate-900 text-slate-600'
                        }`}
                      >
                        {isUnlocked ? lvl.id : <Lock className="w-4 h-4" />}
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>{lvl.title}</span>
                          {isCleared && (
                            <span className="text-[10px] text-emerald-400 font-normal">
                              · Cleared
                            </span>
                          )}
                        </h4>
                        <div
                          className={`text-xs font-mono mt-0.5 ${
                            selectedWorldForLevels === 'stack_volcano'
                              ? 'text-orange-400'
                              : selectedWorldForLevels === 'graph_city'
                              ? 'text-pink-300'
                              : selectedWorldForLevels === 'array_arena'
                              ? 'text-amber-300'
                              : 'text-cyan-300'
                          }`}
                        >
                          {lvl.concept}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">{lvl.subtitle}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Stars */}
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= starsEarned
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-slate-800'
                            }`}
                          />
                        ))}
                      </div>

                      {/* Play Button */}
                      {isUnlocked && (
                        <div
                          className={`p-2 rounded-lg ${
                            selectedWorldForLevels === 'stack_volcano'
                              ? 'bg-red-600/30 text-red-300'
                              : selectedWorldForLevels === 'array_arena'
                              ? 'bg-amber-600/30 text-amber-300'
                              : selectedWorldForLevels === 'graph_city'
                              ? 'bg-pink-600/30 text-pink-300'
                              : 'bg-emerald-600/30 text-emerald-300'
                          }`}
                        >
                          <Play className="w-4 h-4 fill-current" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Footer */}
            <div className="text-center text-xs text-slate-500">
              {selectedWorldForLevels === 'stack_volcano'
                ? 'Conquer all 5 caldera levels to earn the Stack Climber badge!'
                : selectedWorldForLevels === 'array_arena'
                ? 'Master all 5 arena challenges to conquer Algoria Realm and claim the Grandmaster badge!'
                : 'Clear all 5 levels to unlock the next DSA sector and earn your mastery badge!'}
            </div>
          </div>
        </div>
      )}

      {/* Global Modals */}
      <LeaderboardModal
        isOpen={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
        currentUser={currentUser}
      />

      <BadgesModal
        isOpen={showBadges}
        onClose={() => setShowBadges(false)}
        userBadges={badges}
        completedLevels={completedLevels}
      />

      <StreakModal
        isOpen={showStreak}
        onClose={() => setShowStreak(false)}
        streakCount={currentStreak}
        streakDays={currentStreak}
        algoriaDust={algoriaDust}
        hasClaimedToday={hasClaimedToday}
        onClaimDustReward={handleClaimStreakDust}
      />
    </div>
  );
};
