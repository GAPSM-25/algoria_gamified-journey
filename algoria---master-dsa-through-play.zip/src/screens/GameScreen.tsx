import React, { useState, useEffect, useRef } from 'react';
import Phaser from 'phaser';
import { LoopForestScene } from '../game/scenes/LoopForestScene.ts';
import { StackVolcanoScene } from '../game/scenes/StackVolcanoScene.ts';
import { QueueRiverScene } from '../game/scenes/QueueRiverScene.ts';
import { TreeValleyScene } from '../game/scenes/TreeValleyScene.ts';
import { GraphCityScene } from '../game/scenes/GraphCityScene.ts';
import { ArrayArenaScene } from '../game/scenes/ArrayArenaScene.ts';
import { ObjectKingdomScene } from '../game/scenes/ObjectKingdomScene.ts';
import { LOOP_FOREST_LEVELS } from '../levels/loopForest.js';
import { STACK_VOLCANO_LEVELS } from '../levels/stackVolcano.js';
import { QUEUE_RIVER_LEVELS } from '../levels/queueRiver.js';
import { TREE_VALLEY_LEVELS } from '../levels/treeValley.js';
import { GRAPH_CITY_LEVELS } from '../levels/graphCity.js';
import { ARRAY_ARENA_LEVELS } from '../levels/arrayArena.js';
import { OBJECT_KINGDOM_LEVELS } from '../levels/objectKingdom.js';
import { GameHUD } from '../components/GameHUD.tsx';
import { NovaDialogue } from '../components/NovaDialogue.tsx';
import { LoopControlPanel } from '../components/LoopControlPanel.tsx';
import { StackControlPanel } from '../components/StackControlPanel.tsx';
import { QueueControlPanel } from '../components/QueueControlPanel.tsx';
import { TreeControlPanel } from '../components/TreeControlPanel.tsx';
import { GraphControlPanel } from '../components/GraphControlPanel.tsx';
import { ArrayControlPanel } from '../components/ArrayControlPanel.tsx';
import { ObjectKingdomControlPanel } from '../components/ObjectKingdomControlPanel.tsx';
import { CodeRecapModal } from '../components/CodeRecapModal.tsx';
import { NovaHelperSidebar } from '../components/NovaHelperSidebar.tsx';
import { CHARACTERS, recordLevelCompletion } from '../api/gameApi.js';
import { playButtonClick } from '../utils/audio.ts';
import { RotateCcw, ArrowLeft, Sparkles, Home } from 'lucide-react';

interface GameScreenProps {
  worldId: string;
  levelId: number;
  currentUser: any;
  onExitToMap: () => void;
  onGoHome?: () => void;
  onNextLevel: (nextWorldId: string, nextId: number) => void;
  onUserDataUpdated: (updatedUser: any) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  worldId,
  levelId,
  currentUser,
  onExitToMap,
  onGoHome,
  onNextLevel,
  onUserDataUpdated,
  isMuted,
  onToggleMute
}) => {
  const isVolcano = worldId === 'stack_volcano';
  const isQueue = worldId === 'queue_river';
  const isTree = worldId === 'tree_valley';
  const isGraph = worldId === 'graph_city';
  const isArena = worldId === 'array_arena';
  const isObjectKingdom = worldId === 'object_kingdom';
  const levelsList = isVolcano
    ? STACK_VOLCANO_LEVELS
    : isQueue
    ? QUEUE_RIVER_LEVELS
    : isTree
    ? TREE_VALLEY_LEVELS
    : isGraph
    ? GRAPH_CITY_LEVELS
    : isArena
    ? ARRAY_ARENA_LEVELS
    : isObjectKingdom
    ? OBJECT_KINGDOM_LEVELS
    : LOOP_FOREST_LEVELS;
  const levelData = (levelsList.find((l) => l.id === levelId) || levelsList[0]) as any;

  const charId = currentUser?.progress?.characterId || 'bit_byte';
  const charConfig = CHARACTERS.find((c) => c.id === charId) || CHARACTERS[0];

  const maxHearts = 3 + (charConfig.bonusHearts || 0);

  // Hint cooldown calculation based on passive perk
  const hintReduction = charConfig.hintCooldownReduction || 0; // 0.5 for Cyber Nova
  const maxHintCooldown = Math.max(5, Math.round(20 * (1 - hintReduction)));

  // Gameplay state
  const [hearts, setHearts] = useState<number>(maxHearts);
  const [currentTreesPassed, setCurrentTreesPassed] = useState<number>(0);
  const [coinsCollected, setCoinsCollected] = useState<number>(0);
  const [outerLoop, setOuterLoop] = useState<number | undefined>(undefined);
  const [innerLoop, setInnerLoop] = useState<number | undefined>(undefined);

  // Stack Volcano specific state
  const [currentStack, setCurrentStack] = useState<any[]>([]);
  const [peekedItem, setPeekedItem] = useState<any | null>(null);

  // Queue River specific state
  const [queueItems, setQueueItems] = useState<any[]>([]);
  const [queueLastAction, setQueueLastAction] = useState<string>('IDLE');
  const [queueCount, setQueueCount] = useState<number>(0);

  // Tree Valley specific state
  const [treeHarvestedValues, setTreeHarvestedValues] = useState<number[]>([]);
  const [treeCurrentNodeVal, setTreeCurrentNodeVal] = useState<number>(50);
  const [treeIncomingFruit, setTreeIncomingFruit] = useState<number | undefined>(undefined);
  const [treeSearchTarget, setTreeSearchTarget] = useState<number | undefined>(undefined);
  const [treeSearchPhase, setTreeSearchPhase] = useState<'search' | 'height'>('search');
  const [treeCount, setTreeCount] = useState<number>(0);

  // Graph City specific state
  const [graphCurrentNodeId, setGraphCurrentNodeId] = useState<string>('node_A');
  const [graphVisitedNodes, setGraphVisitedNodes] = useState<string[]>([]);
  const [graphAvailableNeighbors, setGraphAvailableNeighbors] = useState<string[]>([]);
  const [graphAccumulatedCost, setGraphAccumulatedCost] = useState<number>(0);
  const [graphSafeZoneRadius, setGraphSafeZoneRadius] = useState<number>(260);
  const [graphIsOutsideZone, setGraphIsOutsideZone] = useState<boolean>(false);
  const [graphCount, setGraphCount] = useState<number>(0);
  const [graphBfsQueue, setGraphBfsQueue] = useState<string[]>([]);
  const [graphDfsStack, setGraphDfsStack] = useState<string[]>([]);

  // Array Arena specific state
  const [arenaCurrentQueryIdx, setArenaCurrentQueryIdx] = useState<number>(0);
  const [arenaArrayData, setArenaArrayData] = useState<any[]>([]);
  const [arenaLow, setArenaLow] = useState<number>(0);
  const [arenaHigh, setArenaHigh] = useState<number>(8);
  const [arenaMid, setArenaMid] = useState<number>(4);
  const [arenaBotIndex, setArenaBotIndex] = useState<number>(0);
  const [arenaPlayerSteps, setArenaPlayerSteps] = useState<number>(0);
  const [arenaLeftPtr, setArenaLeftPtr] = useState<number>(0);
  const [arenaRightPtr, setArenaRightPtr] = useState<number>(5);
  const [arenaIsSorting, setArenaIsSorting] = useState<boolean>(false);
  const [arenaIsReplaying, setArenaIsReplaying] = useState<boolean>(false);
  const [arenaCount, setArenaCount] = useState<number>(0);

  // Object Kingdom specific state
  const [oopCount, setOopCount] = useState<number>(0);
  const [oopConsoleLogs, setOopConsoleLogs] = useState<string[]>([]);

  // Timer & Hint Cooldown
  const [hintCooldown, setHintCooldown] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);

  // Status & Nova dialogues
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [novaMood, setNovaMood] = useState<'happy' | 'excited' | 'curious' | 'serious' | 'surprised' | 'proud'>('happy');
  const [novaMessage, setNovaMessage] = useState<string>(levelData.novaIntro.message);
  const [showFailureModal, setShowFailureModal] = useState<boolean>(false);
  const [failureReason, setFailureReason] = useState<string>('');

  // Recap & Rewards modal
  const [showRecapModal, setShowRecapModal] = useState<boolean>(false);
  const [showNovaHelper, setShowNovaHelper] = useState<boolean>(false);
  const [starsEarned, setStarsEarned] = useState<number>(3);
  const [finalCompletionTime, setFinalCompletionTime] = useState<number>(0);
  const [xpEarned, setXpEarned] = useState<number>(100);
  const [coinsEarned, setCoinsEarned] = useState<number>(15);
  const [isWorldComplete, setIsWorldComplete] = useState<boolean>(false);

  // Phaser references
  const phaserContainerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const loopSceneRef = useRef<LoopForestScene | null>(null);
  const stackSceneRef = useRef<StackVolcanoScene | null>(null);
  const queueSceneRef = useRef<QueueRiverScene | null>(null);
  const treeSceneRef = useRef<TreeValleyScene | null>(null);
  const graphSceneRef = useRef<GraphCityScene | null>(null);
  const arenaSceneRef = useRef<ArrayArenaScene | null>(null);
  const objectKingdomSceneRef = useRef<ObjectKingdomScene | null>(null);

  // Hint cooldown countdown timer
  useEffect(() => {
    if (hintCooldown <= 0) return;
    const timer = setInterval(() => {
      setHintCooldown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [hintCooldown]);

  // Stopwatch for level completion speed
  useEffect(() => {
    if (!isTimerRunning) return;
    const interval = setInterval(() => {
      setElapsedTime((prev) => Math.round((prev + 0.1) * 10) / 10);
    }, 100);
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  // Reset state on level change
  useEffect(() => {
    setHearts(maxHearts);
    setCurrentTreesPassed(0);
    setCoinsCollected(0);
    setOuterLoop(undefined);
    setInnerLoop(undefined);
    setCurrentStack(levelData['initialStack'] ? [...levelData['initialStack']] : []);
    setPeekedItem(null);
    setQueueItems([]);
    setQueueLastAction('IDLE');
    setQueueCount(0);
    setTreeHarvestedValues([]);
    setTreeCurrentNodeVal(50);
    setTreeIncomingFruit(levelData?.fruitsToInsert?.[0]?.value);
    setTreeSearchTarget(levelData?.searchTargets?.[0]?.target);
    setTreeSearchPhase('search');
    setTreeCount(0);
    if (isGraph) {
      setGraphCurrentNodeId(levelData.startNodeId || 'node_A');
      setGraphVisitedNodes([levelData.startNodeId || 'node_A']);
      setGraphAvailableNeighbors([]);
      setGraphAccumulatedCost(0);
      setGraphCount(0);
      setGraphSafeZoneRadius(levelData.safeZone?.initialRadius || 260);
      setGraphIsOutsideZone(false);
      setGraphBfsQueue([]);
      setGraphDfsStack([]);
    }
    if (isArena) {
      setArenaCurrentQueryIdx(0);
      setArenaArrayData(levelData.initialArray || levelData.arrayData || []);
      setArenaLow(0);
      setArenaHigh(levelData.targetArray ? levelData.targetArray.length - 1 : 8);
      setArenaMid(Math.floor((levelData.targetArray ? levelData.targetArray.length - 1 : 8) / 2));
      setArenaBotIndex(0);
      setArenaPlayerSteps(0);
      setArenaLeftPtr(0);
      setArenaRightPtr(levelData.targetArray ? levelData.targetArray.length - 1 : 5);
      setArenaIsSorting(false);
      setArenaIsReplaying(false);
      setArenaCount(0);
    }
    if (isObjectKingdom) {
      setOopCount(0);
      setOopConsoleLogs([]);
    }
    setIsExecuting(false);
    setShowFailureModal(false);
    setShowRecapModal(false);
    setHintCooldown(0);
    setElapsedTime(0);
    setIsTimerRunning(true);
    setNovaMood(levelData.novaIntro.mood as any);
    setNovaMessage(levelData.novaIntro.message);
  }, [worldId, levelId, maxHearts, levelData, isGraph, isArena, isObjectKingdom]);

  // Boot Phaser Scene
  useEffect(() => {
    if (!phaserContainerRef.current) return;

    if (gameRef.current) {
      gameRef.current.destroy(true);
      gameRef.current = null;
      loopSceneRef.current = null;
      stackSceneRef.current = null;
      queueSceneRef.current = null;
      treeSceneRef.current = null;
      graphSceneRef.current = null;
      arenaSceneRef.current = null;
      objectKingdomSceneRef.current = null;
    }
    if (phaserContainerRef.current) {
      phaserContainerRef.current.innerHTML = '';
    }

    let activeScene: Phaser.Scene;

    if (isVolcano) {
      const scene = new StackVolcanoScene();
      stackSceneRef.current = scene;
      activeScene = scene;
    } else if (isQueue) {
      const scene = new QueueRiverScene();
      queueSceneRef.current = scene;
      activeScene = scene;
    } else if (isTree) {
      const scene = new TreeValleyScene();
      treeSceneRef.current = scene;
      activeScene = scene;
    } else if (isGraph) {
      const scene = new GraphCityScene();
      graphSceneRef.current = scene;
      activeScene = scene;
    } else if (isArena) {
      const scene = new ArrayArenaScene();
      arenaSceneRef.current = scene;
      activeScene = scene;
    } else if (isObjectKingdom) {
      const scene = new ObjectKingdomScene();
      objectKingdomSceneRef.current = scene;
      activeScene = scene;
    } else {
      const scene = new LoopForestScene();
      loopSceneRef.current = scene;
      activeScene = scene;
    }

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      parent: phaserContainerRef.current,
      width: 860,
      height: 360,
      transparent: true,
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { x: 0, y: 0 },
          debug: false
        }
      },
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      },
      scene: [activeScene]
    };

    const game = new Phaser.Game(config);
    gameRef.current = game;

    if (isVolcano) {
      game.scene.start('StackVolcanoScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: {
          onStackChanged: (stack: any[]) => {
            setCurrentStack(stack);
          },
          onPeekTriggered: (top: any) => {
            setPeekedItem(top);
            setNovaMood('proud');
            setNovaMessage(`Peek successful! The top rock is "${top?.label}". Stack length remains ${currentStack.length}!`);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Re-evaluating LIFO logic!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else if (isQueue) {
      game.scene.start('QueueRiverScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        speedMultiplier: charConfig.speedMultiplier || 1.0,
        callbacks: {
          onProgressUpdate: (data: any) => {
            if (data.current !== undefined) setQueueCount(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
          },
          onQueueUpdated: (data: { queue: any[]; lastAction: string }) => {
            setQueueItems(data.queue);
            setQueueLastAction(data.lastAction);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Let's maintain proper FIFO discipline!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else if (isTree) {
      game.scene.start('TreeValleyScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: {
          onProgressUpdate: (data: any) => {
            if (data.current !== undefined) setTreeCount(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
            if (data.currentNodeVal !== undefined) setTreeCurrentNodeVal(data.currentNodeVal);
            if (data.harvestedValues) setTreeHarvestedValues(data.harvestedValues);
            if (data.incomingFruit !== undefined) setTreeIncomingFruit(data.incomingFruit);
            if (data.searchTarget !== undefined) setTreeSearchTarget(data.searchTarget);
          },
          onTreeStateUpdated: (data: any) => {
            if (data.currentNodeVal !== undefined) setTreeCurrentNodeVal(data.currentNodeVal);
            if (data.harvestedValues) setTreeHarvestedValues(data.harvestedValues);
            if (data.incomingFruit !== undefined) setTreeIncomingFruit(data.incomingFruit);
            if (data.searchTarget !== undefined) setTreeSearchTarget(data.searchTarget);
            if (data.searchPhase) setTreeSearchPhase(data.searchPhase);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Let's climb carefully and observe the tree structure!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else if (isGraph) {
      game.scene.start('GraphCityScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: {
          onProgressUpdate: (data: any) => {
            if (data.current !== undefined) setGraphCount(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
            if (data.currentNodeId) setGraphCurrentNodeId(data.currentNodeId);
            if (data.visitedNodes) setGraphVisitedNodes(data.visitedNodes);
            if (data.availableNeighbors) setGraphAvailableNeighbors(data.availableNeighbors);
            if (data.accumulatedCost !== undefined) setGraphAccumulatedCost(data.accumulatedCost);
            if (data.safeZoneRadius !== undefined) setGraphSafeZoneRadius(data.safeZoneRadius);
            if (data.isOutsideZone !== undefined) setGraphIsOutsideZone(data.isOutsideZone);
            if (data.bfsQueue) setGraphBfsQueue(data.bfsQueue);
            if (data.dfsStack) setGraphDfsStack(data.dfsStack);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Recalibrating route matrix!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else if (isArena) {
      game.scene.start('ArrayArenaScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: {
          onProgressUpdate: (data: any) => {
            if (data.current !== undefined) setArenaCount(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
            if (data.currentQueryIndex !== undefined) setArenaCurrentQueryIdx(data.currentQueryIndex);
            if (data.currentArray) setArenaArrayData(data.currentArray);
            if (data.low !== undefined) setArenaLow(data.low);
            if (data.high !== undefined) setArenaHigh(data.high);
            if (data.mid !== undefined) setArenaMid(data.mid);
            if (data.botIndex !== undefined) setArenaBotIndex(data.botIndex);
            if (data.playerSteps !== undefined) setArenaPlayerSteps(data.playerSteps);
            if (data.leftPtr !== undefined) setArenaLeftPtr(data.leftPtr);
            if (data.rightPtr !== undefined) setArenaRightPtr(data.rightPtr);
            if (data.isSorting !== undefined) setArenaIsSorting(data.isSorting);
            if (data.isReplaying !== undefined) setArenaIsReplaying(data.isReplaying);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onNovaSpeak: (message: string, mood: any = 'happy') => {
            setNovaMessage(message);
            setNovaMood(mood);
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Array bounds or conditions violated! Let's examine our indices!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else if (isObjectKingdom) {
      game.scene.start('ObjectKingdomScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: {
          onProgressUpdate: (data: any) => {
            if (data.current !== undefined) setOopCount(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
            if (data.consoleLog) setOopConsoleLogs(data.consoleLog);
          },
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Review the OOP contract specification!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    } else {
      game.scene.start('LoopForestScene', {
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        speedMultiplier: charConfig.speedMultiplier || 1.0,
        callbacks: {
          onProgressUpdate: (data: any) => {
            setCurrentTreesPassed(data.current);
            if (data.coins !== undefined) setCoinsCollected(data.coins);
            if (data.outerLoop !== undefined) setOuterLoop(data.outerLoop);
            if (data.innerLoop !== undefined) setInnerLoop(data.innerLoop);
          },
          onJumpExecuted: () => {},
          onCoinCollected: (totalCoins: number) => {
            setCoinsCollected(totalCoins);
          },
          onHeartLost: () => {
            setHearts((prev) => Math.max(0, prev - 1));
          },
          onLevelFailed: (reason: string) => {
            setIsTimerRunning(false);
            setIsExecuting(false);
            setNovaMood('surprised');
            setNovaMessage(`${reason} Let's adjust our loop logic and try again!`);
            setFailureReason(reason);
            setShowFailureModal(true);
          },
          onLevelComplete: (stats: any) => {
            handleComplete(stats);
          }
        }
      });
    }

    const handleComplete = async (stats: any) => {
      setIsTimerRunning(false);
      setIsExecuting(false);

      const timeTaken = stats.completionTime || elapsedTime;
      setFinalCompletionTime(timeTaken);

      const targetTime = levelData['targetTime'] || 20;
      const healthBonus = hearts >= maxHearts - 1;
      const speedBonus = timeTaken <= targetTime;

      let calculatedStars = 1;
      if (healthBonus) calculatedStars += 1;
      if (speedBonus) calculatedStars += 1;
      calculatedStars = Math.min(3, Math.max(1, calculatedStars));

      const baseXP = 150 * levelId;
      const finalXP = Math.round(baseXP * (charConfig.xpMultiplier || 1.0));
      const finalCoins = stats.coinsCollected || 15;

      setStarsEarned(calculatedStars);
      setXpEarned(finalXP);
      setCoinsEarned(finalCoins);

      try {
        if (currentUser?.username) {
          const res = await recordLevelCompletion(currentUser.username, {
            worldId,
            levelId: levelData.id,
            stars: calculatedStars,
            xpGained: finalXP,
            coinsGained: finalCoins,
            stats: {
              ...stats,
              completionTime: timeTaken,
              heartsLeft: hearts
            }
          });

          if (
            (worldId === 'loop_forest' && res?.newlyAwardedBadge === 'loop_master') ||
            (worldId === 'stack_volcano' && res?.newlyAwardedBadge === 'stack_climber') ||
            (worldId === 'queue_river' && res?.newlyAwardedBadge === 'queue_captain') ||
            (worldId === 'tree_valley' && res?.newlyAwardedBadge === 'tree_whisperer')
          ) {
            setIsWorldComplete(true);
          }
          if (res?.progress) {
            onUserDataUpdated({ ...currentUser, progress: res.progress });
          }
        }
      } catch (e) {
        console.error('Failed to record completion', e);
      }

      setShowRecapModal(true);
    };

    return () => {
      if (gameRef.current) {
        gameRef.current.destroy(true);
        gameRef.current = null;
        loopSceneRef.current = null;
        stackSceneRef.current = null;
        queueSceneRef.current = null;
        treeSceneRef.current = null;
        graphSceneRef.current = null;
        arenaSceneRef.current = null;
      }
      if (phaserContainerRef.current) {
        phaserContainerRef.current.innerHTML = '';
      }
    };
  }, [worldId, levelId, charId, levelData, maxHearts, charConfig, isVolcano, isQueue, isTree, isGraph, isArena]);

  // Restart level
  const handleRetry = () => {
    setShowFailureModal(false);
    setShowRecapModal(false);
    setIsExecuting(false);
    setHearts(maxHearts);
    setCurrentTreesPassed(0);
    setCoinsCollected(0);
    setOuterLoop(undefined);
    setInnerLoop(undefined);
    setCurrentStack(levelData['initialStack'] ? [...levelData['initialStack']] : []);
    setPeekedItem(null);
    setQueueItems([]);
    setQueueLastAction('IDLE');
    setQueueCount(0);
    setTreeHarvestedValues([]);
    setTreeCurrentNodeVal(50);
    setTreeIncomingFruit(levelData?.fruitsToInsert?.[0]?.value);
    setTreeSearchTarget(levelData?.searchTargets?.[0]?.target);
    setTreeSearchPhase('search');
    setTreeCount(0);
    if (isGraph) {
      setGraphCurrentNodeId(levelData.startNodeId || 'node_A');
      setGraphVisitedNodes([levelData.startNodeId || 'node_A']);
      setGraphAvailableNeighbors([]);
      setGraphAccumulatedCost(0);
      setGraphCount(0);
      setGraphSafeZoneRadius(levelData.safeZone?.initialRadius || 260);
      setGraphIsOutsideZone(false);
      setGraphBfsQueue([]);
      setGraphDfsStack([]);
    }
    if (isArena) {
      setArenaCurrentQueryIdx(0);
      setArenaArrayData(levelData.initialArray || levelData.arrayData || []);
      setArenaLow(0);
      setArenaHigh(levelData.targetArray ? levelData.targetArray.length - 1 : 8);
      setArenaMid(Math.floor((levelData.targetArray ? levelData.targetArray.length - 1 : 8) / 2));
      setArenaBotIndex(0);
      setArenaPlayerSteps(0);
      setArenaLeftPtr(0);
      setArenaRightPtr(levelData.targetArray ? levelData.targetArray.length - 1 : 5);
      setArenaIsSorting(false);
      setArenaIsReplaying(false);
      setArenaCount(0);
    }
    setElapsedTime(0);
    setIsTimerRunning(true);
    setNovaMood(levelData.novaIntro.mood as any);
    setNovaMessage(levelData.novaIntro.message);

    if (isVolcano && stackSceneRef.current) {
      stackSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: stackSceneRef.current['callbacks']
      });
    } else if (isQueue && queueSceneRef.current) {
      queueSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        speedMultiplier: charConfig.speedMultiplier || 1.0,
        callbacks: queueSceneRef.current['callbacks']
      });
    } else if (isTree && treeSceneRef.current) {
      treeSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: treeSceneRef.current['callbacks']
      });
    } else if (isGraph && graphSceneRef.current) {
      graphSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: graphSceneRef.current['callbacks']
      });
    } else if (isArena && arenaSceneRef.current) {
      arenaSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: arenaSceneRef.current['callbacks']
      });
    } else if (isObjectKingdom && objectKingdomSceneRef.current) {
      objectKingdomSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        callbacks: objectKingdomSceneRef.current['callbacks']
      });
    } else if (loopSceneRef.current) {
      loopSceneRef.current.scene.restart({
        levelConfig: levelData,
        characterId: charId,
        coinMultiplier: charConfig.coinMultiplier || 1,
        speedMultiplier: charConfig.speedMultiplier || 1.0,
        callbacks: loopSceneRef.current['callbacks']
      });
    }
  };

  // Array Arena controls
  const handleSlotPick = (index: number) => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.handleSlotClick(index);
    }
  };

  const handleBubbleStep = () => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.stepBubbleSort();
    }
  };

  const handleBubbleAutoRun = () => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.autoRunBubbleSort();
    }
  };

  const handleRaceStep = () => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.stepBinarySearchRace();
    }
  };

  const handleHalveChoice = (choice: 'left' | 'right' | 'found') => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.halveBinarySearch(choice);
    }
  };

  const handleTwoPointersSwap = () => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.stepTwoPointersSwap();
    }
  };

  const handleNovaReplay = () => {
    if (arenaSceneRef.current) {
      arenaSceneRef.current.runNovaReplay();
    } else {
      setNovaMood('excited');
      setNovaMessage(`Nova Replay Demo: Reviewing algorithm steps for ${levelData.title}! Follow along with the code logic!`);
    }
  };

  // Graph City movement control
  const handleGraphMoveToNode = (targetNodeId: string) => {
    if (graphSceneRef.current) {
      graphSceneRef.current.triggerMoveToNode(targetNodeId);
    }
  };

  // Stack Volcano push/pop/peek controls
  const handleStackPush = (rockData: any) => {
    if (stackSceneRef.current) {
      stackSceneRef.current.pushRock(rockData);
    }
  };

  const handleStackPop = () => {
    if (stackSceneRef.current) {
      stackSceneRef.current.popRock();
    }
  };

  const handleStackPeek = () => {
    if (stackSceneRef.current) {
      stackSceneRef.current.peekTop();
    }
  };

  // Queue River snake direction and boat dispatch controls
  const handleSnakeDirection = (dir: 'up' | 'down' | 'left' | 'right') => {
    if (queueSceneRef.current) {
      queueSceneRef.current.setDirection(dir);
    }
  };

  const handleDispatchBoat = (boatId?: string) => {
    if (queueSceneRef.current) {
      queueSceneRef.current.handleBoatTapped(boatId);
    }
  };

  // Tree Valley controls
  const handleTriggerGhostPath = () => {
    if (treeSceneRef.current) {
      treeSceneRef.current.playGhostPathAnimation();
    }
  };

  const handleTreeNodeClick = (val: number) => {
    if (treeSceneRef.current) {
      treeSceneRef.current.handleNodeClicked(val);
    }
  };

  const handleTreeNavigateChoice = (dir: 'left' | 'right') => {
    if (treeSceneRef.current) {
      treeSceneRef.current.navigateChoice(dir);
    }
  };

  const handleTreeConfirmTargetFound = () => {
    if (treeSceneRef.current) {
      treeSceneRef.current.confirmSearchTargetFound();
    }
  };

  const handleTreeSubmitHeight = (h: number) => {
    if (treeSceneRef.current) {
      treeSceneRef.current.submitTreeHeightAnswer(h);
    }
  };

  // Object Kingdom controls
  const handleInstantiateRobot = (idx: number) => {
    objectKingdomSceneRef.current?.executeInstantiateRobot(idx);
  };

  const handleTestEncapsulation = (idx: number) => {
    objectKingdomSceneRef.current?.executeEncapsulationTest(idx);
  };

  const handleDeriveInheritance = (idx: number) => {
    objectKingdomSceneRef.current?.executeInheritanceDerivation(idx);
  };

  const handlePolymorphicDispatch = (idx: number) => {
    objectKingdomSceneRef.current?.executePolymorphicDispatch(idx);
  };

  const handleImplementContract = (idx: number) => {
    objectKingdomSceneRef.current?.executeContractMethod(idx);
  };

  // Keyboard navigation support for Tree Valley
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isTree && treeSceneRef.current) {
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          treeSceneRef.current.navigateChoice('left');
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          treeSceneRef.current.navigateChoice('right');
        } else if (e.key === 'Enter' || e.key === ' ') {
          if (treeSearchPhase === 'search') {
            e.preventDefault();
            treeSceneRef.current.confirmSearchTargetFound();
          }
        } else if (e.key === 'g' || e.key === 'G') {
          treeSceneRef.current.playGhostPathAnimation();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isTree, treeSearchPhase]);

  // Global key listener to go back to map when pressing Escape
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onExitToMap();
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [onExitToMap]);

  // Loop Forest controls
  const handleExecuteScript = (commands: any[]) => {
    setIsExecuting(true);
    setNovaMood('excited');
    setNovaMessage('Running loop sequence in real time! Watch the algorithmic iteration at work!');
    if (loopSceneRef.current) {
      loopSceneRef.current.executeAutomatedScript(commands);
    }
  };

  const handleManualJump = () => {
    if (loopSceneRef.current) {
      loopSceneRef.current.triggerPlayerJump();
    }
  };

  const handleHint = () => {
    if (hintCooldown > 0) return;
    setHintCooldown(maxHintCooldown);
    setNovaMood('curious');
    setNovaMessage(levelData.hint);
    playButtonClick();
  };

  return (
    <div className="min-h-screen w-full bg-[#0b071a] text-slate-100 flex flex-col justify-between overflow-x-hidden">
      {/* HUD Header */}
      <GameHUD
        hearts={hearts}
        maxHearts={maxHearts}
        xp={currentUser?.progress?.xp || 0}
        coins={(currentUser?.progress?.coins || 0) + coinsCollected}
        stars={currentUser?.progress?.completedLevels?.[`${worldId}_${levelId}`]?.stars || 0}
        currentProgress={
          isVolcano
            ? currentStack.length
            : isQueue
            ? queueCount
            : isTree
            ? treeCount
            : isGraph
            ? graphCount
            : isArena
            ? arenaCount
            : isObjectKingdom
            ? oopCount
            : currentTreesPassed
        }
        totalTarget={levelData['targetCount'] || levelData['treeCount'] || 5}
        levelTitle={levelData.title}
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onHint={handleHint}
        hintCooldown={hintCooldown}
        maxHintCooldown={maxHintCooldown}
        elapsedTime={elapsedTime}
        targetTime={levelData['targetTime']}
        onRetry={handleRetry}
        onExitToMap={onExitToMap}
        onGoHome={onGoHome}
        outerLoop={outerLoop}
        innerLoop={innerLoop}
        onNovaReplay={handleNovaReplay}
        characterId={charId}
        onOpenNovaHelper={() => setShowNovaHelper(true)}
      />

      {/* Main Play Area */}
      <main className="max-w-5xl w-full mx-auto px-3 sm:px-6 py-2 sm:py-4 flex flex-col gap-3 flex-1 justify-center">
        {/* Quick Navigation / Back Breadcrumbs */}
        <div className="flex items-center justify-between text-xs px-1">
          <div className="flex items-center gap-2">
            {onGoHome && (
              <button
                onClick={() => {
                  playButtonClick();
                  onGoHome();
                }}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-cyan-300 hover:text-white transition-all cursor-pointer group active:scale-95"
                title="Return to Home Page"
              >
                <Home className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
                <span className="font-semibold">Home</span>
              </button>
            )}

            <button
              onClick={() => {
                playButtonClick();
                onExitToMap();
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer group"
              title="Go back to the map selection"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-cyan-400 group-hover:-translate-x-0.5 transition-transform" />
              <span className="font-semibold text-cyan-300">Map</span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">{levelData.title}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playButtonClick();
                setShowNovaHelper((prev) => !prev);
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-purple-950/90 to-cyan-950/90 hover:from-purple-900 hover:to-cyan-900 border border-purple-500/40 text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm hover:border-cyan-400"
              title="Toggle Nova Helper Sidebar"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>{showNovaHelper ? 'Close Helper' : 'Nova Helper'}</span>
            </button>
            <span className="text-[11px] text-slate-500 hidden sm:inline font-mono">
              Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">Esc</kbd> for map
            </span>
          </div>
        </div>

        {/* Nova Guide Dialogue */}
        <NovaDialogue
          message={novaMessage}
          mood={novaMood}
          speakerTitle={`Nova (${charConfig.name}) · Mission Control`}
          characterId={charId}
          typingSpeed={18}
          className="w-full"
        />

        {/* Phaser 2D Canvas Container */}
        <div
          className={`relative w-full aspect-[860/360] max-h-[380px] bg-slate-950/90 rounded-2xl border overflow-hidden shadow-2xl flex items-center justify-center ${
            isVolcano
              ? 'border-red-500/40 glow-amber'
              : isQueue
              ? 'border-cyan-500/40 glow-cyan'
              : isTree
              ? 'border-purple-500/50 glow-purple'
              : isGraph
              ? 'border-pink-500/50 glow-pink'
              : isArena
              ? 'border-amber-500/50 glow-amber'
              : 'border-purple-500/30 glow-purple'
          }`}
        >
          <div ref={phaserContainerRef} className="w-full h-full" />
        </div>

        {/* Dynamic Interactive Control Panel */}
        {isVolcano ? (
          <StackControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            currentStack={currentStack}
            onPush={handleStackPush}
            onPop={handleStackPop}
            onPeek={handleStackPeek}
            peekedItem={peekedItem}
          />
        ) : isQueue ? (
          <QueueControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            onSnakeDirection={handleSnakeDirection}
            onDispatchBoat={handleDispatchBoat}
            queueItems={queueItems}
            lastAction={queueLastAction}
            targetCount={levelData.targetCount || 5}
            currentCount={queueCount}
          />
        ) : isTree ? (
          <TreeControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            traversalMode={levelData.traversalMode}
            expectedSequence={levelData.expectedSequence}
            harvestedValues={treeHarvestedValues}
            currentNodeVal={treeCurrentNodeVal}
            incomingFruit={treeIncomingFruit}
            searchTarget={treeSearchTarget}
            searchPhase={treeSearchPhase}
            targetCount={levelData.targetCount || 7}
            currentCount={treeCount}
            onTriggerGhostPath={handleTriggerGhostPath}
            onNodeClick={handleTreeNodeClick}
            onNavigateChoice={handleTreeNavigateChoice}
            onConfirmTargetFound={handleTreeConfirmTargetFound}
            onSubmitTreeHeight={handleTreeSubmitHeight}
          />
        ) : isGraph ? (
          <GraphControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            currentNodeId={graphCurrentNodeId}
            availableNeighbors={graphAvailableNeighbors}
            visitedNodes={graphVisitedNodes}
            accumulatedCost={graphAccumulatedCost}
            optimalCost={levelData.optimalCost}
            safeZoneRadius={graphSafeZoneRadius}
            isOutsideZone={graphIsOutsideZone}
            targetCount={levelData.targetCount || 1}
            currentCount={graphCount}
            nodes={levelData.nodes || []}
            edges={levelData.edges || []}
            bfsQueue={graphBfsQueue}
            dfsStack={graphDfsStack}
            onMoveToNode={handleGraphMoveToNode}
          />
        ) : isArena ? (
          <ArrayControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            targetCount={levelData.targetCount || 5}
            currentCount={arenaCount}
            arrayData={levelData.arrayData || arenaArrayData}
            currentQuery={levelData.queries ? levelData.queries[arenaCurrentQueryIdx] : undefined}
            currentQueryIdx={arenaCurrentQueryIdx}
            totalQueries={levelData.queries ? levelData.queries.length : 4}
            low={arenaLow}
            high={arenaHigh}
            mid={arenaMid}
            botIndex={arenaBotIndex}
            playerSteps={arenaPlayerSteps}
            leftPtr={arenaLeftPtr}
            rightPtr={arenaRightPtr}
            isSorting={arenaIsSorting}
            isReplaying={arenaIsReplaying}
            onSlotPick={handleSlotPick}
            onBubbleStep={handleBubbleStep}
            onBubbleAutoRun={handleBubbleAutoRun}
            onRaceStep={handleRaceStep}
            onHalveChoice={handleHalveChoice}
            onTwoPointersSwap={handleTwoPointersSwap}
            onNovaReplay={handleNovaReplay}
          />
        ) : isObjectKingdom ? (
          <ObjectKingdomControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            targetCount={levelData.targetCount || 3}
            currentCount={oopCount}
            consoleLogs={oopConsoleLogs}
            onInstantiateRobot={handleInstantiateRobot}
            onTestEncapsulation={handleTestEncapsulation}
            onDeriveInheritance={handleDeriveInheritance}
            onPolymorphicDispatch={handlePolymorphicDispatch}
            onImplementContract={handleImplementContract}
          />
        ) : (
          <LoopControlPanel
            key={`${worldId}_${levelId}`}
            levelId={levelId}
            levelType={levelData.type}
            onExecuteScript={handleExecuteScript}
            onManualJump={handleManualJump}
            isExecuting={isExecuting}
            targetCount={levelData['treeCount'] || 5}
          />
        )}
      </main>

      {/* Failure Modal */}
      {showFailureModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-slate-900 border border-red-500/50 rounded-2xl p-6 shadow-2xl text-center">
            <h3 className="text-xl font-bold text-red-400 mb-2">Operation Interrupted!</h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              {failureReason || levelData.failureMessage}
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-2.5">
              <button
                onClick={() => {
                  playButtonClick();
                  handleRetry();
                }}
                className="w-full py-3 bg-gradient-to-r from-red-600 to-purple-600 hover:from-red-500 hover:to-purple-500 active:scale-95 text-white font-bold text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Retry Challenge</span>
              </button>

              <button
                onClick={() => {
                  playButtonClick();
                  setShowFailureModal(false);
                  onExitToMap();
                }}
                className="w-full py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-cyan-300 hover:text-white font-bold text-sm rounded-xl border border-slate-700 hover:border-cyan-500/40 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-cyan-400" />
                <span>Back to Map</span>
              </button>

              {onGoHome && (
                <button
                  onClick={() => {
                    playButtonClick();
                    setShowFailureModal(false);
                    onGoHome();
                  }}
                  className="w-full py-3 bg-slate-900 hover:bg-slate-800 active:scale-95 text-slate-300 hover:text-white font-bold text-sm rounded-xl border border-slate-800 hover:border-cyan-500/40 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Home className="w-4 h-4 text-cyan-400" />
                  <span>Home</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Code Recap Modal on Level Victory */}
      <CodeRecapModal
        isOpen={showRecapModal}
        levelData={levelData}
        stars={starsEarned}
        xpGained={xpEarned}
        coinsGained={coinsEarned}
        completionTime={finalCompletionTime}
        targetTime={levelData['targetTime']}
        heartsLeft={hearts}
        maxHearts={maxHearts}
        isWorldComplete={isWorldComplete}
        worldId={worldId}
        characterId={charId}
        onNextLevel={() => {
          setShowRecapModal(false);
          if (levelId < 5) {
            onNextLevel(worldId, levelId + 1);
          } else {
            onExitToMap();
          }
        }}
        onReplay={handleRetry}
        onExitToMap={onExitToMap}
        onGoHome={onGoHome}
      />

      {/* Collapsible Nova Helper Sidebar with Voice Audio Guide */}
      <NovaHelperSidebar
        isOpen={showNovaHelper}
        onToggle={() => setShowNovaHelper((prev) => !prev)}
        worldId={worldId}
        levelId={levelId}
        levelData={levelData}
        characterId={charId}
        isMuted={isMuted}
      />
    </div>
  );
};
