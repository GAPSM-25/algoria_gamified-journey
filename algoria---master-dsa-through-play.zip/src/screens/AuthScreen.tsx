import React, { useState } from 'react';
import { ArrowLeft, User, Lock, Sparkles, LogIn, UserPlus } from 'lucide-react';
import { login, signup, loginAsGuest } from '../api/gameApi.js';
import { playButtonClick, playErrorSound, playSuccessSound } from '../utils/audio.ts';

interface AuthScreenProps {
  onSuccess: (user: any) => void;
  onBack: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onSuccess, onBack }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      let user;
      if (mode === 'signup') {
        user = await signup(username, password);
      } else {
        user = await login(username, password);
      }
      playSuccessSound();
      onSuccess(user);
    } catch (err: any) {
      playErrorSound();
      setError(err?.message || 'Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestPlay = async () => {
    setIsLoading(true);
    try {
      const guest = await loginAsGuest();
      playSuccessSound();
      onSuccess(guest);
    } catch (err: any) {
      setError(err?.message || 'Failed to start guest session.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 bg-[#050814] text-slate-100 overflow-hidden selection:bg-cyan-500 selection:text-slate-950">
      {/* Background Ambient Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[800px] h-[500px] rounded-full opacity-25 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(6, 182, 212, 0.4) 0%, rgba(168, 85, 247, 0.25) 50%, transparent 75%)'
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-[450px] h-[450px] rounded-full opacity-15 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(168, 85, 247, 0.35) 0%, transparent 70%)'
          }}
        />
      </div>

      <div className="relative z-10 w-full max-w-md bg-slate-950/75 border border-blue-900/40 hover:border-cyan-500/40 transition-colors rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Back Button */}
        <button
          onClick={() => {
            playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        {/* Title */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#081734] border border-cyan-500/40 text-cyan-300 text-[11px] font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>ALGORIA EXPEDITION IDENTITY</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {mode === 'signup' ? 'Create Explorer Account' : 'Welcome Back, Explorer'}
          </h2>
          <p className="text-xs text-slate-400 mt-1.5">
            Cloud synced to MongoDB Atlas · Real-Time Progress Persistence
          </p>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex bg-slate-900/90 p-1 rounded-2xl mb-6 border border-slate-800">
          <button
            type="button"
            onClick={() => {
              playButtonClick();
              setMode('signup');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'signup'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign Up
          </button>
          <button
            type="button"
            onClick={() => {
              playButtonClick();
              setMode('login');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Log In
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs leading-relaxed">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Explorer Codename
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-cyan-400 absolute left-3.5 top-3" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. pallavi"
                className="w-full bg-slate-900/80 border border-slate-800 focus:border-cyan-400 rounded-xl pl-10 pr-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Passcode
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-cyan-400 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 4 characters"
                className="w-full bg-slate-900/80 border border-slate-800 focus:border-cyan-400 rounded-xl pl-10 pr-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-fuchsia-500 hover:brightness-110 active:scale-95 text-slate-950 font-black text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            {mode === 'signup' ? (
              <>
                <UserPlus className="w-4 h-4 stroke-[2.5]" />
                <span>Create Account</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4 stroke-[2.5]" />
                <span>Enter Algoria</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Guest Play Option */}
        <div className="mt-6 pt-5 border-t border-slate-800 text-center">
          <p className="text-xs text-slate-500 mb-2.5">Want to jump straight in without an account?</p>
          <button
            type="button"
            onClick={handleGuestPlay}
            disabled={isLoading}
            className="w-full py-2.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Play Instantly as Guest</span>
          </button>
        </div>
      </div>
    </div>
  );
};
