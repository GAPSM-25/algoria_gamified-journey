import React, { useState } from 'react';
import {
  Compass,
  BookOpen,
  Trophy,
  ChevronDown,
  Play,
  Gamepad2,
  Star,
  ArrowRight,
  Check,
  Shield,
  Volume2,
  VolumeX,
  LogOut,
  Sparkles,
  Flame,
  Zap
} from 'lucide-react';
import { CHARACTERS, selectCharacter } from '../api/gameApi.js';
import { playButtonClick, playSuccessSound } from '../utils/audio.ts';

interface HomeScreenProps {
  onStartAdventure: () => void;
  onOpenAuth: () => void;
  onPlayAsGuest?: () => void;
  onOpenCharacterSelect?: () => void;
  onSelectAvatar?: (charId: string) => void;
  onOpenLeaderboard?: () => void;
  onOpenLearningPaths?: () => void;
  onSelectMode?: (worldId: string) => void;
  onOpenAdmin?: () => void;
  onLogout?: () => void;
  currentUser: any;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onStartAdventure,
  onOpenAuth,
  onOpenLeaderboard,
  onOpenLearningPaths,
  onSelectMode,
  onOpenAdmin,
  onLogout,
  onSelectAvatar,
  currentUser,
  isMuted,
  onToggleMute
}) => {
  // In the target design, 'Nova' (cyber_nova) is selected
  const defaultCharId = currentUser?.progress?.characterId || 'cyber_nova';
  const [activeCharId, setActiveCharId] = useState<string>(defaultCharId);
  const [showUserDropdown, setShowUserDropdown] = useState<boolean>(false);

  const handlePickHero = async (charId: string) => {
    setActiveCharId(charId);
    playSuccessSound();
    if (onSelectAvatar) {
      onSelectAvatar(charId);
    }
    if (currentUser?.username) {
      try {
        await selectCharacter(currentUser.username, charId);
      } catch (e) {
        console.error(e);
      }
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-[#050814] text-slate-100 font-sans overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950 flex flex-col justify-between">
      {/* Background Ambient Glows & Neon Wireframe Accents matching user design */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Soft radial atmospheric auroras */}
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[550px] rounded-full opacity-30 blur-3xl pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(6, 182, 212, 0.45) 0%, rgba(168, 85, 247, 0.25) 50%, transparent 75%)'
          }}
        />
        <div
          className="absolute top-1/2 -right-40 w-[600px] h-[600px] rounded-full opacity-15 blur-3xl pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(168, 85, 247, 0.4) 0%, transparent 70%)'
          }}
        />

        {/* Top-Left: Neon < / > Code Wireframe */}
        <div className="absolute top-36 left-10 md:left-24 opacity-40 transform -rotate-12 select-none">
          <svg width="68" height="68" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-[0_0_12px_rgba(0,229,255,0.7)]">
            <polyline points="16 18 22 12 16 6" />
            <polyline points="8 6 2 12 8 18" />
          </svg>
        </div>

        {/* Mid-Left: Connected Binary Tree Wireframe */}
        <div className="absolute top-64 left-8 md:left-28 opacity-35 select-none">
          <svg width="84" height="84" viewBox="0 0 100 100" fill="none" className="drop-shadow-[0_0_10px_rgba(0,229,255,0.6)]">
            <line x1="50" y1="20" x2="25" y2="55" stroke="#00e5ff" strokeWidth="1.5" strokeDasharray="3 2" />
            <line x1="50" y1="20" x2="75" y2="55" stroke="#00e5ff" strokeWidth="1.5" strokeDasharray="3 2" />
            <line x1="25" y1="55" x2="12" y2="85" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="25" y1="55" x2="38" y2="85" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="75" y1="55" x2="62" y2="85" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="75" y1="55" x2="88" y2="85" stroke="#00e5ff" strokeWidth="1.2" />
            <circle cx="50" cy="20" r="7" stroke="#00e5ff" strokeWidth="2" fill="#050814" />
            <circle cx="25" cy="55" r="6" stroke="#00e5ff" strokeWidth="2" fill="#050814" />
            <circle cx="75" cy="55" r="6" stroke="#00e5ff" strokeWidth="2" fill="#050814" />
            <circle cx="12" cy="85" r="5" stroke="#00e5ff" strokeWidth="1.5" fill="#050814" />
            <circle cx="38" cy="85" r="5" stroke="#00e5ff" strokeWidth="1.5" fill="#050814" />
            <circle cx="62" cy="85" r="5" stroke="#00e5ff" strokeWidth="1.5" fill="#050814" />
            <circle cx="88" cy="85" r="5" stroke="#00e5ff" strokeWidth="1.5" fill="#050814" />
          </svg>
        </div>

        {/* Top-Right: Polyhedron / Geodesic Constellation Wireframe */}
        <div className="absolute top-32 right-12 md:right-28 opacity-40 select-none">
          <svg width="100" height="90" viewBox="0 0 100 90" fill="none" className="drop-shadow-[0_0_12px_rgba(0,229,255,0.7)]">
            <polygon points="50,10 90,30 75,80 25,80 10,30" stroke="#00e5ff" strokeWidth="1.5" />
            <line x1="50" y1="10" x2="50" y2="50" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="90" y1="30" x2="50" y2="50" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="75" y1="80" x2="50" y2="50" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="25" y1="80" x2="50" y2="50" stroke="#00e5ff" strokeWidth="1.2" />
            <line x1="10" y1="30" x2="50" y2="50" stroke="#00e5ff" strokeWidth="1.2" />
            <circle cx="50" cy="10" r="3.5" fill="#00e5ff" />
            <circle cx="90" cy="30" r="3.5" fill="#00e5ff" />
            <circle cx="75" cy="80" r="3.5" fill="#00e5ff" />
            <circle cx="25" cy="80" r="3.5" fill="#00e5ff" />
            <circle cx="10" cy="30" r="3.5" fill="#00e5ff" />
            <circle cx="50" cy="50" r="4" fill="#38bdf8" />
          </svg>
        </div>

        {/* Mid-Right: Trophy Wireframe */}
        <div className="absolute top-64 right-10 md:right-24 opacity-35 select-none">
          <svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-[0_0_10px_rgba(0,229,255,0.6)]">
            <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
            <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
            <path d="M4 22h16" />
            <path d="M10 14.66V17c0 .55-.45 1-1 1H7v2h10v-2h-2c-.55 0-1-.45-1-1v-2.34" />
            <path d="M6 4h12v7a6 6 0 0 1-12 0V4Z" />
            <polygon points="12 6.5 13 8.5 15.2 8.8 13.6 10.3 14 12.5 12 11.4 10 12.5 10.4 10.3 8.8 8.8 11 8.5 12 6.5" fill="#00e5ff" stroke="none" />
          </svg>
        </div>

        {/* Subtle grid backdrop */}
        <div
          className="w-full h-full opacity-10"
          style={{
            backgroundImage: `linear-gradient(to right, rgba(6, 182, 212, 0.15) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(6, 182, 212, 0.15) 1px, transparent 1px)`,
            backgroundSize: '48px 48px'
          }}
        />
      </div>

      {/* Top Header Navigation Bar */}
      <header className="relative z-30 max-w-7xl w-full mx-auto px-4 sm:px-8 py-5 flex items-center justify-between">
        {/* Left: Brand Icon + Wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg border-2 border-cyan-400 bg-cyan-950/60 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.5)]">
            <span className="font-black text-cyan-400 text-sm tracking-wider">A</span>
          </div>
          <span className="text-lg font-black tracking-widest text-white uppercase select-none">
            ALGORIA
          </span>
        </div>

        {/* Center: Main Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-8">
          {/* Active Tab: Explore */}
          <div className="relative flex flex-col items-center">
            <button
              onClick={() => {
                playButtonClick();
              }}
              className="flex items-center gap-2 text-cyan-400 font-bold text-sm transition-colors cursor-pointer"
            >
              <Compass className="w-4 h-4 text-cyan-400" />
              <span>Explore</span>
            </button>
            {/* Glowing Active Underline Indicator */}
            <div className="h-[2px] w-full bg-cyan-400 rounded-full shadow-[0_0_10px_#00e5ff] mt-2" />
          </div>

          {/* Learning Paths */}
          <button
            onClick={() => {
              playButtonClick();
              if (onOpenLearningPaths) onOpenLearningPaths();
              else onStartAdventure();
            }}
            className="flex items-center gap-2 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-slate-400" />
            <span>Learning Paths</span>
          </button>

          {/* Leaderboard */}
          <button
            onClick={() => {
              playButtonClick();
              if (onOpenLeaderboard) onOpenLeaderboard();
            }}
            className="flex items-center gap-2 text-slate-300 hover:text-white font-medium text-sm transition-colors cursor-pointer"
          >
            <Trophy className="w-4 h-4 text-slate-400" />
            <span>Leaderboard</span>
          </button>
        </nav>

        {/* Right: Sound Mute & User Profile Pill */}
        <div className="relative flex items-center gap-3">
          <button
            onClick={() => {
              playButtonClick();
              onToggleMute();
            }}
            className="p-2 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-full text-slate-400 hover:text-slate-200 transition cursor-pointer"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Profile Pill matching user design */}
          <div className="relative">
            <button
              onClick={() => {
                playButtonClick();
                setShowUserDropdown(!showUserDropdown);
              }}
              className="flex items-center gap-2.5 pl-1 pr-3 py-1 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/60 rounded-full transition cursor-pointer shadow-md group"
            >
              <img
                src="/assets/avatars/avatar_pallavi.jpg"
                alt="pallavi"
                className="w-7 h-7 rounded-full object-cover border border-cyan-400/60 group-hover:border-cyan-300 shadow-sm"
              />
              <span className="text-xs font-bold text-white tracking-wide">
                {currentUser?.username || 'pallavi'}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-200 transition-transform duration-200" />
            </button>

            {/* Profile Dropdown Menu */}
            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-slate-950/95 border border-cyan-500/30 p-3 shadow-2xl backdrop-blur-xl z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                  <img
                    src="/assets/avatars/avatar_pallavi.jpg"
                    alt="pallavi"
                    className="w-10 h-10 rounded-full object-cover border border-cyan-400 shadow-md"
                  />
                  <div>
                    <div className="text-sm font-extrabold text-white">
                      {currentUser?.username || 'pallavi'}
                    </div>
                    <div className="text-[10px] text-cyan-400 font-mono">
                      Level 1 Algoria Explorer
                    </div>
                  </div>
                </div>

                <div className="py-2.5 space-y-1.5 text-xs font-mono">
                  <div className="flex items-center justify-between text-slate-300 bg-slate-900/70 px-2.5 py-1.5 rounded-lg border border-slate-800">
                    <span className="flex items-center gap-1.5 text-amber-400">
                      <Flame className="w-3.5 h-3.5 fill-current" /> Daily Streak
                    </span>
                    <span className="font-bold text-white">{currentUser?.progress?.streak || 1}d</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300 bg-slate-900/70 px-2.5 py-1.5 rounded-lg border border-slate-800">
                    <span className="flex items-center gap-1.5 text-cyan-300">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Algoria Dust
                    </span>
                    <span className="font-bold text-white">{currentUser?.progress?.algoriaDust ?? 150}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 space-y-1">
                  {onOpenAdmin && (
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onOpenAdmin();
                      }}
                      className="w-full text-left px-2.5 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-900 rounded-lg flex items-center gap-2 transition cursor-pointer"
                    >
                      <Shield className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Admin &amp; MongoDB Status</span>
                    </button>
                  )}

                  {onLogout && (
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onLogout();
                      }}
                      className="w-full text-left px-2.5 py-1.5 text-xs text-rose-300 hover:text-rose-100 hover:bg-rose-950/40 rounded-lg flex items-center gap-2 transition cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-400" />
                      <span>Log Out</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Hero & Content Section */}
      <main className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 text-center my-auto pt-2 pb-6 flex flex-col items-center">
        {/* Floating Mascot with Speech Bubble */}
        <div className="relative mb-4 flex items-center justify-center">
          {/* Nova Floating Avatar in Holographic Ring */}
          <div className="relative group cursor-pointer transition-transform duration-300 hover:scale-105">
            <div className="absolute inset-0 rounded-full bg-cyan-400/20 blur-2xl animate-pulse pointer-events-none" />
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full p-1.5 bg-gradient-to-b from-cyan-400 via-blue-600 to-purple-600 shadow-[0_0_35px_rgba(0,229,255,0.45)] flex items-center justify-center overflow-hidden">
              <img
                src="/assets/heroes/hero_nova.jpg"
                alt="Nova Robot Guide"
                className="w-full h-full object-cover rounded-full"
              />
              <div className="absolute inset-0 rounded-full ring-2 ring-cyan-300/40 pointer-events-none" />
            </div>
          </div>

          {/* Speech Bubble pointing to Nova */}
          <div className="absolute -right-24 sm:-right-36 top-6 sm:top-8 bg-slate-900/95 border border-cyan-400/50 rounded-2xl px-4 py-2.5 text-left shadow-2xl backdrop-blur-md select-none hidden xs:block">
            {/* Bubble Tail */}
            <div className="absolute -left-2 top-4 w-0 h-0 border-t-6 border-t-transparent border-r-8 border-r-slate-900/95 border-b-6 border-b-transparent" />
            <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
              <span>Hi! I'm Nova</span>
              <span className="text-amber-300 text-sm animate-bounce">👋</span>
            </div>
            <div className="text-[10px] sm:text-xs text-cyan-300/80 font-sans mt-0.5">
              Your AI learning guide
            </div>
          </div>
        </div>

        {/* Hero Kicker with Wings */}
        <div className="flex items-center justify-center gap-3 mb-3">
          <div className="h-[1px] w-10 sm:w-16 bg-gradient-to-r from-transparent to-cyan-500/60" />
          <div className="px-4 py-1 rounded-full bg-[#081734] border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.35)] flex items-center gap-1.5">
            <span className="text-sm">🚀</span>
            <span className="text-[10px] sm:text-xs font-black tracking-widest text-cyan-300 uppercase">
              YOUR DSA ADVENTURE STARTS HERE
            </span>
          </div>
          <div className="h-[1px] w-10 sm:w-16 bg-gradient-to-l from-transparent to-cyan-500/60" />
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl md:text-[54px] font-black tracking-tight text-white leading-[1.1] mb-3">
          Master Algorithms. Play Your Way.
        </h1>

        {/* Subtitle */}
        <p className="text-xs sm:text-sm md:text-base text-slate-300 max-w-xl mx-auto leading-relaxed mb-6 font-normal">
          Learn Data Structures &amp; Algorithms through immersive games,<br className="hidden sm:inline" />
          build skills, and track your progress!
        </p>

        {/* Main Glass Card: Choose your hero */}
        <div className="w-full max-w-4xl bg-slate-950/70 border border-blue-900/40 rounded-2xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl backdrop-blur-xl">
          {/* Card Title */}
          <div className="flex items-center justify-center gap-2 mb-5">
            <Gamepad2 className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
              Choose your hero
            </h2>
          </div>

          {/* 4 Hero Cards in a Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
            {CHARACTERS.map((hero) => {
              const isSelected = hero.id === activeCharId;
              return (
                <button
                  key={hero.id}
                  onClick={() => handlePickHero(hero.id)}
                  className={`relative p-3 rounded-2xl text-center transition-all duration-200 cursor-pointer flex flex-col items-center overflow-hidden ${
                    isSelected
                      ? 'border-2 border-cyan-400 bg-[#09152e]/85 shadow-[0_0_25px_rgba(6,182,212,0.45)] ring-2 ring-cyan-400/20 scale-[1.02]'
                      : 'border border-slate-800/80 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900/80 hover:scale-[1.01]'
                  }`}
                >
                  {/* Selected Checkmark Badge in Top-Right */}
                  {isSelected && (
                    <span className="absolute top-2.5 right-2.5 z-10 w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-md">
                      <Check className="w-3.5 h-3.5 stroke-[3.5]" />
                    </span>
                  )}

                  {/* Hero Portrait Image */}
                  <div className="w-full h-32 sm:h-36 mb-2 rounded-xl overflow-hidden flex items-center justify-center bg-slate-950/60 border border-slate-800">
                    <img
                      src={hero.image}
                      alt={hero.name}
                      className="w-full h-full object-cover rounded-xl transition-transform duration-300 hover:scale-105"
                    />
                  </div>

                  {/* Hero Name */}
                  <span className="text-sm sm:text-base font-bold text-white tracking-wide">
                    {hero.name}
                  </span>

                  {/* Hero Subtitle */}
                  <span className="text-[11px] text-slate-400 font-normal mt-0.5">
                    {hero.subtitle}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Action Buttons Below Cards */}
          <div className="flex items-center justify-center gap-3 mt-6 flex-wrap">
            {/* Primary Action Button */}
            <button
              onClick={() => {
                playButtonClick();
                onStartAdventure();
              }}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-fuchsia-500 hover:brightness-110 active:scale-95 text-slate-950 font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start your adventure →</span>
            </button>

            {/* Secondary Action Button */}
            <button
              onClick={() => {
                playButtonClick();
                if (onOpenLearningPaths) onOpenLearningPaths();
                else onStartAdventure();
              }}
              className="px-5 py-2.5 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/40 text-white font-medium text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>Explore learning paths</span>
            </button>
          </div>
        </div>

        {/* Learning Dashboard Overview (Focused strictly on learning metrics and user progress, no game modes) */}
        <section className="w-full max-w-4xl mt-7">
          {/* Header row */}
          <div className="flex items-center justify-between mb-3.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm sm:text-base font-bold text-white tracking-wide">
                Learning Dashboard
              </h3>
            </div>

            {onOpenLeaderboard && (
              <button
                onClick={() => {
                  playButtonClick();
                  onOpenLeaderboard();
                }}
                className="text-xs font-semibold text-cyan-300 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/30 hover:border-cyan-400 px-3.5 py-1.5 rounded-full transition cursor-pointer flex items-center gap-1.5"
              >
                <Trophy className="w-3 h-3 text-amber-400" />
                <span>Leaderboard</span>
              </button>
            )}
          </div>

          {/* 4 Focused Learning Dashboard Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-3.5">
            {/* Daily Streak Card */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-amber-500/40 hover:bg-slate-900/80 transition-all duration-200 text-left shadow-lg backdrop-blur-md group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-400">Daily Streak</span>
                <Flame className="w-4 h-4 text-amber-400 fill-amber-400 group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-white font-mono">
                {currentUser?.progress?.streak || 1} <span className="text-xs font-normal text-amber-300">Days</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Consistent algorithmic practice
              </p>
            </div>

            {/* Algoria Dust Card */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/40 hover:bg-slate-900/80 transition-all duration-200 text-left shadow-lg backdrop-blur-md group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-400">Algoria Dust</span>
                <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-white font-mono">
                {currentUser?.progress?.algoriaDust ?? 150} <span className="text-xs font-normal text-cyan-300">Dust</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Usable for energy and hints
              </p>
            </div>

            {/* DSA Mastery Card */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-purple-500/40 hover:bg-slate-900/80 transition-all duration-200 text-left shadow-lg backdrop-blur-md group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-400">DSA Mastery</span>
                <Star className="w-4 h-4 text-purple-400 fill-purple-400/40 group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-xl sm:text-2xl font-black text-white font-mono">
                {Object.keys(currentUser?.progress?.completedLevels || {}).length} <span className="text-xs font-normal text-purple-300">/ 30</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Core concepts completed
              </p>
            </div>

            {/* Companion Perk Card */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-400/50 hover:bg-slate-900/80 transition-all duration-200 text-left shadow-lg backdrop-blur-md group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-400">Active Perk</span>
                <Shield className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              </div>
              <div className="text-sm font-bold text-white truncate">
                {CHARACTERS.find((c) => c.id === activeCharId)?.name || 'Nova'}
              </div>
              <p className="text-[10px] text-cyan-300/90 mt-1 truncate">
                {CHARACTERS.find((c) => c.id === activeCharId)?.perk || 'Guidance Boost'}
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 max-w-7xl w-full mx-auto px-6 py-4 border-t border-slate-900/80 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-4">
        <div>Algoria · Interactive Computer Science Adventure</div>
        <div className="text-slate-400 font-mono text-[11px]">
          Cloud Synced: MongoDB Atlas (<span className="text-cyan-400">cluster0.lpoe18o.mongodb.net</span>) · Real-Time Data Only
        </div>
      </footer>
    </div>
  );
};
