import React, { useState } from 'react';
import {
  Trees,
  Castle,
  ArrowRight,
  Sparkles,
  Award,
  Layers,
  Code2,
  Cpu,
  User,
  Shield,
  Star,
  CheckCircle2,
  Compass,
  Lock,
  AlertCircle,
  X,
  Home
} from 'lucide-react';
import { CharacterAvatar } from '../components/CharacterAvatar.tsx';
import { CHARACTERS } from '../api/gameApi.js';
import { playButtonClick, playErrorSound } from '../utils/audio.ts';

interface RealmSelectScreenProps {
  currentUser: any;
  onSelectRealm: (realm: 'WORLD_MAP' | 'OBJECT_KINGDOM') => void;
  onChangeAvatar: () => void;
  onGoHome?: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const RealmSelectScreen: React.FC<RealmSelectScreenProps> = ({
  currentUser,
  onSelectRealm,
  onChangeAvatar,
  onGoHome
}) => {
  const [showLockedModal, setShowLockedModal] = useState<boolean>(false);

  const charId = currentUser?.progress?.characterId || 'bit_byte';
  const charConfig = CHARACTERS.find((c) => c.id === charId) || CHARACTERS[0];
  const progress = currentUser?.progress || {};
  const completedLevels = progress.completedLevels || {};

  // Count cleared levels
  const dsaLevelsCount = Object.keys(completedLevels).filter((k) => !k.startsWith('object_kingdom')).length;

  const handleObjectKingdomClick = () => {
    playErrorSound();
    setShowLockedModal(true);
  };

  return (
    <div className="relative min-h-screen w-full bg-[#050814] text-slate-100 flex flex-col justify-between p-4 sm:p-8 overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950">
      {/* Background Ambient Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full opacity-25 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(6, 182, 212, 0.4) 0%, rgba(168, 85, 247, 0.2) 50%, transparent 75%)'
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full opacity-15 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(168, 85, 247, 0.35) 0%, transparent 70%)'
          }}
        />
      </div>

      {/* Top Header */}
      <header className="relative z-10 max-w-6xl w-full mx-auto flex items-center justify-between pb-4 border-b border-cyan-500/20">
        <div className="flex items-center gap-3">
          <CharacterAvatar characterId={charId} size={42} />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-white">
                {currentUser?.username || 'Explorer'}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-mono font-bold">
                {charConfig.name}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Avatar Active · Ready for Realm Expedition</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onGoHome && (
            <button
              onClick={() => {
                playButtonClick();
                onGoHome();
              }}
              className="px-3.5 py-1.5 text-xs text-cyan-300 hover:text-white bg-slate-900/90 hover:bg-slate-800 rounded-xl border border-cyan-500/40 hover:border-cyan-400 transition-all cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95"
              title="Return to Home Screen"
            >
              <Home className="w-3.5 h-3.5 text-cyan-400" />
              <span>Home</span>
            </button>
          )}

          <button
            onClick={() => {
              playButtonClick();
              onChangeAvatar();
            }}
            className="px-3.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900/90 hover:bg-slate-800 rounded-xl border border-slate-700/80 hover:border-cyan-400 transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
          >
            <User className="w-3.5 h-3.5 text-purple-400" />
            <span>Change Avatar</span>
          </button>
        </div>
      </header>

      {/* Main Realm Choice Arena */}
      <main className="relative z-10 max-w-5xl w-full mx-auto my-auto py-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#081734] border border-cyan-500/50 text-cyan-300 text-xs font-semibold mb-3 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <Compass className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span>SELECT DESTINATION REALM</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            Choose Your Adventure Realm
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-xl mx-auto leading-relaxed">
            Your avatar <strong className="text-cyan-300">{charConfig.name}</strong> is synchronized. Select the active <strong className="text-emerald-400">World Map</strong> to begin your DSA adventure!
          </p>
        </div>

        {/* 2 Big Realm Choice Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 max-w-4xl mx-auto">
          {/* Card 1: World Map (DSA Realm) - UNLOCKED & ACTIVE */}
          <div
            onClick={() => {
              playButtonClick();
              onSelectRealm('WORLD_MAP');
            }}
            className="group relative p-6 sm:p-7 rounded-3xl bg-slate-950/75 border-2 border-emerald-500/50 hover:border-emerald-400 shadow-2xl hover:shadow-emerald-500/20 transition-all duration-300 flex flex-col justify-between cursor-pointer transform hover:-translate-y-1.5 backdrop-blur-xl ring-2 ring-emerald-500/20"
          >
            {/* Sector Badge */}
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-[11px] font-mono font-bold text-emerald-300 flex items-center gap-1.5">
                <Trees className="w-3.5 h-3.5 text-emerald-400" />
                <span>6 ACTIVE SECTORS</span>
              </span>
              <span className="text-xs font-mono text-emerald-400 font-bold">
                {dsaLevelsCount}/30 Levels Cleared
              </span>
            </div>

            {/* Realm Visual Icon */}
            <div className="w-16 h-16 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-300 mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-emerald-500/20">
              <Trees className="w-9 h-9" />
            </div>

            {/* Title & Description */}
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white group-hover:text-emerald-300 transition-colors">
              World Map (DSA)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              Master Data Structures &amp; Algorithms across 6 rich sectors: Loop Forest runner, Stack Volcano LIFO, Queue River FIFO, Tree Valley BST, Graph City survival, and Array Arena.
            </p>

            {/* Highlights List */}
            <div className="mt-4 pt-4 border-t border-slate-800 space-y-1.5 text-xs text-slate-400 font-mono">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Loop Forest, Stack Volcano &amp; Queue River</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Tree Valley BST Traversals &amp; Graph City</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Array Arena: Bubble Sort &amp; Binary Search Race</span>
              </div>
            </div>

            {/* Action Button */}
            <div className="mt-6 pt-3">
              <button className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 group-hover:from-emerald-500 group-hover:to-teal-500 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer">
                <span>Enter World Map &amp; Play DSA</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Card 2: Object Kingdom (OOP Realm) - LOCKED & UNDER CONSTRUCTION */}
          <div
            onClick={handleObjectKingdomClick}
            className="group relative p-6 sm:p-7 rounded-3xl bg-slate-950/70 border-2 border-slate-800 hover:border-amber-500/50 transition-all duration-300 flex flex-col justify-between cursor-pointer opacity-85 hover:opacity-100"
          >
            {/* Locked Badge */}
            <div className="flex items-center justify-between mb-4">
              <span className="px-3 py-1 rounded-full bg-amber-950/80 border border-amber-500/50 text-[11px] font-mono font-bold text-amber-300 flex items-center gap-1.5 shadow-sm">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>LOCKED · UNDER CONSTRUCTION</span>
              </span>
              <span className="text-xs font-mono text-slate-500">
                Coming Soon
              </span>
            </div>

            {/* Realm Visual Icon with Lock */}
            <div className="relative w-16 h-16 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-400 mb-4 group-hover:border-amber-500/50 transition-all">
              <Castle className="w-9 h-9 text-slate-400" />
              <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 rounded-full p-1 border-2 border-slate-900">
                <Lock className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Title & Description */}
            <div className="flex items-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-300 group-hover:text-amber-200 transition-colors">
                Object Kingdom
              </h2>
              <Lock className="w-5 h-5 text-amber-400" />
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
              Citadel of Object-Oriented Programming (Classes, Encapsulation, Inheritance, Polymorphism &amp; Abstraction).
            </p>

            {/* Highlights List */}
            <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-500 font-mono">
              <div className="flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <span>Classes &amp; Objects: Blueprints vs Instances</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <span>Encapsulation: Private Fields &amp; Defensive Setters</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <span>Inheritance, Polymorphism &amp; Abstraction</span>
              </div>
            </div>

            {/* Locked Action Button */}
            <div className="mt-6 pt-3">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleObjectKingdomClick();
                }}
                className="w-full py-3.5 px-4 bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 hover:border-amber-400 text-amber-300 font-bold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Lock className="w-4 h-4 text-amber-400" />
                <span>Locked · Under Construction</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Lock Notice Modal: "We are still working on that continue with world map" */}
      {showLockedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border-2 border-amber-500/50 rounded-2xl p-6 shadow-2xl text-center">
            {/* Close button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowLockedModal(false);
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Icon */}
            <div className="w-16 h-16 mx-auto mb-4 bg-amber-950/80 border-2 border-amber-500/60 rounded-2xl flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/20">
              <Lock className="w-8 h-8 stroke-[2.5]" />
            </div>

            <h3 className="text-xl font-black text-white mb-2">
              Object Kingdom is Locked!
            </h3>

            {/* Requested copy */}
            <p className="text-sm text-amber-200/90 leading-relaxed mb-6 font-medium bg-amber-950/40 p-3 rounded-xl border border-amber-500/30">
              We are still working on that! Continue with world map.
            </p>

            <div className="space-y-2.5">
              <button
                onClick={() => {
                  playButtonClick();
                  setShowLockedModal(false);
                  onSelectRealm('WORLD_MAP');
                }}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Continue with World Map</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  playButtonClick();
                  setShowLockedModal(false);
                }}
                className="w-full py-2.5 text-xs text-slate-400 hover:text-white cursor-pointer transition-colors"
              >
                Close Notice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Info */}
      <footer className="max-w-6xl w-full mx-auto text-center text-xs text-slate-500 pt-4 border-t border-slate-800/80">
        Algoria Multiverse Engine · Computer Science Core Curriculum (Data Structures &amp; Algorithms)
      </footer>
    </div>
  );
};
