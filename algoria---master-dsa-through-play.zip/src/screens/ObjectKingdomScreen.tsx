import React, { useState } from 'react';
import { OBJECT_KINGDOM_LEVELS } from '../levels/objectKingdom.js';
import { CharacterAvatar } from '../components/CharacterAvatar.tsx';
import {
  Castle,
  Shield,
  Layers,
  Sparkles,
  Zap,
  Coins,
  Star,
  Play,
  Volume2,
  VolumeX,
  X,
  ArrowRight,
  Compass,
  CheckCircle2,
  Lock,
  Cpu,
  KeyRound,
  Boxes,
  Trees,
  Home
} from 'lucide-react';
import { playButtonClick, playErrorSound } from '../utils/audio.ts';

interface ObjectKingdomScreenProps {
  currentUser: any;
  onSelectLevel: (worldId: string, levelId: number) => void;
  onBackToRealmSelect: () => void;
  onSwitchToWorldMap: () => void;
  onChangeCharacter: () => void;
  onLogout: () => void;
  onGoHome?: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const ObjectKingdomScreen: React.FC<ObjectKingdomScreenProps> = ({
  currentUser,
  onBackToRealmSelect,
  onSwitchToWorldMap,
  onChangeCharacter,
  onLogout,
  onGoHome,
  isMuted,
  onToggleMute
}) => {
  const [showLockedModal, setShowLockedModal] = useState<boolean>(true);

  const charId = currentUser?.progress?.characterId || 'bit_byte';
  const progress = currentUser?.progress || {};

  const handleTowerClick = () => {
    playErrorSound();
    setShowLockedModal(true);
  };

  return (
    <div className="min-h-screen w-full bg-[#050814] text-slate-100 flex flex-col justify-between overflow-x-hidden selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header */}
      <header className="border-b border-cyan-500/20 bg-slate-950/85 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl w-full mx-auto px-4 py-3 sm:px-8 flex flex-wrap items-center justify-between gap-4">
          {/* User Profile */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                playButtonClick();
                onChangeCharacter();
              }}
              className="relative group p-1 bg-slate-900 rounded-xl border border-purple-500/40 hover:border-purple-300 transition-colors cursor-pointer"
              title="Change Avatar"
            >
              <CharacterAvatar characterId={charId} size={42} />
              <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-0.5 border border-slate-950">
                <Lock className="w-2.5 h-2.5 text-slate-950" />
              </div>
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-bold text-white tracking-wide">
                  {currentUser?.username || 'Explorer'}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 font-mono font-bold flex items-center gap-1">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span>LOCKED · UNDER CONSTRUCTION</span>
                </span>
              </div>
              <span className="text-[11px] text-slate-400">Object Kingdom (OOP Realm)</span>
            </div>
          </div>

          {/* Center Stats */}
          <div className="flex items-center gap-2 sm:gap-4 text-xs sm:text-sm">
            <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-purple-500/30">
              <Zap className="w-4 h-4 text-purple-400" />
              <span className="font-mono font-bold text-purple-300 tabular-nums">
                {progress.xp || 0}
              </span>
              <span className="text-[10px] text-slate-500 hidden sm:inline">XP</span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-amber-500/30">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="font-mono font-bold text-amber-300 tabular-nums">
                {progress.coins || 0}
              </span>
            </div>
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-2">
            {/* Return to Home Screen Button */}
            {onGoHome && (
              <button
                onClick={() => {
                  playButtonClick();
                  onGoHome();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-950/80 to-slate-900 hover:from-cyan-900/90 hover:to-slate-800 border border-cyan-500/50 hover:border-cyan-400 rounded-xl text-cyan-300 hover:text-white text-xs font-bold transition-all cursor-pointer shadow-sm active:scale-95 group"
                title="Return to Home Page"
              >
                <Home className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                <span>Home</span>
              </button>
            )}

            {/* Quick Switch to World Map (DSA) */}
            <button
              onClick={() => {
                playButtonClick();
                onSwitchToWorldMap();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-950/80 hover:bg-emerald-900/80 border border-emerald-500/60 rounded-xl text-emerald-300 text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Continue with World Map"
            >
              <Trees className="w-4 h-4 text-emerald-400" />
              <span>Continue with World Map</span>
            </button>

            {/* Back to Realm Select */}
            <button
              onClick={() => {
                playButtonClick();
                onBackToRealmSelect();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300 text-xs font-bold transition-all cursor-pointer shadow-sm"
              title="Select Realm"
            >
              <Compass className="w-4 h-4 text-purple-400" />
              <span className="hidden sm:inline">Realms</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                onToggleMute();
              }}
              className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-300 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => {
                playButtonClick();
                onLogout();
              }}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-800 transition-colors cursor-pointer"
            >
              Sign Out
            </button>
          </div>
        </div>
      </header>

      {/* Main Citadel Map Area */}
      <main className="max-w-7xl w-full mx-auto p-4 sm:p-8 flex-1">
        {/* Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/40 text-[10px] font-mono font-bold text-amber-300 flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>ALL OBJECT MAP GAMES ARE LOCKED</span>
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Object Kingdom · The OOP Citadel
            </h1>
            <p className="text-xs sm:text-sm text-amber-300/90 mt-1 max-w-2xl font-medium">
              We are still working on that! Continue with world map to play the active DSA challenges.
            </p>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onSwitchToWorldMap();
            }}
            className="p-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 rounded-2xl flex items-center gap-3 shadow-lg shadow-emerald-500/20 text-white font-bold text-xs cursor-pointer transition-all"
          >
            <Trees className="w-6 h-6 text-white" />
            <div className="text-left font-mono">
              <div>CONTINUE WITH WORLD MAP</div>
              <div className="text-[10px] text-emerald-100 font-normal">Play Active DSA Adventures →</div>
            </div>
          </button>
        </div>

        {/* 5 Locked Citadel Tower Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {OBJECT_KINGDOM_LEVELS.map((lvl) => {
            return (
              <div
                key={lvl.id}
                onClick={handleTowerClick}
                className="relative p-6 rounded-3xl border-2 border-slate-800 bg-slate-950/70 hover:border-amber-500/50 transition-all duration-300 flex flex-col justify-between cursor-pointer opacity-80 hover:opacity-100"
              >
                {/* Top Badge & Lock */}
                <div className="flex items-center justify-between mb-4">
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-[10px] font-mono font-bold text-slate-400">
                    TOWER {lvl.id} OF 5
                  </span>

                  <span className="px-2 py-0.5 rounded-lg bg-amber-950/80 border border-amber-500/40 text-amber-300 flex items-center gap-1 text-[10px] font-mono font-bold">
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>LOCKED</span>
                  </span>
                </div>

                {/* Center Content */}
                <div>
                  <h3 className="text-xl font-bold text-slate-300 flex items-center gap-2">
                    <span>{lvl.title}</span>
                    <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                  </h3>
                  <div className="text-xs font-mono text-purple-400/80 font-bold mt-1">
                    {lvl.concept}
                  </div>
                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    {lvl.subtitle}
                  </p>
                </div>

                {/* Bottom Lock Notice Button */}
                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] font-mono text-amber-400/90 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>Under Construction</span>
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTowerClick();
                    }}
                    className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>Locked</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* Lock Notice Modal: "We are still working on that continue with world map" */}
      {showLockedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border-2 border-amber-500/50 rounded-2xl p-6 shadow-2xl text-center">
            {/* Close button */}
            <button
              onClick={() => {
                playButtonClick();
                setShowLockedModal(false);
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Icon */}
            <div className="w-16 h-16 mx-auto mb-4 bg-amber-950/80 border-2 border-amber-500/60 rounded-2xl flex items-center justify-center text-amber-400 shadow-lg shadow-amber-500/20">
              <Lock className="w-8 h-8 stroke-[2.5]" />
            </div>

            <h3 className="text-xl font-black text-white mb-2">
              Object Kingdom is Locked!
            </h3>

            {/* Requested exact copy */}
            <p className="text-sm text-amber-200/90 leading-relaxed mb-6 font-medium bg-amber-950/40 p-3 rounded-xl border border-amber-500/30">
              We are still working on that! Continue with world map.
            </p>

            <div className="space-y-2.5">
              <button
                onClick={() => {
                  playButtonClick();
                  setShowLockedModal(false);
                  onSwitchToWorldMap();
                }}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Continue with World Map</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  playButtonClick();
                  setShowLockedModal(false);
                }}
                className="w-full py-2.5 text-xs text-slate-400 hover:text-white cursor-pointer transition-colors"
              >
                Close Notice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="max-w-7xl w-full mx-auto p-4 text-center text-xs text-slate-500 border-t border-purple-500/10">
        Object Kingdom · Object-Oriented Software Engineering Realm (Under Construction)
      </footer>
    </div>
  );
};
