import Phaser from 'phaser';
import {
  playCoinSound,
  playErrorSound,
  playSuccessSound,
  playNodeTravelSound,
  playEnergyCellSound,
  playZoneAlertSound,
  playBfsWaveSound,
  playDfsBranchSound
} from '../../utils/audio.ts';

export interface GraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
  isStart?: boolean;
  isExit?: boolean;
  hasEnergy?: boolean;
  layer?: number;
  depth?: number;
  branch?: string;
  isLeaf?: boolean;
  collapsed?: boolean;
}

export interface GraphEdge {
  from: string;
  to: string;
  weight?: number;
}

export interface SafeZoneConfig {
  initialRadius: number;
  minRadius: number;
  shrinkRate: number;
  centerX: number;
  centerY: number;
}

export interface GraphLevelConfig {
  id: number;
  type: string;
  targetCount: number;
  targetTime?: number;
  startNodeId: string;
  exitNodeId?: string;
  targetNodeId?: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  safeZone: SafeZoneConfig;
  bfsLayers?: Record<number, string[]>;
  optimalCost?: number;
  optimalPath?: string[];
}

export interface GraphSceneCallbacks {
  onProgressUpdate?: (data: {
    current: number;
    total: number;
    coins?: number;
    currentNodeId: string;
    visitedNodes: string[];
    availableNeighbors: string[];
    accumulatedCost?: number;
    safeZoneRadius?: number;
    isOutsideZone?: boolean;
    bfsQueue?: string[];
    dfsStack?: string[];
  }) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: {
    itemsCleared: number;
    coinsCollected: number;
    completionTime: number;
    perfect?: boolean;
  }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
}

export class GraphCityScene extends Phaser.Scene {
  private levelConfig!: GraphLevelConfig;
  private callbacks!: GraphSceneCallbacks;
  private coinMultiplier = 1;
  private characterId = 'bit_byte';

  // Graph state
  private currentNodeId!: string;
  private visitedNodes: Set<string> = new Set();
  private collectedEnergyNodes: Set<string> = new Set();
  private collapsedNodes: Set<string> = new Set();
  private isMoving = false;
  private accumulatedCost = 0;
  private currentPath: string[] = [];

  // BFS / DFS specialized structures
  private bfsCurrentLayer = 1;
  private bfsQueue: string[] = [];
  private dfsStack: string[] = [];

  // Safe Zone state
  private safeZoneRadius = 260;
  private zoneCenter = { x: 430, y: 180 };
  private isOutsideZone = false;
  private outsideZoneSeconds = 0;
  private lastAlertSoundTime = 0;

  // Display objects
  private backgroundGraphics!: Phaser.GameObjects.Graphics;
  private roadGraphics!: Phaser.GameObjects.Graphics;
  private zoneGraphics!: Phaser.GameObjects.Graphics;
  private playerAvatar!: Phaser.GameObjects.Container;
  private nodeContainers: Map<string, Phaser.GameObjects.Container> = new Map();
  private energySprites: Map<string, Phaser.GameObjects.Container> = new Map();
  private weightLabels: Phaser.GameObjects.Text[] = [];

  // Pulses and visual effects
  private dataPackets: Array<{ from: GraphNode; to: GraphNode; progress: number; speed: number }> = [];
  private bfsRings: Array<{ x: number; y: number; radius: number; alpha: number }> = [];

  // General counters
  private totalCoins = 0;
  private startTime = 0;
  private isLevelFinished = false;

  constructor() {
    super({ key: 'GraphCityScene' });
  }

  init(data: {
    levelConfig: GraphLevelConfig;
    characterId?: string;
    coinMultiplier?: number;
    callbacks: GraphSceneCallbacks;
  }) {
    this.levelConfig = data.levelConfig;
    this.callbacks = data.callbacks;
    this.coinMultiplier = data.coinMultiplier || 1;
    this.characterId = data.characterId || 'bit_byte';
    this.isLevelFinished = false;
    this.isMoving = false;
    this.totalCoins = 0;
    this.accumulatedCost = 0;

    this.currentNodeId = this.levelConfig.startNodeId;
    this.visitedNodes = new Set([this.currentNodeId]);
    this.collectedEnergyNodes = new Set();
    this.collapsedNodes = new Set();
    this.currentPath = [this.currentNodeId];

    // Initialize Safe Zone
    if (this.levelConfig.safeZone) {
      this.safeZoneRadius = this.levelConfig.safeZone.initialRadius;
      this.zoneCenter = {
        x: this.levelConfig.safeZone.centerX,
        y: this.levelConfig.safeZone.centerY
      };
    }

    // Initialize BFS / DFS structures
    if (this.levelConfig.type === 'bfs_traversal') {
      this.bfsCurrentLayer = 1;
      this.bfsQueue = [this.levelConfig.startNodeId];
      // Enqueue layer 1 neighbors
      const l1 = this.levelConfig.bfsLayers?.[1] || [];
      this.bfsQueue = [this.levelConfig.startNodeId, ...l1];
    } else if (this.levelConfig.type === 'dfs_traversal') {
      this.dfsStack = [this.levelConfig.startNodeId];
    }
  }

  create() {
    this.startTime = this.time.now;

    // Graphics layers in Z-order
    this.backgroundGraphics = this.add.graphics();
    this.roadGraphics = this.add.graphics();
    this.zoneGraphics = this.add.graphics();

    this.drawBackgroundGrid();
    this.setupRoadsAndNodes();
    this.createPlayerAvatar();

    // Spawn animated data packets along edges
    this.initDataPackets();

    // Trigger initial progress callback
    this.emitProgress();

    // Ambient BFS sound if level 2
    if (this.levelConfig.type === 'bfs_traversal') {
      playBfsWaveSound();
      this.triggerBfsPulse(this.zoneCenter.x, this.zoneCenter.y);
    }
  }

  private drawBackgroundGrid() {
    this.backgroundGraphics.clear();

    // Deep slate-950 backdrop
    this.backgroundGraphics.fillStyle(0x070b14, 1);
    this.backgroundGraphics.fillRect(0, 0, 860, 360);

    // Subtle cyan cyber grid lines
    this.backgroundGraphics.lineStyle(1, 0x1e293b, 0.45);
    for (let x = 0; x <= 860; x += 40) {
      this.backgroundGraphics.beginPath();
      this.backgroundGraphics.moveTo(x, 0);
      this.backgroundGraphics.lineTo(x, 360);
      this.backgroundGraphics.strokePath();
    }
    for (let y = 0; y <= 360; y += 40) {
      this.backgroundGraphics.beginPath();
      this.backgroundGraphics.moveTo(0, y);
      this.backgroundGraphics.lineTo(860, y);
      this.backgroundGraphics.strokePath();
    }

    // High-tech corner telemetry marks
    this.backgroundGraphics.lineStyle(2, 0x06b6d4, 0.25);
    this.backgroundGraphics.strokeRect(10, 10, 840, 340);
  }

  private setupRoadsAndNodes() {
    // Clean up any old containers
    this.nodeContainers.forEach((c) => c.destroy());
    this.nodeContainers.clear();
    this.energySprites.forEach((s) => s.destroy());
    this.energySprites.clear();
    this.weightLabels.forEach((w) => w.destroy());
    this.weightLabels = [];

    // Render Nodes
    this.levelConfig.nodes.forEach((node) => {
      const container = this.add.container(node.x, node.y);

      // Outer glow disc
      const glowDisc = this.add.arc(0, 0, 24, 0, 360, false, 0x06b6d4, 0.15);
      glowDisc.setName('glowDisc');

      // Inner base node pad
      let nodeFill = 0x0f172a;
      let strokeColor = 0x38bdf8;
      if (node.isStart) {
        strokeColor = 0x10b981; // Emerald start
        nodeFill = 0x064e3b;
      } else if (node.isExit) {
        strokeColor = 0xf59e0b; // Amber exit
        nodeFill = 0x78350f;
      }

      const baseCircle = this.add.circle(0, 0, 17, nodeFill, 0.95);
      baseCircle.setStrokeStyle(2.5, strokeColor, 1);
      baseCircle.setName('baseCircle');

      // Label
      const shortLabel = node.label.length > 12 ? node.label.substring(0, 11) + '..' : node.label;
      const labelText = this.add.text(0, 22, shortLabel, {
        fontSize: '10px',
        color: '#e2e8f0',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5, 0);

      container.add([glowDisc, baseCircle, labelText]);

      // Interactive hit area
      baseCircle.setInteractive({ useHandCursor: true });
      baseCircle.on('pointerdown', () => {
        this.handleNodeClick(node.id);
      });

      // Hover feedback
      baseCircle.on('pointerover', () => {
        if (!this.isMoving && this.getConnectedNeighbors(this.currentNodeId).includes(node.id)) {
          glowDisc.setScale(1.3);
          glowDisc.setFillStyle(0xec4899, 0.4);
        }
      });
      baseCircle.on('pointerout', () => {
        glowDisc.setScale(1);
        this.updateNodeVisual(node.id);
      });

      this.nodeContainers.set(node.id, container);

      // Render Energy Cell if present
      if (node.hasEnergy && !this.collectedEnergyNodes.has(node.id)) {
        this.createEnergyCell(node);
      }
    });

    // Add Edge weight pills for Level 4
    if (this.levelConfig.type === 'dijkstra_shortest_path') {
      this.levelConfig.edges.forEach((edge) => {
        const fromNode = this.getNode(edge.from);
        const toNode = this.getNode(edge.to);
        if (fromNode && toNode && edge.weight !== undefined) {
          const midX = (fromNode.x + toNode.x) / 2;
          const midY = (fromNode.y + toNode.y) / 2;

          const bgPill = this.add.rectangle(midX, midY, 26, 16, 0x1e1b4b, 0.95);
          bgPill.setStrokeStyle(1.5, 0xf43f5e, 0.9);

          const txt = this.add.text(midX, midY, `${edge.weight}`, {
            fontSize: '11px',
            color: '#fda4af',
            fontFamily: 'monospace',
            fontStyle: 'bold'
          }).setOrigin(0.5);

          this.weightLabels.push(txt);
        }
      });
    }

    this.refreshAllNodeVisuals();
  }

  private createEnergyCell(node: GraphNode) {
    const container = this.add.container(node.x, node.y - 4);

    // Glowing diamond energy cell
    const diamond = this.add.polygon(0, 0, [
      { x: 0, y: -9 },
      { x: 8, y: 0 },
      { x: 0, y: 9 },
      { x: -8, y: 0 }
    ], 0x38bdf8, 0.95);
    diamond.setStrokeStyle(1.5, 0xa5f3fc);

    const innerCore = this.add.circle(0, 0, 3, 0xffffff, 1);
    container.add([diamond, innerCore]);

    // Bobbing and rotating tween
    this.tweens.add({
      targets: container,
      y: node.y - 9,
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });

    this.tweens.add({
      targets: diamond,
      angle: 360,
      duration: 4000,
      repeat: -1,
      ease: 'Linear'
    });

    this.energySprites.set(node.id, container);
  }

  private createPlayerAvatar() {
    const startNode = this.getNode(this.currentNodeId);
    const x = startNode ? startNode.x : 120;
    const y = startNode ? startNode.y : 180;

    this.playerAvatar = this.add.container(x, y);

    let haloColor = 0x06b6d4;
    let bodyColor = 0x38bdf8;
    let coreColor = 0xf43f5e;

    if (this.characterId === 'algo_fox') {
      haloColor = 0xea580c;
      bodyColor = 0xf97316;
      coreColor = 0xfef08a;
    } else if (this.characterId === 'cyber_nova') {
      haloColor = 0xa855f7;
      bodyColor = 0xc084fc;
      coreColor = 0xf472b6;
    } else if (this.characterId === 'pixel_knight') {
      haloColor = 0x10b981;
      bodyColor = 0x34d399;
      coreColor = 0xfbbf24;
    }

    // Outer cyber shield halo
    const halo = this.add.arc(0, 0, 18, 0, 360, false, haloColor, 0.35);
    halo.setName('avatarHalo');

    // Cyber Runner Drone body (diamond polygon with neon accents)
    const runnerBody = this.add.polygon(0, 0, [
      { x: 12, y: 0 },
      { x: -6, y: -9 },
      { x: -2, y: 0 },
      { x: -6, y: 9 }
    ], bodyColor, 1);
    runnerBody.setStrokeStyle(2, 0xffffff, 1);

    const coreLight = this.add.circle(0, 0, 3.5, coreColor, 1);

    this.playerAvatar.add([halo, runnerBody, coreLight]);
    this.playerAvatar.setDepth(20);

    // Gentle hover tween
    this.tweens.add({
      targets: halo,
      scaleX: 1.25,
      scaleY: 1.25,
      alpha: 0.15,
      duration: 800,
      yoyo: true,
      repeat: -1
    });
  }

  private initDataPackets() {
    this.dataPackets = [];
    this.levelConfig.edges.forEach((edge) => {
      const fromNode = this.getNode(edge.from);
      const toNode = this.getNode(edge.to);
      if (fromNode && toNode) {
        this.dataPackets.push({
          from: fromNode,
          to: toNode,
          progress: Math.random(),
          speed: 0.003 + Math.random() * 0.004
        });
      }
    });
  }

  /**
   * Main Scene Loop: Renders roads, safe zone, data pulses, and zone hazard timer
   */
  update(_time: number, delta: number) {
    if (this.isLevelFinished) return;

    // 1. Shrink Safe Zone
    if (this.levelConfig.safeZone && this.safeZoneRadius > this.levelConfig.safeZone.minRadius) {
      const shrinkAmt = (this.levelConfig.safeZone.shrinkRate * delta) / 1000;
      this.safeZoneRadius = Math.max(this.levelConfig.safeZone.minRadius, this.safeZoneRadius - shrinkAmt);
    }

    // 2. Check if player is outside the safe zone circle
    const distToCenter = Phaser.Math.Distance.Between(
      this.playerAvatar.x,
      this.playerAvatar.y,
      this.zoneCenter.x,
      this.zoneCenter.y
    );

    const wasOutside = this.isOutsideZone;
    this.isOutsideZone = distToCenter > this.safeZoneRadius;

    if (this.isOutsideZone) {
      this.outsideZoneSeconds += delta / 1000;
      // Pulse avatar alert
      const halo = this.playerAvatar.getByName('avatarHalo') as Phaser.GameObjects.Arc;
      if (halo) halo.setFillStyle(0xef4444, 0.6);

      // Warning audio alert every 1.8s
      if (_time - this.lastAlertSoundTime > 1800) {
        playZoneAlertSound();
        this.lastAlertSoundTime = _time;
      }

      // If outside safe zone for more than 4 seconds, lose a heart
      if (this.outsideZoneSeconds >= 4.0) {
        this.outsideZoneSeconds = 0;
        if (this.callbacks.onHeartLost) this.callbacks.onHeartLost();
      }
    } else {
      this.outsideZoneSeconds = 0;
      const halo = this.playerAvatar.getByName('avatarHalo') as Phaser.GameObjects.Arc;
      if (halo) halo.setFillStyle(0x06b6d4, 0.35);
    }

    if (wasOutside !== this.isOutsideZone) {
      this.emitProgress();
    }

    // 3. Render Roads and Connections
    this.renderRoads();

    // 4. Render Safe Zone perimeter & hazard overlay
    this.renderSafeZone();

    // 5. Update data pulses
    this.dataPackets.forEach((p) => {
      p.progress += p.speed;
      if (p.progress > 1) p.progress = 0;
    });

    // 6. Update BFS expanding rings
    for (let i = this.bfsRings.length - 1; i >= 0; i--) {
      const ring = this.bfsRings[i];
      ring.radius += delta * 0.12;
      ring.alpha -= delta * 0.0009;
      if (ring.alpha <= 0 || ring.radius > 320) {
        this.bfsRings.splice(i, 1);
      }
    }
  }

  private renderRoads() {
    this.roadGraphics.clear();

    // Render underlying edge roads
    this.levelConfig.edges.forEach((edge) => {
      const from = this.getNode(edge.from);
      const to = this.getNode(edge.to);
      if (!from || !to) return;

      const isCurrentRoad =
        (this.currentNodeId === edge.from && this.getConnectedNeighbors(this.currentNodeId).includes(edge.to)) ||
        (this.currentNodeId === edge.to && this.getConnectedNeighbors(this.currentNodeId).includes(edge.from));

      // Road glow & base
      if (isCurrentRoad) {
        this.roadGraphics.lineStyle(5, 0x06b6d4, 0.45);
        this.roadGraphics.beginPath();
        this.roadGraphics.moveTo(from.x, from.y);
        this.roadGraphics.lineTo(to.x, to.y);
        this.roadGraphics.strokePath();

        this.roadGraphics.lineStyle(2, 0x38bdf8, 0.95);
      } else {
        this.roadGraphics.lineStyle(2, 0x334155, 0.6);
      }

      this.roadGraphics.beginPath();
      this.roadGraphics.moveTo(from.x, from.y);
      this.roadGraphics.lineTo(to.x, to.y);
      this.roadGraphics.strokePath();
    });

    // Render active path breadcrumb trail (especially in DFS and Dijkstra)
    if (this.currentPath.length > 1) {
      this.roadGraphics.lineStyle(3, 0xec4899, 0.85);
      for (let i = 0; i < this.currentPath.length - 1; i++) {
        const p1 = this.getNode(this.currentPath[i]);
        const p2 = this.getNode(this.currentPath[i + 1]);
        if (p1 && p2) {
          this.roadGraphics.beginPath();
          this.roadGraphics.moveTo(p1.x, p1.y);
          this.roadGraphics.lineTo(p2.x, p2.y);
          this.roadGraphics.strokePath();
        }
      }
    }

    // Render flowing data packets
    this.dataPackets.forEach((p) => {
      const px = p.from.x + (p.to.x - p.from.x) * p.progress;
      const py = p.from.y + (p.to.y - p.from.y) * p.progress;
      this.roadGraphics.fillStyle(0x38bdf8, 0.8);
      this.roadGraphics.fillCircle(px, py, 3);
    });
  }

  private renderSafeZone() {
    this.zoneGraphics.clear();

    const cx = this.zoneCenter.x;
    const cy = this.zoneCenter.y;
    const r = this.safeZoneRadius;

    // Glowing electric boundary circle
    this.zoneGraphics.lineStyle(2.5, 0x06b6d4, 0.85);
    this.zoneGraphics.strokeCircle(cx, cy, r);

    // Outer faint pulsing halo
    this.zoneGraphics.lineStyle(1.5, 0xec4899, 0.4);
    this.zoneGraphics.strokeCircle(cx, cy, r + 4);

    // Hazard vignette outside safe zone
    // Render dashed hazard ticks along perimeter
    this.zoneGraphics.lineStyle(1.5, 0xf43f5e, 0.55);
    const tickCount = 28;
    for (let i = 0; i < tickCount; i++) {
      const angle = (i / tickCount) * Math.PI * 2;
      const x1 = cx + Math.cos(angle) * r;
      const y1 = cy + Math.sin(angle) * r;
      const x2 = cx + Math.cos(angle) * (r + 8);
      const y2 = cy + Math.sin(angle) * (r + 8);
      this.zoneGraphics.beginPath();
      this.zoneGraphics.moveTo(x1, y1);
      this.zoneGraphics.lineTo(x2, y2);
      this.zoneGraphics.strokePath();
    }

    // Draw active BFS radial rings if expanding
    this.bfsRings.forEach((ring) => {
      this.zoneGraphics.lineStyle(2, 0x38bdf8, ring.alpha);
      this.zoneGraphics.strokeCircle(ring.x, ring.y, ring.radius);
    });
  }

  public triggerBfsPulse(x: number, y: number) {
    this.bfsRings.push({ x, y, radius: 10, alpha: 0.8 });
  }

  /**
   * Node Navigation Logic
   */
  public handleNodeClick(targetId: string) {
    if (this.isMoving || this.isLevelFinished) return;
    if (targetId === this.currentNodeId) return;

    const currentNeighbors = this.getConnectedNeighbors(this.currentNodeId);
    if (!currentNeighbors.includes(targetId)) {
      playErrorSound();
      return;
    }

    const targetNode = this.getNode(targetId);
    if (!targetNode) return;

    // Rule Level 5: Check if node is collapsed
    if (this.collapsedNodes.has(targetId)) {
      playErrorSound();
      if (this.callbacks.onLevelFailed) {
        this.callbacks.onLevelFailed(`Node "${targetNode.label}" has already collapsed into the glitch void!`);
      }
      return;
    }

    // Rule Level 2: BFS order check
    if (this.levelConfig.type === 'bfs_traversal') {
      const targetLayer = targetNode.layer ?? 0;
      if (targetLayer > this.bfsCurrentLayer) {
        // Check if there are any unvisited nodes in earlier layers
        const unvisitedInEarlierLayers = this.levelConfig.nodes.some(
          (n) => (n.layer ?? 0) < targetLayer && !this.visitedNodes.has(n.id)
        );
        if (unvisitedInEarlierLayers) {
          playErrorSound();
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed(
              `BFS Breach! You must visit all Layer ${this.bfsCurrentLayer} nodes before proceeding to Layer ${targetLayer}!`
            );
          }
          return;
        }
      }
    }

    // Rule Level 3: DFS deep-first check
    if (this.levelConfig.type === 'dfs_traversal') {
      const currentNode = this.getNode(this.currentNodeId);
      // If we are currently exploring a branch, don't jump across branches unless at a fork/backtrack
      if (currentNode && targetNode.branch && currentNode.branch && targetNode.branch !== currentNode.branch) {
        // Can only jump branches if we reached leaf of previous branch
        const unvisitedInBranch = this.levelConfig.nodes.some(
          (n) => n.branch === currentNode.branch && !this.visitedNodes.has(n.id)
        );
        if (unvisitedInBranch && !currentNode.isLeaf && currentNode.id !== 'node_Root') {
          playErrorSound();
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed(
              `DFS Breach! Must exhaust Branch ${currentNode.branch} all the way to its leaf terminus before switching branches!`
            );
          }
          return;
        }
      }
    }

    // Begin Movement
    this.isMoving = true;
    playNodeTravelSound();

    // Edge weight accumulation for Level 4
    if (this.levelConfig.type === 'dijkstra_shortest_path') {
      const edge = this.levelConfig.edges.find(
        (e) => (e.from === this.currentNodeId && e.to === targetId) || (e.from === targetId && e.to === this.currentNodeId)
      );
      if (edge && edge.weight) {
        this.accumulatedCost += edge.weight;
      }
    }

    // Rotate avatar towards destination
    const angle = Phaser.Math.Angle.Between(
      this.playerAvatar.x,
      this.playerAvatar.y,
      targetNode.x,
      targetNode.y
    );
    this.playerAvatar.setRotation(angle);

    // Tween avatar along road
    this.tweens.add({
      targets: this.playerAvatar,
      x: targetNode.x,
      y: targetNode.y,
      duration: 380,
      ease: 'Cubic.easeInOut',
      onComplete: () => {
        this.onArrivalAtNode(targetId);
      }
    });
  }

  private onArrivalAtNode(arrivedId: string) {
    this.isMoving = false;
    const oldNodeId = this.currentNodeId;
    this.currentNodeId = arrivedId;
    this.visitedNodes.add(arrivedId);
    this.currentPath.push(arrivedId);

    // Level 5 Collapsing rule: the old node collapses once left behind!
    if (this.levelConfig.type === 'avoid_visited_nodes') {
      this.collapsedNodes.add(oldNodeId);
      this.updateNodeVisual(oldNodeId);
    }

    // BFS ring advancement
    if (this.levelConfig.type === 'bfs_traversal') {
      const curr = this.getNode(arrivedId);
      if (curr && (curr.layer ?? 0) >= this.bfsCurrentLayer) {
        // Check if all nodes in this layer are visited
        const allLayerVisited = this.levelConfig.nodes
          .filter((n) => (n.layer ?? 0) === this.bfsCurrentLayer)
          .every((n) => this.visitedNodes.has(n.id));
        if (allLayerVisited) {
          this.bfsCurrentLayer++;
          playBfsWaveSound();
          this.triggerBfsPulse(curr.x, curr.y);
        }
      }
      // Update BFS Queue display
      this.bfsQueue = this.bfsQueue.filter((id) => id !== arrivedId);
    }

    // DFS Stack update
    if (this.levelConfig.type === 'dfs_traversal') {
      const curr = this.getNode(arrivedId);
      if (curr?.isLeaf) {
        playDfsBranchSound();
      }
      this.dfsStack.push(arrivedId);
    }

    // Collect energy cell if present
    const arrivedNode = this.getNode(arrivedId);
    if (arrivedNode?.hasEnergy && !this.collectedEnergyNodes.has(arrivedId)) {
      this.collectedEnergyNodes.add(arrivedId);
      playEnergyCellSound();

      // Destroy energy cell sprite with particle effect
      const cellSprite = this.energySprites.get(arrivedId);
      if (cellSprite) {
        this.tweens.add({
          targets: cellSprite,
          scaleX: 1.8,
          scaleY: 1.8,
          alpha: 0,
          duration: 250,
          onComplete: () => {
            cellSprite.destroy();
            this.energySprites.delete(arrivedId);
          }
        });
      }

      // Add coins
      const coinsGained = Math.round(5 * this.coinMultiplier);
      this.totalCoins += coinsGained;
      if (this.callbacks.onCoinCollected) {
        this.callbacks.onCoinCollected(this.totalCoins, coinsGained);
      }
      playCoinSound();
    }

    this.refreshAllNodeVisuals();
    this.emitProgress();

    // Check Win Condition
    this.checkVictoryCondition();
  }

  private checkVictoryCondition() {
    if (this.isLevelFinished) return;

    const currNode = this.getNode(this.currentNodeId);
    const collectedCount = this.collectedEnergyNodes.size;

    // Level 1: Collect 3 cells and reach Exit F
    if (this.levelConfig.type === 'graph_explore') {
      if (this.currentNodeId === this.levelConfig.exitNodeId) {
        if (collectedCount >= this.levelConfig.targetCount) {
          this.triggerLevelSuccess();
        } else {
          playErrorSound();
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed(
              `Extraction reached prematurely! You gathered ${collectedCount}/${this.levelConfig.targetCount} energy cells. Collect all cells first!`
            );
          }
        }
      }
    }

    // Level 2 (BFS): All nodes visited in BFS order
    else if (this.levelConfig.type === 'bfs_traversal') {
      if (collectedCount >= this.levelConfig.targetCount) {
        this.triggerLevelSuccess();
      }
    }

    // Level 3 (DFS): All branches visited deep-first
    else if (this.levelConfig.type === 'dfs_traversal') {
      if (collectedCount >= this.levelConfig.targetCount) {
        this.triggerLevelSuccess();
      }
    }

    // Level 4 (Dijkstra): Reached Safe Bunker
    else if (this.levelConfig.type === 'dijkstra_shortest_path') {
      if (this.currentNodeId === this.levelConfig.targetNodeId) {
        const optimal = this.levelConfig.optimalCost || 9;
        if (this.accumulatedCost <= optimal) {
          this.triggerLevelSuccess();
        } else {
          playErrorSound();
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed(
              `Safe Bunker reached, but route cost was ${this.accumulatedCost} (Optimal shortest path is ${optimal})! Glitch storm caught you.`
            );
          }
        }
      }
    }

    // Level 5 (Avoid Visited Nodes / Collapsing Grid): All 4 cells gathered and reach Central Citadel
    else if (this.levelConfig.type === 'avoid_visited_nodes') {
      if (this.currentNodeId === this.levelConfig.exitNodeId) {
        if (collectedCount >= this.levelConfig.targetCount) {
          this.triggerLevelSuccess();
        } else {
          playErrorSound();
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed(
              `Citadel reached, but only gathered ${collectedCount}/${this.levelConfig.targetCount} energy cells!`
            );
          }
        }
      }
    }
  }

  private triggerLevelSuccess() {
    this.isLevelFinished = true;
    playSuccessSound();

    const completionTime = Math.round(((this.time.now - this.startTime) / 1000) * 10) / 10;
    const targetTime = this.levelConfig.targetTime || 30;
    const perfect = completionTime <= targetTime;

    if (this.callbacks.onLevelComplete) {
      this.callbacks.onLevelComplete({
        itemsCleared: this.collectedEnergyNodes.size || 1,
        coinsCollected: this.totalCoins,
        completionTime,
        perfect
      });
    }
  }

  private refreshAllNodeVisuals() {
    this.levelConfig.nodes.forEach((n) => this.updateNodeVisual(n.id));
  }

  private updateNodeVisual(nodeId: string) {
    const container = this.nodeContainers.get(nodeId);
    const node = this.getNode(nodeId);
    if (!container || !node) return;

    const baseCircle = container.getByName('baseCircle') as Phaser.GameObjects.Arc;
    const glowDisc = container.getByName('glowDisc') as Phaser.GameObjects.Arc;
    if (!baseCircle || !glowDisc) return;

    const isCurrent = this.currentNodeId === nodeId;
    const isVisited = this.visitedNodes.has(nodeId);
    const isCollapsed = this.collapsedNodes.has(nodeId);
    const isNeighbor = this.getConnectedNeighbors(this.currentNodeId).includes(nodeId);

    if (isCollapsed) {
      // Shattered hazard void
      baseCircle.setFillStyle(0x450a0a, 0.8);
      baseCircle.setStrokeStyle(2, 0xef4444, 0.7);
      glowDisc.setFillStyle(0x7f1d1d, 0.1);
    } else if (isCurrent) {
      // Current active node
      baseCircle.setFillStyle(0x0284c7, 1);
      baseCircle.setStrokeStyle(3, 0x38bdf8, 1);
      glowDisc.setFillStyle(0x38bdf8, 0.4);
    } else if (isNeighbor) {
      // Valid jump destination
      baseCircle.setFillStyle(0x0f172a, 0.95);
      baseCircle.setStrokeStyle(2.5, 0xec4899, 0.95);
      glowDisc.setFillStyle(0xec4899, 0.25);
    } else if (isVisited) {
      // Previously visited node
      baseCircle.setFillStyle(0x1e293b, 0.85);
      baseCircle.setStrokeStyle(1.5, 0x64748b, 0.8);
      glowDisc.setFillStyle(0x475569, 0.1);
    } else if (node.isExit) {
      baseCircle.setFillStyle(0x78350f, 0.95);
      baseCircle.setStrokeStyle(2.5, 0xf59e0b, 1);
      glowDisc.setFillStyle(0xf59e0b, 0.3);
    } else {
      baseCircle.setFillStyle(0x0f172a, 0.95);
      baseCircle.setStrokeStyle(2, 0x38bdf8, 0.7);
      glowDisc.setFillStyle(0x06b6d4, 0.15);
    }
  }

  public getConnectedNeighbors(nodeId: string): string[] {
    const neighbors: string[] = [];
    this.levelConfig.edges.forEach((edge) => {
      if (edge.from === nodeId && !neighbors.includes(edge.to)) {
        neighbors.push(edge.to);
      } else if (edge.to === nodeId && !neighbors.includes(edge.from)) {
        neighbors.push(edge.from);
      }
    });
    return neighbors;
  }

  public getNode(nodeId: string): GraphNode | undefined {
    return this.levelConfig.nodes.find((n) => n.id === nodeId);
  }

  private emitProgress() {
    if (!this.callbacks.onProgressUpdate) return;

    this.callbacks.onProgressUpdate({
      current: this.collectedEnergyNodes.size,
      total: this.levelConfig.targetCount,
      coins: this.totalCoins,
      currentNodeId: this.currentNodeId,
      visitedNodes: Array.from(this.visitedNodes),
      availableNeighbors: this.getConnectedNeighbors(this.currentNodeId).filter(
        (id) => !this.collapsedNodes.has(id)
      ),
      accumulatedCost: this.accumulatedCost,
      safeZoneRadius: Math.round(this.safeZoneRadius),
      isOutsideZone: this.isOutsideZone,
      bfsQueue: this.bfsQueue,
      dfsStack: this.dfsStack
    });
  }

  /**
   * Public command for moving runner from UI button
   */
  public triggerMoveToNode(targetId: string) {
    this.handleNodeClick(targetId);
  }
}
