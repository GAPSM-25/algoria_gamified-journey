import Phaser from 'phaser';
import {
  playCoinSound,
  playErrorSound,
  playSuccessSound,
  playArraySlotClickSound,
  playArraySwapSound,
  playBinarySearchHalveSound,
  playRaceWinSound
} from '../../utils/audio.ts';

export interface ArrayArenaLevelConfig {
  id: number;
  type: string;
  targetCount: number;
  targetTime?: number;
  arrayData?: any[];
  queries?: any[];
  initialArray?: number[];
  sortedArray?: number[];
  targetValue?: number;
  targetArray?: number[];
  novaReplaySteps?: any[];
}

export interface ArrayArenaCallbacks {
  onProgressUpdate?: (data: {
    current: number;
    total: number;
    coins?: number;
    currentQueryIndex?: number;
    currentArray?: number[];
    low?: number;
    high?: number;
    mid?: number;
    botIndex?: number;
    playerSteps?: number;
    leftPtr?: number;
    rightPtr?: number;
    isSorting?: boolean;
    isReplaying?: boolean;
  }) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: {
    itemsCleared: number;
    coinsCollected: number;
    completionTime: number;
    perfect?: boolean;
  }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
  onNovaSpeak?: (message: string, mood?: string) => void;
}

export class ArrayArenaScene extends Phaser.Scene {
  private levelConfig!: ArrayArenaLevelConfig;
  private callbacks!: ArrayArenaCallbacks;
  private coinMultiplier = 1;

  // Level 1 state (Index lookup)
  private currentQueryIdx = 0;
  private queryCountCleared = 0;

  // Level 2 state (Bubble sort)
  private currentArrayState: number[] = [];
  private isSortingActive = false;
  private bubbleI = 0;
  private bubbleJ = 0;
  private autoSortTimer?: Phaser.Time.TimerEvent;

  // Level 3 state (Race)
  private botIndex = 0;
  private raceTarget = 81;
  private raceArray: number[] = [];
  private raceLow = 0;
  private raceHigh = 15;
  private raceMid = 7;
  private racePlayerSteps = 0;
  private botTimerEvent?: Phaser.Time.TimerEvent;

  // Level 4 state (Binary Search Halving)
  private bsArray: number[] = [];
  private bsLow = 0;
  private bsHigh = 8;
  private bsMid = 4;
  private bsTarget = 55;
  private discardedIndices: Set<number> = new Set();

  // Level 5 state (Two Pointers)
  private tpArray: number[] = [];
  private tpLeft = 0;
  private tpRight = 5;

  // Replay state
  private isReplaying = false;

  // Graphics and display elements
  private backgroundGraphics!: Phaser.GameObjects.Graphics;
  private slotContainers: Phaser.GameObjects.Container[] = [];
  private botRunnerContainer?: Phaser.GameObjects.Container;
  private playerRunnerContainer?: Phaser.GameObjects.Container;
  private pointerMarkersGraphics!: Phaser.GameObjects.Graphics;

  private totalCoins = 0;
  private startTime = 0;
  private isLevelFinished = false;

  constructor() {
    super({ key: 'ArrayArenaScene' });
  }

  init(data: {
    levelConfig: ArrayArenaLevelConfig;
    characterId?: string;
    coinMultiplier?: number;
    callbacks: ArrayArenaCallbacks;
  }) {
    if (this.autoSortTimer) {
      this.autoSortTimer.destroy();
      this.autoSortTimer = undefined;
    }
    if (this.botTimerEvent) {
      this.botTimerEvent.destroy();
      this.botTimerEvent = undefined;
    }

    this.levelConfig = data.levelConfig;
    this.callbacks = data.callbacks;
    this.coinMultiplier = data.coinMultiplier || 1;
    this.isLevelFinished = false;
    this.totalCoins = 0;
    this.isReplaying = false;

    // Reset Level 1
    this.currentQueryIdx = 0;
    this.queryCountCleared = 0;

    // Reset Level 2
    if (this.levelConfig.initialArray) {
      this.currentArrayState = [...this.levelConfig.initialArray];
    }
    this.isSortingActive = false;
    this.bubbleI = 0;
    this.bubbleJ = 0;

    // Reset Level 3
    if (this.levelConfig.type === 'search_race') {
      this.raceArray = this.levelConfig.arrayData || [];
      this.raceTarget = this.levelConfig.targetValue || 81;
      this.raceLow = 0;
      this.raceHigh = this.raceArray.length - 1;
      this.raceMid = Math.floor((this.raceLow + this.raceHigh) / 2);
      this.botIndex = 0;
      this.racePlayerSteps = 0;
    }

    // Reset Level 4
    if (this.levelConfig.type === 'binary_search_halving') {
      this.bsArray = this.levelConfig.arrayData || [];
      this.bsLow = 0;
      this.bsHigh = this.bsArray.length - 1;
      this.bsMid = Math.floor((this.bsLow + this.bsHigh) / 2);
      this.bsTarget = this.levelConfig.targetValue || 55;
      this.discardedIndices.clear();
    }

    // Reset Level 5
    if (this.levelConfig.type === 'two_pointers') {
      this.tpArray = [...(this.levelConfig.initialArray || [10, 20, 30, 40, 50, 60])];
      this.tpLeft = 0;
      this.tpRight = this.tpArray.length - 1;
    }
  }

  create() {
    this.startTime = this.time.now;

    this.backgroundGraphics = this.add.graphics();
    this.pointerMarkersGraphics = this.add.graphics();

    this.drawBackground();
    this.renderActiveLevel();

    // Start bot ticking if Level 3 Race
    if (this.levelConfig.type === 'search_race') {
      this.startBotLinearTicker();
    }

    this.emitProgress();
  }

  private drawBackground() {
    this.backgroundGraphics.clear();

    // Dark colosseum slate-950 backdrop
    this.backgroundGraphics.fillStyle(0x080914, 1);
    this.backgroundGraphics.fillRect(0, 0, 860, 360);

    // Grid bus track lines (Amber / Gold memory bus theme)
    this.backgroundGraphics.lineStyle(1, 0x1e293b, 0.4);
    for (let x = 0; x <= 860; x += 40) {
      this.backgroundGraphics.beginPath();
      this.backgroundGraphics.moveTo(x, 0);
      this.backgroundGraphics.lineTo(x, 360);
      this.backgroundGraphics.strokePath();
    }
    for (let y = 0; y <= 360; y += 40) {
      this.backgroundGraphics.beginPath();
      this.backgroundGraphics.moveTo(0, y);
      this.backgroundGraphics.lineTo(860, y);
      this.backgroundGraphics.strokePath();
    }

    // Golden memory bus borders
    this.backgroundGraphics.lineStyle(2, 0xf59e0b, 0.3);
    this.backgroundGraphics.strokeRect(12, 12, 836, 336);
  }

  private renderActiveLevel() {
    // Clear old slots
    this.slotContainers.forEach((c) => c.destroy());
    this.slotContainers = [];
    if (this.botRunnerContainer) this.botRunnerContainer.destroy();
    if (this.playerRunnerContainer) this.playerRunnerContainer.destroy();

    const type = this.levelConfig.type;
    if (type === 'array_index_lookup') {
      this.renderLevel1IndexSlots();
    } else if (type === 'bubble_sort') {
      this.renderLevel2BubbleSlots();
    } else if (type === 'search_race') {
      this.renderLevel3RaceCorridors();
    } else if (type === 'binary_search_halving') {
      this.renderLevel4HalvingSlots();
    } else if (type === 'two_pointers') {
      this.renderLevel5TwoPointers();
    }
  }

  // ==========================================
  // LEVEL 1: 0-INDEXED MEMORY SLOTS
  // ==========================================
  private renderLevel1IndexSlots() {
    const arr = this.levelConfig.arrayData || [];
    const slotWidth = 90;
    const spacing = 24;
    const totalWidth = arr.length * slotWidth + (arr.length - 1) * spacing;
    const startX = (860 - totalWidth) / 2 + slotWidth / 2;
    const slotY = 175;

    arr.forEach((item, idx) => {
      const x = startX + idx * (slotWidth + spacing);
      const container = this.add.container(x, slotY);

      // Memory slot card
      const slotBg = this.add.rectangle(0, 0, slotWidth, 110, 0x0f172a, 0.95);
      slotBg.setStrokeStyle(2, 0xf59e0b, 0.6);
      slotBg.setName('slotBg');

      // Top memory address badge (e.g. 0x1000)
      const addrText = this.add.text(0, -40, item.memoryAddr || `0x${(4096 + idx * 4).toString(16)}`, {
        fontSize: '10px',
        color: '#94a3b8',
        fontFamily: 'monospace'
      }).setOrigin(0.5);

      // Value Orb in center
      const orb = this.add.circle(0, 0, 22, 0x1e1b4b, 1);
      orb.setStrokeStyle(2.5, 0xfbbf24, 1);
      orb.setName('orb');

      const valText = this.add.text(0, 0, `${item.value}`, {
        fontSize: '16px',
        color: '#fef3c7',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      // Bottom index badge: [ 0 ], [ 1 ], ...
      const idxBadge = this.add.rectangle(0, 42, 54, 20, 0x1e293b, 1);
      idxBadge.setStrokeStyle(1.5, 0x38bdf8, 0.8);
      const idxText = this.add.text(0, 42, `[ ${idx} ]`, {
        fontSize: '12px',
        color: '#38bdf8',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      container.add([slotBg, addrText, orb, valText, idxBadge, idxText]);

      // Click to choose
      slotBg.setInteractive({ useHandCursor: true });
      slotBg.on('pointerdown', () => this.handleSlotClick(idx));
      slotBg.on('pointerover', () => {
        orb.setScale(1.15);
        slotBg.setStrokeStyle(2.5, 0x38bdf8, 1);
      });
      slotBg.on('pointerout', () => {
        orb.setScale(1);
        slotBg.setStrokeStyle(2, 0xf59e0b, 0.6);
      });

      this.slotContainers.push(container);
    });
  }

  public handleSlotClick(idx: number) {
    if (this.isLevelFinished) return;
    const queries = this.levelConfig.queries || [];
    if (this.currentQueryIdx >= queries.length) return;

    const currentQuery = queries[this.currentQueryIdx];

    if (idx === currentQuery.targetIndex) {
      // Correct!
      playArraySlotClickSound();
      this.queryCountCleared++;

      const container = this.slotContainers[idx];
      if (container) {
        this.tweens.add({
          targets: container,
          scaleX: 1.15,
          scaleY: 1.15,
          yoyo: true,
          duration: 180
        });
      }

      this.currentQueryIdx++;

      if (this.queryCountCleared >= queries.length) {
        this.triggerLevelSuccess();
      } else {
        const nextQ = queries[this.currentQueryIdx];
        if (this.callbacks.onNovaSpeak) {
          this.callbacks.onNovaSpeak(`Correct! Now: ${nextQ.prompt}`, 'proud');
        }
      }
      this.emitProgress();
    } else {
      // Wrong index
      playErrorSound();
      if (this.callbacks.onHeartLost) this.callbacks.onHeartLost();
      if (this.callbacks.onNovaSpeak) {
        this.callbacks.onNovaSpeak(`Oops! You selected arr[${idx}]. Remember: 0-indexed!`, 'surprised');
      }
    }
  }

  // ==========================================
  // LEVEL 2: BUBBLE SORT ARENA
  // ==========================================
  private renderLevel2BubbleSlots() {
    const arr = this.currentArrayState;
    const slotWidth = 100;
    const spacing = 20;
    const totalWidth = arr.length * slotWidth + (arr.length - 1) * spacing;
    const startX = (860 - totalWidth) / 2 + slotWidth / 2;
    const slotY = 175;

    const isAllSorted = arr.every((v, i, a) => !i || a[i - 1] <= v);

    arr.forEach((val, idx) => {
      const x = startX + idx * (slotWidth + spacing);
      const container = this.add.container(x, slotY);

      // An element is locked if it's placed in its final position or whole array is sorted
      const isLocked = isAllSorted || (idx >= arr.length - this.bubbleI && this.bubbleI > 0);
      const isComparing = !isAllSorted && !this.isLevelFinished && (idx === this.bubbleJ || idx === this.bubbleJ + 1);

      const strokeColor = isLocked ? 0x10b981 : isComparing ? 0x06b6d4 : 0xf59e0b;
      const orbColor = isLocked ? 0x064e3b : isComparing ? 0x083344 : 0x1e1b4b;
      const orbStroke = isLocked ? 0x34d399 : isComparing ? 0x22d3ee : 0xfbbf24;

      const slotBg = this.add.rectangle(0, 0, slotWidth, 120, 0x0f172a, 0.95);
      slotBg.setStrokeStyle(isComparing ? 2.5 : 2, strokeColor, isComparing ? 1 : 0.8);

      const orb = this.add.circle(0, -6, 26, orbColor, 1);
      orb.setStrokeStyle(2.5, orbStroke, 1);

      const valText = this.add.text(0, -6, `${val}`, {
        fontSize: '18px',
        color: isLocked ? '#a7f3d0' : isComparing ? '#67e8f9' : '#ffffff',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      const idxText = this.add.text(0, 42, `[ ${idx} ]`, {
        fontSize: '11px',
        color: isLocked ? '#34d399' : isComparing ? '#38bdf8' : '#94a3b8',
        fontFamily: 'monospace'
      }).setOrigin(0.5);

      container.add([slotBg, orb, valText, idxText]);

      // Allow manual comparison/swap on click when not auto-sorting
      slotBg.setInteractive({ useHandCursor: !this.isSortingActive });
      slotBg.on('pointerdown', () => {
        if (!this.isSortingActive && !this.isLevelFinished) {
          if (idx < arr.length - 1 && arr[idx] > arr[idx + 1]) {
            playArraySwapSound();
            const temp = arr[idx];
            arr[idx] = arr[idx + 1];
            arr[idx + 1] = temp;
            if (this.callbacks.onNovaSpeak) {
              this.callbacks.onNovaSpeak(`Manual Swap: Swapped ${arr[idx + 1]} and ${arr[idx]}!`, 'proud');
            }
            this.renderLevel2BubbleSlots();
            this.emitProgress();
            this.checkBubbleSortComplete();
          } else if (idx > 0 && arr[idx - 1] > arr[idx]) {
            playArraySwapSound();
            const temp = arr[idx - 1];
            arr[idx - 1] = arr[idx];
            arr[idx] = temp;
            if (this.callbacks.onNovaSpeak) {
              this.callbacks.onNovaSpeak(`Manual Swap: Swapped ${arr[idx]} and ${arr[idx - 1]}!`, 'proud');
            }
            this.renderLevel2BubbleSlots();
            this.emitProgress();
            this.checkBubbleSortComplete();
          } else {
            playArraySlotClickSound();
            if (this.callbacks.onNovaSpeak) {
              this.callbacks.onNovaSpeak(`Orb ${val} is in order relative to its neighbor! Use 'Step Compare' or 'Auto-Run' below!`, 'happy');
            }
          }
        }
      });

      this.slotContainers.push(container);
    });

    this.drawBubblePointers();
  }

  private drawBubblePointers() {
    this.pointerMarkersGraphics.clear();
    if (this.levelConfig.type !== 'bubble_sort' || this.isLevelFinished) return;

    const arr = this.currentArrayState;
    const isSorted = arr.every((v, i, a) => !i || a[i - 1] <= v);
    if (isSorted && this.bubbleI >= arr.length - 2) return;

    const j = this.bubbleJ;
    if (j < arr.length - 1 - this.bubbleI && this.slotContainers[j] && this.slotContainers[j + 1]) {
      const c1 = this.slotContainers[j];
      const c2 = this.slotContainers[j + 1];

      // Draw active comparing bracket below both
      this.pointerMarkersGraphics.lineStyle(3, 0x06b6d4, 1);
      this.pointerMarkersGraphics.beginPath();
      this.pointerMarkersGraphics.moveTo(c1.x - 36, 248);
      this.pointerMarkersGraphics.lineTo(c1.x - 36, 260);
      this.pointerMarkersGraphics.lineTo(c2.x + 36, 260);
      this.pointerMarkersGraphics.lineTo(c2.x + 36, 248);
      this.pointerMarkersGraphics.strokePath();

      // Compare icon text
      const midX = (c1.x + c2.x) / 2;
      this.pointerMarkersGraphics.fillStyle(0x06b6d4, 1);
      this.pointerMarkersGraphics.fillTriangle(midX, 250, midX - 7, 262, midX + 7, 262);
    }
  }

  private executeBubbleStep(): boolean {
    const arr = this.currentArrayState;
    const n = arr.length;

    if (this.bubbleI >= n - 1) {
      return false;
    }

    const j = this.bubbleJ;
    const isOutOfOrder = arr[j] > arr[j + 1];

    if (isOutOfOrder) {
      // Swap!
      playArraySwapSound();
      const temp = arr[j];
      arr[j] = arr[j + 1];
      arr[j + 1] = temp;

      if (this.callbacks.onNovaSpeak) {
        this.callbacks.onNovaSpeak(`Swapped ${arr[j + 1]} and ${arr[j]} because ${arr[j + 1]} > ${arr[j]}!`, 'proud');
      }
    } else {
      playArraySlotClickSound();
      if (this.callbacks.onNovaSpeak) {
        this.callbacks.onNovaSpeak(`${arr[j]} <= ${arr[j + 1]} — Already in order, no swap!`, 'happy');
      }
    }

    this.bubbleJ++;
    if (this.bubbleJ >= n - 1 - this.bubbleI) {
      this.bubbleJ = 0;
      this.bubbleI++;
      if (this.callbacks.onNovaSpeak && this.bubbleI < n) {
        const lockedVal = arr[n - this.bubbleI];
        this.callbacks.onNovaSpeak(`Pass ${this.bubbleI} completed! Largest remaining orb (${lockedVal}) bubbled to the end!`, 'excited');
      }
    }

    this.renderLevel2BubbleSlots();
    this.emitProgress();
    return true;
  }

  public stepBubbleSort() {
    if (this.isSortingActive || this.isLevelFinished) return;

    const isSorted = this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
    if (isSorted && this.bubbleI >= this.currentArrayState.length - 2) {
      this.triggerLevelSuccess();
      return;
    }

    this.executeBubbleStep();

    const nowSorted = this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
    if (nowSorted && (this.bubbleI >= this.currentArrayState.length - 2 || this.bubbleJ === 0)) {
      this.triggerLevelSuccess();
    }
  }

  public autoRunBubbleSort() {
    if (this.isSortingActive || this.isLevelFinished) return;
    this.isSortingActive = true;
    this.emitProgress();

    if (this.callbacks.onNovaSpeak) {
      this.callbacks.onNovaSpeak('Auto-Run Bubble Sort initiated! Watch adjacent pairs compare and bubble to the right...', 'excited');
    }

    if (this.autoSortTimer) {
      this.autoSortTimer.destroy();
      this.autoSortTimer = undefined;
    }

    const runLoop = () => {
      if (this.isLevelFinished || !this.scene.isActive()) {
        this.isSortingActive = false;
        this.emitProgress();
        return;
      }

      const isSorted = this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
      const n = this.currentArrayState.length;

      // If array is sorted and passes finished
      if (isSorted && (this.bubbleI >= n - 2 || this.bubbleJ === 0)) {
        this.isSortingActive = false;
        this.emitProgress();
        this.renderLevel2BubbleSlots();
        this.triggerLevelSuccess();
        return;
      }

      if (this.bubbleI >= n - 1) {
        this.isSortingActive = false;
        this.emitProgress();
        this.renderLevel2BubbleSlots();
        this.checkBubbleSortComplete();
        return;
      }

      const stepped = this.executeBubbleStep();
      if (!stepped) {
        this.isSortingActive = false;
        this.emitProgress();
        this.renderLevel2BubbleSlots();
        this.checkBubbleSortComplete();
        return;
      }

      // Check after stepping
      const nowSorted = this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
      if (nowSorted && (this.bubbleI >= n - 2 || this.bubbleJ === 0)) {
        this.isSortingActive = false;
        this.emitProgress();
        this.renderLevel2BubbleSlots();
        this.triggerLevelSuccess();
        return;
      }

      // Delay between steps for clear visibility (500ms)
      this.autoSortTimer = this.time.delayedCall(500, runLoop);
    };

    // First step after 200ms
    this.autoSortTimer = this.time.delayedCall(200, runLoop);
  }

  private checkBubbleSortComplete() {
    const isSorted = this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
    if (isSorted && !this.isLevelFinished) {
      this.isSortingActive = false;
      this.emitProgress();
      this.triggerLevelSuccess();
    }
  }

  // ==========================================
  // LEVEL 3: RACE (LINEAR VS BINARY SEARCH)
  // ==========================================
  private renderLevel3RaceCorridors() {
    const arr = this.raceArray;
    const slotW = 44;
    const spacing = 6;
    const startX = 50;

    // Corridor 1: Top Lane (Linear Search Bot)
    this.add.text(startX, 45, 'CORRIDOR A: ROGUE BOT (Linear Search O(N))', {
      fontSize: '11px',
      color: '#ef4444',
      fontFamily: 'monospace',
      fontStyle: 'bold'
    });

    // Corridor 2: Bottom Lane (Player Binary Search)
    this.add.text(startX, 185, 'CORRIDOR B: PLAYER / NOVA (Binary Search O(log N))', {
      fontSize: '11px',
      color: '#38bdf8',
      fontFamily: 'monospace',
      fontStyle: 'bold'
    });

    // Render Bottom Lane 16 items
    arr.forEach((val, idx) => {
      const x = startX + idx * (slotW + spacing);
      const isEliminated = idx < this.raceLow || idx > this.raceHigh;
      const isMid = idx === this.raceMid;
      const isFound = val === this.raceTarget && this.raceLow === this.raceHigh;

      const container = this.add.container(x, 260);

      const strokeCol = isFound ? 0x10b981 : isMid ? 0x38bdf8 : isEliminated ? 0x334155 : 0xf59e0b;
      const bg = this.add.rectangle(0, 0, slotW, 60, isEliminated ? 0x050810 : 0x0f172a, isEliminated ? 0.4 : 0.95);
      bg.setStrokeStyle(isMid ? 2.5 : 1.5, strokeCol, isEliminated ? 0.3 : 1);

      const txt = this.add.text(0, -6, `${val}`, {
        fontSize: '13px',
        color: isEliminated ? '#475569' : isFound ? '#10b981' : '#ffffff',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      const idxLabel = this.add.text(0, 18, `${idx}`, {
        fontSize: '9px',
        color: '#64748b',
        fontFamily: 'monospace'
      }).setOrigin(0.5);

      container.add([bg, txt, idxLabel]);
      this.slotContainers.push(container);
    });

    // Bot Top Runner Avatar
    this.renderBotRunner();
  }

  private renderBotRunner() {
    if (this.botRunnerContainer) this.botRunnerContainer.destroy();

    const startX = 50;
    const slotW = 44;
    const spacing = 6;
    const botX = startX + this.botIndex * (slotW + spacing);

    this.botRunnerContainer = this.add.container(botX, 105);

    const botBox = this.add.rectangle(0, 0, 38, 38, 0x7f1d1d, 1);
    botBox.setStrokeStyle(2, 0xef4444, 1);

    const botEye = this.add.circle(0, -3, 6, 0xff0000, 1);
    const botLabel = this.add.text(0, 24, `Slot ${this.botIndex}`, {
      fontSize: '9px',
      color: '#f87171',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.botRunnerContainer.add([botBox, botEye, botLabel]);
  }

  private startBotLinearTicker() {
    this.botTimerEvent = this.time.addEvent({
      delay: 1800, // Moves 1 slot every 1.8s
      loop: true,
      callback: () => {
        if (this.isLevelFinished) return;
        this.botIndex++;
        this.renderBotRunner();
        this.emitProgress();

        if (this.raceArray[this.botIndex] === this.raceTarget) {
          // Bot reached target first
          if (this.callbacks.onLevelFailed) {
            this.callbacks.onLevelFailed('The Linear Search Bot reached the target first! Halve faster with Binary Search!');
          }
        }
      }
    });
  }

  public stepBinarySearchRace() {
    if (this.isLevelFinished) return;
    const midVal = this.raceArray[this.raceMid];
    this.racePlayerSteps++;
    playBinarySearchHalveSound();

    if (midVal === this.raceTarget) {
      // Reached target!
      playRaceWinSound();
      if (this.botTimerEvent) this.botTimerEvent.destroy();
      this.triggerLevelSuccess();
      return;
    }

    if (midVal < this.raceTarget) {
      this.raceLow = this.raceMid + 1;
    } else {
      this.raceHigh = this.raceMid - 1;
    }

    this.raceMid = Math.floor((this.raceLow + this.raceHigh) / 2);
    this.renderActiveLevel();
    this.emitProgress();
  }

  // ==========================================
  // LEVEL 4: BINARY SEARCH WITH HALVING
  // ==========================================
  private renderLevel4HalvingSlots() {
    const arr = this.bsArray;
    const slotW = 76;
    const spacing = 14;
    const totalW = arr.length * slotW + (arr.length - 1) * spacing;
    const startX = (860 - totalW) / 2 + slotW / 2;

    arr.forEach((val, idx) => {
      const x = startX + idx * (slotW + spacing);
      const isDiscarded = this.discardedIndices.has(idx);
      const isMid = idx === this.bsMid && !isDiscarded;
      const isLow = idx === this.bsLow && !isDiscarded;
      const isHigh = idx === this.bsHigh && !isDiscarded;

      const container = this.add.container(x, 175);

      const strokeCol = isMid ? 0x38bdf8 : isDiscarded ? 0x1e293b : 0xf59e0b;
      const slotBg = this.add.rectangle(0, 0, slotW, 110, 0x0f172a, isDiscarded ? 0.3 : 0.95);
      slotBg.setStrokeStyle(isMid ? 2.5 : 1.5, strokeCol, isDiscarded ? 0.2 : 0.8);

      const orb = this.add.circle(0, -6, 20, isDiscarded ? 0x0f172a : isMid ? 0x0369a1 : 0x1e1b4b, 1);
      orb.setStrokeStyle(2, isMid ? 0x38bdf8 : 0xfbbf24, isDiscarded ? 0.2 : 1);

      const valTxt = this.add.text(0, -6, `${val}`, {
        fontSize: '15px',
        color: isDiscarded ? '#475569' : '#ffffff',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      const idxTxt = this.add.text(0, 40, `[ ${idx} ]`, {
        fontSize: '10px',
        color: isDiscarded ? '#334155' : '#94a3b8',
        fontFamily: 'monospace'
      }).setOrigin(0.5);

      // Pointers badges above
      if (isLow && isHigh) {
        const ptrTxt = this.add.text(0, -42, 'LOW=HIGH', {
          fontSize: '9px',
          color: '#34d399',
          fontFamily: 'monospace',
          fontStyle: 'bold'
        }).setOrigin(0.5);
        container.add(ptrTxt);
      } else if (isLow) {
        const ptrTxt = this.add.text(0, -42, 'LOW ▲', {
          fontSize: '9px',
          color: '#34d399',
          fontFamily: 'monospace',
          fontStyle: 'bold'
        }).setOrigin(0.5);
        container.add(ptrTxt);
      } else if (isHigh) {
        const ptrTxt = this.add.text(0, -42, 'HIGH ▲', {
          fontSize: '9px',
          color: '#f87171',
          fontFamily: 'monospace',
          fontStyle: 'bold'
        }).setOrigin(0.5);
        container.add(ptrTxt);
      }

      container.add([slotBg, orb, valTxt, idxTxt]);
      this.slotContainers.push(container);
    });
  }

  public halveBinarySearch(direction: 'left' | 'right' | 'found') {
    if (this.isLevelFinished) return;
    const midVal = this.bsArray[this.bsMid];

    if (direction === 'found') {
      if (midVal === this.bsTarget) {
        playRaceWinSound();
        this.triggerLevelSuccess();
      } else {
        playErrorSound();
        if (this.callbacks.onHeartLost) this.callbacks.onHeartLost();
      }
      return;
    }

    playBinarySearchHalveSound();

    if (direction === 'left') {
      // Discard left half (low to mid)
      for (let i = this.bsLow; i <= this.bsMid; i++) {
        this.discardedIndices.add(i);
      }
      this.bsLow = this.bsMid + 1;
    } else {
      // Discard right half (mid to high)
      for (let i = this.bsMid; i <= this.bsHigh; i++) {
        this.discardedIndices.add(i);
      }
      this.bsHigh = this.bsMid - 1;
    }

    this.bsMid = Math.floor((this.bsLow + this.bsHigh) / 2);
    this.renderLevel4HalvingSlots();
    this.emitProgress();

    if (this.bsArray[this.bsMid] === this.bsTarget) {
      if (this.callbacks.onNovaSpeak) {
        this.callbacks.onNovaSpeak(`Target ${this.bsTarget} is right at MID (index ${this.bsMid})! Confirm target to claim victory!`, 'excited');
      }
    }
  }

  // ==========================================
  // LEVEL 5: TWO POINTERS COLOSSEUM
  // ==========================================
  private renderLevel5TwoPointers() {
    const arr = this.tpArray;
    const slotW = 90;
    const spacing = 18;
    const totalW = arr.length * slotW + (arr.length - 1) * spacing;
    const startX = (860 - totalW) / 2 + slotW / 2;

    arr.forEach((val, idx) => {
      const x = startX + idx * (slotW + spacing);
      const isLeft = idx === this.tpLeft;
      const isRight = idx === this.tpRight;
      const isSwapped = idx < this.tpLeft || idx > this.tpRight;

      const container = this.add.container(x, 175);

      const strokeCol = isLeft ? 0x06b6d4 : isRight ? 0xec4899 : isSwapped ? 0x10b981 : 0xf59e0b;
      const slotBg = this.add.rectangle(0, 0, slotW, 110, 0x0f172a, 0.95);
      slotBg.setStrokeStyle(isLeft || isRight ? 2.5 : 1.5, strokeCol, 0.9);

      const orb = this.add.circle(0, -6, 22, isSwapped ? 0x064e3b : 0x1e1b4b, 1);
      orb.setStrokeStyle(2, strokeCol, 1);

      const valTxt = this.add.text(0, -6, `${val}`, {
        fontSize: '16px',
        color: '#ffffff',
        fontFamily: 'monospace',
        fontStyle: 'bold'
      }).setOrigin(0.5);

      const idxTxt = this.add.text(0, 40, `[ ${idx} ]`, {
        fontSize: '11px',
        color: '#94a3b8',
        fontFamily: 'monospace'
      }).setOrigin(0.5);

      if (isLeft) {
        const ptrTxt = this.add.text(0, -42, 'LEFT [L]', {
          fontSize: '10px',
          color: '#38bdf8',
          fontFamily: 'monospace',
          fontStyle: 'bold'
        }).setOrigin(0.5);
        container.add(ptrTxt);
      }
      if (isRight) {
        const ptrTxt = this.add.text(0, -42, 'RIGHT [R]', {
          fontSize: '10px',
          color: '#f472b6',
          fontFamily: 'monospace',
          fontStyle: 'bold'
        }).setOrigin(0.5);
        container.add(ptrTxt);
      }

      container.add([slotBg, orb, valTxt, idxTxt]);
      this.slotContainers.push(container);
    });
  }

  public stepTwoPointersSwap() {
    if (this.isLevelFinished) return;
    if (this.tpLeft >= this.tpRight) {
      this.triggerLevelSuccess();
      return;
    }

    playArraySwapSound();

    // Swap values at left and right
    const temp = this.tpArray[this.tpLeft];
    this.tpArray[this.tpLeft] = this.tpArray[this.tpRight];
    this.tpArray[this.tpRight] = temp;

    this.tpLeft++;
    this.tpRight--;

    this.renderLevel5TwoPointers();
    this.emitProgress();

    if (this.tpLeft >= this.tpRight) {
      playRaceWinSound();
      this.triggerLevelSuccess();
    }
  }

  // ==========================================
  // "WATCH NOVA DO IT" REPLAY ENGINE
  // ==========================================
  public runNovaReplay() {
    if (this.isReplaying || this.isLevelFinished) return;
    this.isReplaying = true;
    this.emitProgress();

    const steps = this.levelConfig.novaReplaySteps || [];
    let stepIndex = 0;

    const replayTimer = this.time.addEvent({
      delay: 1500,
      repeat: steps.length,
      callback: () => {
        if (stepIndex >= steps.length || this.isLevelFinished) {
          replayTimer.destroy();
          this.isReplaying = false;
          if (this.callbacks.onNovaSpeak) {
            this.callbacks.onNovaSpeak('That is how the algorithm executes! Now take the controls and try it yourself!', 'proud');
          }
          this.emitProgress();
          return;
        }

        const step = steps[stepIndex];
        stepIndex++;

        if (this.callbacks.onNovaSpeak && step.speech) {
          this.callbacks.onNovaSpeak(step.speech, 'excited');
        }

        if (this.levelConfig.type === 'array_index_lookup' && step.index !== undefined) {
          this.handleSlotClick(step.index);
        } else if (this.levelConfig.type === 'bubble_sort') {
          this.stepBubbleSort();
        } else if (this.levelConfig.type === 'search_race') {
          this.stepBinarySearchRace();
        } else if (this.levelConfig.type === 'binary_search_halving') {
          if (this.bsArray[this.bsMid] === this.bsTarget) {
            this.halveBinarySearch('found');
          } else if (this.bsArray[this.bsMid] < this.bsTarget) {
            this.halveBinarySearch('left');
          } else {
            this.halveBinarySearch('right');
          }
        } else if (this.levelConfig.type === 'two_pointers') {
          this.stepTwoPointersSwap();
        }
      }
    });
  }

  private triggerLevelSuccess() {
    this.isLevelFinished = true;
    playSuccessSound();

    const completionTime = Math.round(((this.time.now - this.startTime) / 1000) * 10) / 10;
    const targetTime = this.levelConfig.targetTime || 30;
    const perfect = completionTime <= targetTime;

    if (this.callbacks.onLevelComplete) {
      this.callbacks.onLevelComplete({
        itemsCleared: this.levelConfig.targetCount,
        coinsCollected: this.totalCoins,
        completionTime,
        perfect
      });
    }
  }

  private emitProgress() {
    if (!this.callbacks.onProgressUpdate) return;
    const isBubble = this.levelConfig.type === 'bubble_sort';
    const isSorted = isBubble && this.currentArrayState.every((v, i, a) => !i || a[i - 1] <= v);
    const bubbleCurrent = isSorted ? 5 : Math.min(5, Math.max(1, this.bubbleI + 1));

    this.callbacks.onProgressUpdate({
      current: this.queryCountCleared || (isBubble ? bubbleCurrent : this.racePlayerSteps || 1),
      total: this.levelConfig.targetCount,
      coins: this.totalCoins,
      currentQueryIndex: this.currentQueryIdx,
      currentArray: this.currentArrayState,
      low: this.levelConfig.type === 'search_race' ? this.raceLow : this.bsLow,
      high: this.levelConfig.type === 'search_race' ? this.raceHigh : this.bsHigh,
      mid: this.levelConfig.type === 'search_race' ? this.raceMid : this.bsMid,
      botIndex: this.botIndex,
      playerSteps: this.racePlayerSteps,
      leftPtr: this.tpLeft,
      rightPtr: this.tpRight,
      isSorting: this.isSortingActive,
      isReplaying: this.isReplaying
    });
  }
}
