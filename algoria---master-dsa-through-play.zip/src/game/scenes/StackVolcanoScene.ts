import Phaser from 'phaser';
import {
  playPushSound,
  playPopSound,
  playPeekSound,
  playLavaSizzle,
  playSuccessSound,
  playErrorSound,
  playCoinSound
} from '../../utils/audio.ts';

export interface StackRock {
  id: string;
  label: string;
  color?: string;
  value?: number;
  unstable?: boolean;
  isFaulty?: boolean;
}

export interface StackLevelConfig {
  id: number;
  type: string;
  targetCount?: number;
  initialStack?: StackRock[];
  availableRocks?: StackRock[];
  targetWord?: string[];
  wordLetters?: string[];
  targetReversed?: string[];
}

export interface StackSceneCallbacks {
  onStackChanged?: (stack: StackRock[]) => void;
  onPeekTriggered?: (topRock: StackRock | null) => void;
  onCoinCollected?: (totalCoins: number, value: number) => void;
  onHeartLost?: () => void;
  onLevelComplete?: (stats: { itemsStacked: number; completionTime: number; coinsCollected: number }) => void;
  onLevelFailed?: (reason: string) => void;
}

export class StackVolcanoScene extends Phaser.Scene {
  private levelConfig!: StackLevelConfig;
  private callbacks!: StackSceneCallbacks;
  private characterId: string = 'bit_byte';
  private coinMultiplier: number = 1;
  private levelStartTime: number = 0;

  // Visual Objects
  private currentStack: StackRock[] = [];
  private rockSprites: Phaser.GameObjects.Container[] = [];
  private topIndicator!: Phaser.GameObjects.Container;
  private lavaPool!: Phaser.GameObjects.Rectangle;
  private lavaGlow!: Phaser.GameObjects.Rectangle;
  private steamParticles!: Phaser.GameObjects.Particles.ParticleEmitter;
  private emberParticles!: Phaser.GameObjects.Particles.ParticleEmitter;
  private pedestalPlatform!: Phaser.GameObjects.Rectangle;
  private stackPillars!: Phaser.GameObjects.Graphics;
  private playerSpriteContainer?: Phaser.GameObjects.Container;

  // Level State
  private isGameOver: boolean = false;
  private isVictory: boolean = false;
  private coinsCollected: number = 0;
  private reversedPoppedLetters: string[] = [];
  private hasPeeked: boolean = false;

  // Geometry
  private stackBaseX: number = 430;
  private stackBaseY: number = 270;
  private rockHeight: number = 38;
  private rockWidth: number = 140;

  constructor() {
    super({ key: 'StackVolcanoScene' });
  }

  init(data: {
    levelConfig: StackLevelConfig;
    callbacks: StackSceneCallbacks;
    characterId: string;
    coinMultiplier?: number;
  }) {
    this.levelConfig = data.levelConfig;
    this.callbacks = data.callbacks || {};
    this.characterId = data.characterId || 'bit_byte';
    this.coinMultiplier = data.coinMultiplier || 1;
    this.currentStack = [];
    this.rockSprites = [];
    this.isGameOver = false;
    this.isVictory = false;
    this.coinsCollected = 0;
    this.reversedPoppedLetters = [];
    this.hasPeeked = false;
  }

  preload() {
    // Generate Procedural Textures for Volcano
    if (!this.textures.exists('volcano_rock')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      // Basalt boulder rounded rectangle
      g.fillStyle(0x27272a, 1);
      g.fillRoundedRect(0, 0, 140, 36, 8);
      // Molten veins
      g.lineStyle(2, 0xf97316, 0.9);
      g.strokeRoundedRect(0, 0, 140, 36, 8);
      g.beginPath();
      g.moveTo(20, 18);
      g.lineTo(50, 18);
      g.lineTo(65, 26);
      g.lineTo(120, 26);
      g.stroke();
      g.generateTexture('volcano_rock', 140, 36);
      g.destroy();
    }

    if (!this.textures.exists('volcano_ember')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0xf59e0b, 1);
      g.fillCircle(4, 4, 4);
      g.fillStyle(0xffffff, 0.8);
      g.fillCircle(4, 4, 2);
      g.generateTexture('volcano_ember', 8, 8);
      g.destroy();
    }

    if (!this.textures.exists('steam_cloud')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0x71717a, 0.4);
      g.fillCircle(12, 12, 12);
      g.generateTexture('steam_cloud', 24, 24);
      g.destroy();
    }
  }

  create() {
    const { width, height } = this.scale;
    this.levelStartTime = Date.now();

    // 1. Volcano Crater Parallax Background
    this.createVolcanoBackdrop(width, height);

    // 2. Stack Pedestal and Guide Tube
    this.createStackPedestal(width);

    // 3. Molten Lava Pool at Bottom
    this.createLavaPool(width, height);

    // 4. TOP pointer indicator
    this.createTopIndicator();

    // 5. Populate initial stack if defined in level config
    if (this.levelConfig.initialStack && this.levelConfig.initialStack.length > 0) {
      this.levelConfig.initialStack.forEach((rock) => {
        this.pushRockDirect(rock, false);
      });
    }

    this.updateTopIndicator();

    // 6. Player Vantage Ledge
    this.createPlayerLedge();

    if (this.callbacks.onStackChanged) {
      this.callbacks.onStackChanged([...this.currentStack]);
    }
  }

  private createVolcanoBackdrop(width: number, height: number) {
    // Obsidian dark sky
    const sky = this.add.graphics();
    sky.fillGradientStyle(0x180816, 0x180816, 0x450a0a, 0x450a0a, 1);
    sky.fillRect(0, 0, width, height);

    // Volcanic caldera silhouette
    const caldera = this.add.graphics();
    caldera.fillStyle(0x1c1917, 1);
    caldera.beginPath();
    caldera.moveTo(0, height);
    caldera.lineTo(0, height - 140);
    caldera.lineTo(160, height - 230);
    caldera.lineTo(260, height - 170);
    caldera.lineTo(430, height - 90);
    caldera.lineTo(600, height - 180);
    caldera.lineTo(720, height - 240);
    caldera.lineTo(width, height - 140);
    caldera.lineTo(width, height);
    caldera.closePath();
    caldera.fill();

    // Glowing crater veins
    caldera.lineStyle(3, 0xef4444, 0.7);
    caldera.beginPath();
    caldera.moveTo(120, height - 180);
    caldera.lineTo(240, height - 150);
    caldera.lineTo(340, height - 110);
    caldera.moveTo(520, height - 120);
    caldera.lineTo(640, height - 160);
    caldera.stroke();

    // Rising Ember Particles
    this.emberParticles = this.add.particles(width / 2, height - 40, 'volcano_ember', {
      speed: { min: 20, max: 90 },
      angle: { min: 250, max: 290 },
      scale: { start: 0.8, end: 0 },
      alpha: { start: 0.8, end: 0 },
      lifespan: 3200,
      quantity: 2,
      frequency: 200
    });
  }

  private createStackPedestal(width: number) {
    const px = this.stackBaseX;
    const py = this.stackBaseY;

    // Basalt foundation platform
    this.pedestalPlatform = this.add.rectangle(px, py + 18, 180, 22, 0x09090b);
    this.pedestalPlatform.setStrokeStyle(2, 0xf97316);

    // Vertical containment pillar rails
    this.stackPillars = this.add.graphics();
    this.stackPillars.lineStyle(2, 0x7c2d12, 0.8);
    // Left rail
    this.stackPillars.lineBetween(px - 85, py + 10, px - 85, py - 200);
    // Right rail
    this.stackPillars.lineBetween(px + 85, py + 10, px + 85, py - 200);

    // Slot notches
    for (let i = 0; i < 5; i++) {
      const slotY = py - i * this.rockHeight;
      this.stackPillars.lineStyle(1, 0x57534e, 0.4);
      this.stackPillars.lineBetween(px - 80, slotY, px - 72, slotY);
      this.stackPillars.lineBetween(px + 72, slotY, px + 80, slotY);

      // Slot index text
      this.add.text(px - 95, slotY - 6, `${i}`, {
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: '10px',
        color: '#78716c'
      }).setOrigin(1, 0.5);
    }

    // Label: "STACK TOWER [LIFO]"
    this.add.text(px, py + 26, 'CONTAINMENT PEDESTAL [LIFO]', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '10px',
      color: '#fb923c'
    }).setOrigin(0.5);
  }

  private createPlayerLedge() {
    const lx = 140;
    const ly = 230;

    // Obsidian vantage cliff
    const cliff = this.add.graphics();
    cliff.fillStyle(0x18181b, 1);
    cliff.beginPath();
    cliff.moveTo(lx - 50, ly + 25);
    cliff.lineTo(lx + 50, ly + 25);
    cliff.lineTo(lx + 35, ly + 90);
    cliff.lineTo(lx - 60, ly + 90);
    cliff.closePath();
    cliff.fill();
    cliff.lineStyle(2, 0xf97316, 0.7);
    cliff.lineBetween(lx - 50, ly + 25, lx + 50, ly + 25);

    // Character container
    this.playerSpriteContainer = this.add.container(lx, ly);

    let primaryColor = 0x06b6d4;
    let secondaryColor = 0x38bdf8;
    let label = 'BIT BYTE';

    if (this.characterId === 'algo_fox') {
      primaryColor = 0xea580c;
      secondaryColor = 0xfbbf24;
      label = 'ALGO FOX';
    } else if (this.characterId === 'cyber_nova') {
      primaryColor = 0xa855f7;
      secondaryColor = 0xec4899;
      label = 'CYBER NOVA';
    } else if (this.characterId === 'pixel_knight') {
      primaryColor = 0x10b981;
      secondaryColor = 0x34d399;
      label = 'PIXEL KNIGHT';
    }

    const body = this.add.rectangle(0, 0, 18, 22, primaryColor);
    const head = this.add.rectangle(0, -15, 16, 14, primaryColor);
    const visor = this.add.rectangle(3, -15, 8, 5, secondaryColor);
    const tag = this.add.text(0, -28, label, {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '8px',
      color: '#cbd5e1'
    }).setOrigin(0.5);

    this.playerSpriteContainer.add([body, head, visor, tag]);
    this.playerSpriteContainer.setDepth(15);

    // Idle breathing bob
    this.tweens.add({
      targets: this.playerSpriteContainer,
      y: ly - 3,
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
  }

  private createLavaPool(width: number, height: number) {
    // Rising bubbling lava
    this.lavaPool = this.add.rectangle(width / 2, height - 14, width, 28, 0xd97706);
    this.lavaGlow = this.add.rectangle(width / 2, height - 26, width, 6, 0xfbbf24);

    // Lava glow tween
    this.tweens.add({
      targets: this.lavaGlow,
      alpha: 0.4,
      yoyo: true,
      repeat: -1,
      duration: 800,
      ease: 'Sine.easeInOut'
    });
  }

  private createTopIndicator() {
    this.topIndicator = this.add.container(this.stackBaseX + 95, this.stackBaseY);

    const arrow = this.add.text(0, 0, '◀ TOP', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '13px',
      fontStyle: 'bold',
      color: '#38bdf8'
    }).setOrigin(0, 0.5);

    this.topIndicator.add(arrow);

    // Gentle bounce animation
    this.tweens.add({
      targets: this.topIndicator,
      x: this.stackBaseX + 102,
      duration: 500,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });

    this.topIndicator.setVisible(false);
  }

  private updateTopIndicator() {
    if (this.currentStack.length === 0) {
      this.topIndicator.setVisible(false);
    } else {
      this.topIndicator.setVisible(true);
      const topIdx = this.currentStack.length - 1;
      const targetY = this.stackBaseY - topIdx * this.rockHeight;
      this.topIndicator.y = targetY;
    }
  }

  /**
   * PUSH Operation
   */
  public pushRock(rock: StackRock) {
    if (this.isGameOver || this.isVictory) return;
    this.pushRockDirect(rock, true);

    // Check level-specific goals
    this.evaluateLevelState();
  }

  private pushRockDirect(rock: StackRock, animate: boolean = true) {
    const slotIndex = this.currentStack.length;
    this.currentStack.push(rock);

    const targetX = this.stackBaseX;
    const targetY = this.stackBaseY - slotIndex * this.rockHeight;

    // Create rock container
    const container = this.add.container(targetX, animate ? targetY - 120 : targetY);

    // Rock body
    const colorHex = rock.color ? Phaser.Display.Color.HexStringToColor(rock.color).color : 0x27272a;
    const rockBox = this.add.rectangle(0, 0, this.rockWidth, 32, 0x18181b);
    rockBox.setStrokeStyle(2, colorHex);

    // Molten Core Glow
    const rockCore = this.add.rectangle(0, 0, this.rockWidth - 8, 24, colorHex, 0.4);

    // Label
    const textLabel = this.add.text(0, 0, rock.label, {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '12px',
      fontStyle: 'bold',
      color: '#ffffff'
    }).setOrigin(0.5);

    container.add([rockBox, rockCore, textLabel]);
    this.rockSprites.push(container);

    if (animate) {
      playPushSound();
      this.tweens.add({
        targets: container,
        y: targetY,
        duration: 250,
        ease: 'Bounce.easeOut',
        onComplete: () => {
          this.spawnLandingEmbers(targetX, targetY);
          this.updateTopIndicator();
        }
      });
    }

    this.updateTopIndicator();

    if (this.callbacks.onStackChanged) {
      this.callbacks.onStackChanged([...this.currentStack]);
    }
  }

  /**
   * POP Operation
   */
  public popRock(): StackRock | null {
    if (this.isGameOver || this.isVictory) return null;
    if (this.currentStack.length === 0) {
      playErrorSound();
      return null;
    }

    playPopSound();
    const poppedRock = this.currentStack.pop()!;
    const sprite = this.rockSprites.pop();

    if (sprite) {
      // Pop upward animation with steam
      this.tweens.add({
        targets: sprite,
        y: sprite.y - 70,
        alpha: 0,
        scaleX: 1.3,
        scaleY: 1.3,
        duration: 220,
        ease: 'Cubic.easeOut',
        onComplete: () => {
          this.spawnSteamBlast(sprite.x, sprite.y - 40);
          sprite.destroy();
          this.updateTopIndicator();
          this.evaluateLevelState(poppedRock);
        }
      });
    } else {
      this.updateTopIndicator();
      this.evaluateLevelState(poppedRock);
    }

    if (this.callbacks.onStackChanged) {
      this.callbacks.onStackChanged([...this.currentStack]);
    }

    return poppedRock;
  }

  /**
   * PEEK Operation
   */
  public peekTop(): StackRock | null {
    if (this.currentStack.length === 0) {
      playErrorSound();
      return null;
    }

    playPeekSound();
    const topRock = this.currentStack[this.currentStack.length - 1];
    const topSprite = this.rockSprites[this.rockSprites.length - 1];

    if (topSprite) {
      // Golden inspection glow pulse
      this.tweens.add({
        targets: topSprite,
        scaleX: 1.15,
        scaleY: 1.15,
        yoyo: true,
        duration: 220,
        repeat: 1
      });

      // Shimmering inspection ring
      this.spawnPeekSparkles(topSprite.x, topSprite.y);
    }

    this.hasPeeked = true;

    if (this.callbacks.onPeekTriggered) {
      this.callbacks.onPeekTriggered(topRock);
    }

    // Evaluate for Level 3
    if (this.levelConfig.id === 3) {
      this.time.delayedCall(400, () => {
        this.handleLevelVictory();
      });
    }

    return topRock;
  }

  private evaluateLevelState(lastPoppedRock?: StackRock) {
    const lvlId = this.levelConfig.id;

    // LEVEL 1: Push 3 rocks
    if (lvlId === 1) {
      if (this.currentStack.length >= 3) {
        this.time.delayedCall(350, () => this.handleLevelVictory());
      }
    }

    // LEVEL 2: Pop the top unstable rock
    if (lvlId === 2) {
      if (lastPoppedRock && lastPoppedRock.unstable) {
        // Unstable rock popped successfully!
        playLavaSizzle();
        this.time.delayedCall(400, () => this.handleLevelVictory());
      }
    }

    // LEVEL 4: Undo puzzle (Toxic slag removed)
    if (lvlId === 4) {
      if (lastPoppedRock && lastPoppedRock.isFaulty) {
        playLavaSizzle();
        this.time.delayedCall(400, () => this.handleLevelVictory());
      }
    }

    // LEVEL 5: Word Reversal (Push N, O, V, A, then Pop all -> A, V, O, N)
    if (lvlId === 5) {
      if (lastPoppedRock) {
        this.reversedPoppedLetters.push(lastPoppedRock.label);

        // Check if all letters were reversed in order
        const target = this.levelConfig.targetReversed || ['A', 'V', 'O', 'N'];
        const isMatchSoFar = this.reversedPoppedLetters.every((l, idx) => l === target[idx]);

        if (!isMatchSoFar) {
          this.handleFailure('Letters were popped in the incorrect order!');
          return;
        }

        if (this.reversedPoppedLetters.length === target.length) {
          this.time.delayedCall(400, () => this.handleLevelVictory());
        }
      }
    }
  }

  private spawnLandingEmbers(x: number, y: number) {
    const emitter = this.add.particles(x, y + 14, 'volcano_ember', {
      speed: { min: 40, max: 120 },
      angle: { min: 200, max: 340 },
      scale: { start: 0.9, end: 0 },
      lifespan: 300,
      quantity: 8
    });
    this.time.delayedCall(300, () => emitter.destroy());
  }

  private spawnSteamBlast(x: number, y: number) {
    const emitter = this.add.particles(x, y, 'steam_cloud', {
      speed: { min: 30, max: 80 },
      angle: { min: 220, max: 320 },
      scale: { start: 0.8, end: 1.6 },
      alpha: { start: 0.7, end: 0 },
      lifespan: 400,
      quantity: 6
    });
    this.time.delayedCall(400, () => emitter.destroy());
  }

  private spawnPeekSparkles(x: number, y: number) {
    const emitter = this.add.particles(x, y, 'volcano_ember', {
      speed: { min: 40, max: 100 },
      angle: { min: 0, max: 360 },
      scale: { start: 1, end: 0 },
      tint: [0x38bdf8, 0xfbbf24, 0xffffff],
      lifespan: 350,
      quantity: 12
    });
    this.time.delayedCall(350, () => emitter.destroy());
  }

  private handleLevelVictory() {
    if (this.isVictory) return;
    this.isVictory = true;
    playSuccessSound();

    const durationSec = Math.max(1, Math.round((Date.now() - this.levelStartTime) / 100) / 10);
    const coinsWon = (20 * this.coinMultiplier);

    this.time.delayedCall(500, () => {
      if (this.callbacks.onLevelComplete) {
        this.callbacks.onLevelComplete({
          itemsStacked: this.currentStack.length,
          completionTime: durationSec,
          coinsCollected: coinsWon
        });
      }
    });
  }

  private handleFailure(reason: string) {
    if (this.isGameOver) return;
    this.isGameOver = true;
    playErrorSound();

    this.cameras.main.shake(350, 0.03);

    if (this.callbacks.onHeartLost) {
      this.callbacks.onHeartLost();
    }

    this.time.delayedCall(500, () => {
      if (this.callbacks.onLevelFailed) {
        this.callbacks.onLevelFailed(reason);
      }
    });
  }
}
