import Phaser from 'phaser';
import {
  playCoinSound,
  playErrorSound,
  playSuccessSound,
  playFruitHarvestSound,
  playBranchClimbSound,
  playGhostPathChime,
  playBstCorrectChoiceSound
} from '../../utils/audio.ts';

export interface TreeNodeData {
  id: string;
  value: number;
  label: string;
  role?: string;
  depth?: number;
  x?: number;
  y?: number;
  left?: TreeNodeData | null;
  right?: TreeNodeData | null;
  harvested?: boolean;
  isNew?: boolean;
}

export interface TreeLevelConfig {
  id: number;
  type: string;
  traversalMode?: 'preorder' | 'inorder' | 'postorder';
  targetCount: number;
  treeData: TreeNodeData;
  expectedSequence?: number[];
  fruitsToInsert?: Array<{
    value: number;
    hint: string;
    expectedPath: string[];
  }>;
  searchTargets?: Array<{
    target: number;
    prompt: string;
    expectedSteps: string[];
  }>;
  treeHeightChallenge?: {
    correctHeight: number;
    options: number[];
    explanation: string;
  };
}

export interface TreeSceneCallbacks {
  onProgressUpdate?: (data: {
    current: number;
    total: number;
    coins?: number;
    currentNodeVal?: number;
    harvestedValues?: number[];
    incomingFruit?: number;
    searchTarget?: number;
    currentDepth?: number;
  }) => void;
  onTreeStateUpdated?: (data: {
    harvestedValues: number[];
    currentNodeVal: number;
    incomingFruit?: number;
    searchTarget?: number;
    searchPhase?: 'search' | 'height';
    plantedCount?: number;
  }) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: {
    itemsCleared: number;
    coinsCollected: number;
    completionTime: number;
    perfect?: boolean;
  }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
}

export class TreeValleyScene extends Phaser.Scene {
  private levelConfig!: TreeLevelConfig;
  private callbacks!: TreeSceneCallbacks;
  private characterId: string = 'bit_byte';
  private coinMultiplier: number = 1;

  // General State
  private isGameOver: boolean = false;
  private isVictory: boolean = false;
  private levelStartTime: number = 0;
  private coinsCollected: number = 0;
  private itemsCleared: number = 0;

  // Tree Structure & Layout
  private rootNode!: TreeNodeData;
  private nodeMap: Map<number, TreeNodeData> = new Map();
  private nodeSprites: Map<
    number,
    {
      container: Phaser.GameObjects.Container;
      fruitCircle: Phaser.GameObjects.Arc;
      fruitAura: Phaser.GameObjects.Arc;
      valueText: Phaser.GameObjects.Text;
      roleText: Phaser.GameObjects.Text;
      checkIcon?: Phaser.GameObjects.Text;
    }
  > = new Map();
  private branchGraphics!: Phaser.GameObjects.Graphics;
  private ghostGraphics!: Phaser.GameObjects.Graphics;

  // Climbing Player Avatar
  private playerAvatar!: Phaser.GameObjects.Container;
  private currentNodeVal: number = 50;

  // Traversals State (Levels 1-3)
  private harvestedValues: number[] = [];
  private expectedSequence: number[] = [];
  private ghostTween: Phaser.Tweens.Tween | null = null;
  private ghostMarker!: Phaser.GameObjects.Arc;

  // BST Insertion State (Level 4)
  private currentFruitIndex: number = 0;
  private currentInsertStep: number = 0;
  private plantedCount: number = 0;
  private isTransitioningFruit: boolean = false;

  // BST Search & Height State (Level 5)
  private searchPhase: 'search' | 'height' = 'search';
  private currentSearchTargetIndex: number = 0;
  private currentSearchTarget: number = 65;
  private searchStepIndex: number = 0;

  constructor() {
    super({ key: 'TreeValleyScene' });
  }

  init(data: {
    levelConfig: TreeLevelConfig;
    characterId?: string;
    coinMultiplier?: number;
    callbacks?: TreeSceneCallbacks;
  }) {
    this.levelConfig = data.levelConfig;
    this.characterId = data.characterId || 'bit_byte';
    this.coinMultiplier = data.coinMultiplier || 1;
    this.callbacks = data.callbacks || {};

    this.isGameOver = false;
    this.isVictory = false;
    this.levelStartTime = Date.now();
    this.coinsCollected = 0;
    this.itemsCleared = 0;
    this.harvestedValues = [];
    this.currentFruitIndex = 0;
    this.currentInsertStep = 0;
    this.plantedCount = 0;
    this.isTransitioningFruit = false;
    this.searchPhase = 'search';
    this.currentSearchTargetIndex = 0;
    this.searchStepIndex = 0;
    this.nodeMap.clear();
    this.nodeSprites.clear();

    // Deep clone treeData to allow dynamic node insertions without mutating original
    this.rootNode = JSON.parse(JSON.stringify(this.levelConfig.treeData));
    this.expectedSequence = this.levelConfig.expectedSequence
      ? [...this.levelConfig.expectedSequence]
      : [];
    if (this.levelConfig.searchTargets && this.levelConfig.searchTargets.length > 0) {
      this.currentSearchTarget = this.levelConfig.searchTargets[0].target;
    }
  }

  create() {
    const { width, height } = this.scale;

    // 1. Cyber-Forest Atmosphere
    this.createAtmosphere(width, height);

    // 2. Compute tree coordinates with balanced offsets so every node is on-screen
    this.layoutTree(this.rootNode, width / 2, 54, 205, 0);

    // 3. Draw Branches
    this.branchGraphics = this.add.graphics();
    this.redrawBranches();

    // 4. Ghost Path Layer
    this.ghostGraphics = this.add.graphics();
    this.ghostMarker = this.add.circle(0, 0, 11, 0xfde047, 0.95);
    this.ghostMarker.setStrokeStyle(2, 0xffffff, 1);
    this.ghostMarker.setVisible(false);
    this.ghostMarker.setDepth(15);

    // 5. Render Node Discs & Hanging Fruits
    this.renderNodes(this.rootNode);

    // 6. Create Climbing Player Avatar
    this.createPlayerAvatar();

    // 7. Initialize Player position at Root
    this.movePlayerToNode(this.rootNode.value, false);

    // 8. Auto-play Ghost Path Hint on Traversals at level start
    if (this.levelConfig.type === 'tree_traversal') {
      this.time.delayedCall(400, () => {
        this.playGhostPathAnimation();
      });
    }

    // 9. Initial callback update
    this.notifyCallbacks();
  }

  private createAtmosphere(width: number, height: number) {
    const bg = this.add.graphics();
    // Violet-indigo to deep cyber-navy gradient
    bg.fillGradientStyle(0x150b2e, 0x150b2e, 0x070518, 0x070518, 1);
    bg.fillRect(0, 0, width, height);

    // Subtle bioluminescent ground roots at bottom
    const ground = this.add.graphics();
    ground.fillStyle(0x0e0928, 0.92);
    ground.fillRoundedRect(12, height - 34, width - 24, 28, 14);
    ground.lineStyle(1.5, 0x8b5cf6, 0.45);
    ground.strokeRoundedRect(12, height - 34, width - 24, 28, 14);

    // Root pulse label
    this.add.text(width / 2, height - 20, 'ALGÒRIA FOREST NETWORK · BINARY TREE RUNTIME', {
      fontSize: '10px',
      color: '#a78bfa',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    // Floating spore particles
    const sporeGraphic = this.make.graphics({ x: 0, y: 0 });
    sporeGraphic.fillStyle(0xa78bfa, 0.85);
    sporeGraphic.fillCircle(4, 4, 3);
    sporeGraphic.generateTexture('sporeParticle', 8, 8);
    sporeGraphic.destroy();

    this.add.particles(0, 0, 'sporeParticle', {
      x: { min: 20, max: width - 20 },
      y: { min: 20, max: height - 40 },
      speedY: { min: -12, max: -32 },
      speedX: { min: -8, max: 8 },
      scale: { start: 0.8, end: 0.2 },
      alpha: { start: 0.75, end: 0 },
      lifespan: 2600,
      frequency: 220
    });
  }

  /**
   * Recursively assign positions to binary tree nodes
   * Symmetrical, well-bounded offsets ensuring all 4 levels fit within 860x360 canvas
   */
  private layoutTree(
    node: TreeNodeData | null | undefined,
    x: number,
    y: number,
    hOffset: number,
    depth: number
  ) {
    if (!node) return;
    node.x = x;
    node.y = y;
    node.depth = depth;
    this.nodeMap.set(node.value, node);

    const childY = y + 68;
    const nextOffset = Math.max(48, Math.round(hOffset * 0.5));

    if (node.left) {
      this.layoutTree(node.left, x - hOffset, childY, nextOffset, depth + 1);
    }
    if (node.right) {
      this.layoutTree(node.right, x + hOffset, childY, nextOffset, depth + 1);
    }
  }

  /**
   * Draw cyber-organic branches connecting parent to children
   */
  private redrawBranches() {
    this.branchGraphics.clear();

    const drawBranch = (node: TreeNodeData | null | undefined) => {
      if (!node || node.x === undefined || node.y === undefined) return;

      if (node.left && node.left.x !== undefined && node.left.y !== undefined) {
        // Outer glow
        this.branchGraphics.lineStyle(6, 0x4c1d95, 0.45);
        this.branchGraphics.lineBetween(node.x, node.y, node.left.x, node.left.y);
        // Core organic branch
        this.branchGraphics.lineStyle(3, 0x8b5cf6, 0.85);
        this.branchGraphics.lineBetween(node.x, node.y, node.left.x, node.left.y);
        // Cyber pulse vein
        this.branchGraphics.lineStyle(1.2, 0xd8b4fe, 0.95);
        this.branchGraphics.lineBetween(node.x, node.y, node.left.x, node.left.y);
        drawBranch(node.left);
      }

      if (node.right && node.right.x !== undefined && node.right.y !== undefined) {
        // Outer glow
        this.branchGraphics.lineStyle(6, 0x4c1d95, 0.45);
        this.branchGraphics.lineBetween(node.x, node.y, node.right.x, node.right.y);
        // Core organic branch
        this.branchGraphics.lineStyle(3, 0x8b5cf6, 0.85);
        this.branchGraphics.lineBetween(node.x, node.y, node.right.x, node.right.y);
        // Cyber pulse vein
        this.branchGraphics.lineStyle(1.2, 0xd8b4fe, 0.95);
        this.branchGraphics.lineBetween(node.x, node.y, node.right.x, node.right.y);
        drawBranch(node.right);
      }
    };

    drawBranch(this.rootNode);
  }

  /**
   * Render nodes with interactive fruit visuals
   */
  private renderNodes(node: TreeNodeData | null | undefined) {
    if (!node || node.x === undefined || node.y === undefined) return;

    if (this.nodeSprites.has(node.value)) {
      this.renderNodes(node.left);
      this.renderNodes(node.right);
      return;
    }

    const container = this.add.container(node.x, node.y);

    const isRoot = node.role === 'Root';
    const isLeaf = node.role === 'Leaf' || node.role === 'Deepest Leaf' || node.role === 'Planted Leaf';

    const auraColor = isRoot ? 0xf59e0b : isLeaf ? 0x10b981 : 0xa855f7;
    const circleColor = isRoot ? 0xd97706 : isLeaf ? 0x059669 : 0x7c3aed;
    const strokeColor = isRoot ? 0xfde047 : isLeaf ? 0x6ee7b7 : 0xc084fc;

    // Glowing aura
    const fruitAura = this.add.circle(0, 0, 24, auraColor, 0.35);

    // Main Fruit Sphere
    const fruitCircle = this.add.circle(0, 0, 19, circleColor, 1);
    fruitCircle.setStrokeStyle(2, strokeColor, 0.95);

    // Fruit shine reflection
    const shine = this.add.circle(-5, -6, 4, 0xffffff, 0.65);

    // Fruit Value Text
    const valueText = this.add.text(0, -1, `${node.value}`, {
      fontSize: '13px',
      color: '#ffffff',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    // Role badge below
    const roleColor = isRoot ? '#fde047' : isLeaf ? '#34d399' : '#c084fc';
    const roleText = this.add.text(0, 25, node.role || 'Node', {
      fontSize: '9px',
      color: roleColor,
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    container.add([fruitAura, fruitCircle, shine, valueText, roleText]);
    container.setSize(52, 52);
    container.setInteractive({ useHandCursor: true });

    // Idle bob animation
    this.tweens.add({
      targets: fruitCircle,
      y: { from: -1.5, to: 1.5 },
      duration: 1700 + Math.random() * 400,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });

    // Node Click Handler
    container.on('pointerdown', () => {
      this.handleNodeClicked(node.value);
    });

    this.nodeSprites.set(node.value, {
      container,
      fruitCircle,
      fruitAura,
      valueText,
      roleText
    });

    this.renderNodes(node.left);
    this.renderNodes(node.right);
  }

  /**
   * Create climbing player avatar representation with avatar styling
   */
  private createPlayerAvatar() {
    this.playerAvatar = this.add.container(0, 0);

    let auraColor = 0x06b6d4;
    let bodyColor = 0x0891b2;
    let strokeColor = 0x67e8f9;
    let label = 'BIT BYTE';

    if (this.characterId === 'algo_fox') {
      auraColor = 0xea580c;
      bodyColor = 0xc2410c;
      strokeColor = 0xfbbf24;
      label = 'ALGO FOX';
    } else if (this.characterId === 'cyber_nova') {
      auraColor = 0xa855f7;
      bodyColor = 0x7e22ce;
      strokeColor = 0xf472b6;
      label = 'CYBER NOVA';
    } else if (this.characterId === 'pixel_knight') {
      auraColor = 0x10b981;
      bodyColor = 0x047857;
      strokeColor = 0x6ee7b7;
      label = 'PIXEL KNIGHT';
    }

    const aura = this.add.circle(0, 0, 16, auraColor, 0.45);
    const body = this.add.circle(0, 0, 11, bodyColor, 1);
    body.setStrokeStyle(2, strokeColor, 1);

    // Eye visor
    const visor = this.add.rectangle(1, -2, 10, 4, 0xffffff, 0.95);

    // Character Tag
    const tag = this.add.text(0, -18, label, {
      fontSize: '8px',
      color: `#${strokeColor.toString(16).padStart(6, '0')}`,
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.playerAvatar.add([aura, body, visor, tag]);
    this.playerAvatar.setDepth(20);

    // Gentle pulse animation
    this.tweens.add({
      targets: aura,
      scale: 1.35,
      alpha: 0.15,
      duration: 850,
      yoyo: true,
      repeat: -1
    });
  }

  /**
   * Move player avatar to target tree node & notify callbacks immediately
   */
  private movePlayerToNode(val: number, animate: boolean = true) {
    const targetNode = this.nodeMap.get(val);
    if (!targetNode || targetNode.x === undefined || targetNode.y === undefined) return;

    this.currentNodeVal = val;

    if (!animate) {
      this.playerAvatar.setPosition(targetNode.x, targetNode.y);
      this.notifyCallbacks();
      return;
    }

    playBranchClimbSound();

    this.tweens.add({
      targets: this.playerAvatar,
      x: targetNode.x,
      y: targetNode.y,
      duration: 340,
      ease: 'Cubic.easeOut',
      onComplete: () => {
        this.notifyCallbacks();
      }
    });

    this.notifyCallbacks();
  }

  /**
   * Animate the Ghost Path showing the exact traversal order
   */
  public playGhostPathAnimation() {
    if (this.ghostTween) {
      this.ghostTween.stop();
      this.ghostTween = null;
    }

    if (!this.expectedSequence || this.expectedSequence.length === 0) return;

    playGhostPathChime();
    this.ghostGraphics.clear();
    this.ghostMarker.setVisible(true);

    const pathPoints: Array<{ x: number; y: number; val: number }> = [];
    for (const val of this.expectedSequence) {
      const node = this.nodeMap.get(val);
      if (node && node.x !== undefined && node.y !== undefined) {
        pathPoints.push({ x: node.x, y: node.y, val });
      }
    }

    if (pathPoints.length === 0) return;

    this.ghostMarker.setPosition(pathPoints[0].x, pathPoints[0].y);

    let step = 0;
    const advanceMarker = () => {
      if (step >= pathPoints.length - 1) {
        this.time.delayedCall(1200, () => {
          this.ghostGraphics.clear();
          this.ghostMarker.setVisible(false);
        });
        return;
      }

      const p1 = pathPoints[step];
      const p2 = pathPoints[step + 1];

      // Draw dashed luminous connection
      this.ghostGraphics.lineStyle(2.5, 0xfde047, 0.75);
      this.ghostGraphics.lineBetween(p1.x, p1.y, p2.x, p2.y);

      // Pulse at current node
      const sprite = this.nodeSprites.get(p1.val);
      if (sprite) {
        this.tweens.add({
          targets: sprite.fruitAura,
          scale: 1.65,
          alpha: 0.85,
          duration: 240,
          yoyo: true
        });
      }

      this.ghostTween = this.tweens.add({
        targets: this.ghostMarker,
        x: p2.x,
        y: p2.y,
        duration: 460,
        ease: 'Sine.easeInOut',
        onComplete: () => {
          step++;
          advanceMarker();
        }
      });
    };

    advanceMarker();
  }

  /**
   * Handle player clicking a node on the tree canvas
   */
  public handleNodeClicked(val: number) {
    if (this.isGameOver || this.isVictory) return;

    if (this.levelConfig.type === 'tree_traversal') {
      this.processTraversalStep(val);
    } else if (this.levelConfig.type === 'bst_insertion') {
      if (this.isTransitioningFruit) return;
      const currentNode = this.nodeMap.get(this.currentNodeVal);
      if (currentNode) {
        if (currentNode.left?.value === val) {
          this.handleBstInsertionChoice('left');
        } else if (currentNode.right?.value === val) {
          this.handleBstInsertionChoice('right');
        } else {
          // If player clicks the tree directly, check which direction matches the incoming fruit
          const fruits = this.levelConfig.fruitsToInsert || [];
          if (this.currentFruitIndex < fruits.length) {
            const currentFruit = fruits[this.currentFruitIndex];
            const dir = currentFruit.value < currentNode.value ? 'left' : 'right';
            if (
              (dir === 'left' && currentNode.left?.value === val) ||
              (dir === 'right' && currentNode.right?.value === val)
            ) {
              this.handleBstInsertionChoice(dir);
            }
          }
        }
      }
    } else if (this.levelConfig.type === 'bst_search_and_height') {
      if (this.searchPhase === 'search') {
        if (val === this.currentNodeVal && val === this.currentSearchTarget) {
          this.confirmSearchTargetFound();
        } else {
          const currentNode = this.nodeMap.get(this.currentNodeVal);
          if (currentNode) {
            if (currentNode.left?.value === val) {
              this.handleSearchStep('left');
            } else if (currentNode.right?.value === val) {
              this.handleSearchStep('right');
            } else if (val === this.currentSearchTarget) {
              const dir = this.currentSearchTarget < currentNode.value ? 'left' : 'right';
              this.handleSearchStep(dir);
            } else {
              this.triggerMistake(`Step node-by-node down the BST branches towards target ${this.currentSearchTarget}!`);
            }
          }
        }
      }
    }
  }

  /**
   * Traversals: verify next node matches preorder / inorder / postorder sequence
   */
  private processTraversalStep(val: number) {
    if (this.harvestedValues.includes(val)) {
      return;
    }

    const nextExpected = this.expectedSequence[this.harvestedValues.length];

    if (val === nextExpected) {
      this.harvestedValues.push(val);
      this.itemsCleared = this.harvestedValues.length;

      this.movePlayerToNode(val, true);

      playFruitHarvestSound();
      this.harvestFruitVisual(val);

      const coinGain = Math.round(5 * this.coinMultiplier);
      this.coinsCollected += coinGain;
      if (this.callbacks.onCoinCollected) {
        this.callbacks.onCoinCollected(this.coinsCollected, coinGain);
      }

      this.notifyCallbacks();

      if (this.harvestedValues.length >= this.expectedSequence.length) {
        this.triggerVictory();
      }
    } else {
      this.triggerMistake(
        `Out of ${this.levelConfig.traversalMode} order! Target was ${nextExpected}, but you selected ${val}.`
      );
    }
  }

  private harvestFruitVisual(val: number) {
    const sprite = this.nodeSprites.get(val);
    if (!sprite) return;

    this.tweens.add({
      targets: sprite.fruitCircle,
      scale: 1.4,
      duration: 180,
      yoyo: true,
      onComplete: () => {
        sprite.fruitCircle.setFillStyle(0x1e293b, 0.95);
        sprite.fruitCircle.setStrokeStyle(2, 0x10b981, 0.9);
        sprite.fruitAura.setFillStyle(0x10b981, 0.65);
        sprite.valueText.setColor('#34d399');
        sprite.roleText.setText('✓ Harvested');
        sprite.roleText.setColor('#34d399');
      }
    });

    const sparks = this.add.particles(sprite.container.x, sprite.container.y, 'sporeParticle', {
      speed: { min: 40, max: 120 },
      angle: { min: 0, max: 360 },
      scale: { start: 1, end: 0 },
      alpha: { start: 1, end: 0 },
      lifespan: 500,
      quantity: 14
    });
    this.time.delayedCall(600, () => sparks.destroy());
  }

  /**
   * Main navigation handler for Left / Right branch choice
   */
  public navigateChoice(direction: 'left' | 'right') {
    if (this.isGameOver || this.isVictory) return;

    if (this.levelConfig.type === 'bst_insertion') {
      this.handleBstInsertionChoice(direction);
    } else if (this.levelConfig.type === 'bst_search_and_height') {
      this.handleSearchStep(direction);
    }
  }

  public navigateLeft() {
    this.navigateChoice('left');
  }

  public navigateRight() {
    this.navigateChoice('right');
  }

  private handleBstInsertionChoice(direction: 'left' | 'right') {
    if (this.isTransitioningFruit) return;

    const fruits = this.levelConfig.fruitsToInsert || [];
    if (this.currentFruitIndex >= fruits.length) return;

    const currentFruit = fruits[this.currentFruitIndex];
    const expectedDir = currentFruit.expectedPath[this.currentInsertStep];

    if (direction === expectedDir) {
      playBstCorrectChoiceSound();
      this.currentInsertStep++;

      const currentNode = this.nodeMap.get(this.currentNodeVal);
      if (!currentNode) return;

      const nextNode = direction === 'left' ? currentNode.left : currentNode.right;

      if (nextNode && nextNode.value) {
        // Move to existing child
        this.movePlayerToNode(nextNode.value, true);
      } else {
        // Reached null leaf: plant the new fruit here!
        this.plantNewFruitNode(currentNode, direction, currentFruit.value);
      }
    } else {
      const node = this.nodeMap.get(this.currentNodeVal);
      const nodeVal = node?.value || 50;
      const fruitVal = currentFruit.value;
      const relation = fruitVal < nodeVal ? 'smaller (<)' : 'larger (>)';
      const correctDir = fruitVal < nodeVal ? 'LEFT' : 'RIGHT';
      this.triggerMistake(
        `BST invariant breach! Fruit ${fruitVal} is ${relation} than node ${nodeVal}, so it MUST go ${correctDir}!`
      );
    }
  }

  private plantNewFruitNode(
    parentNode: TreeNodeData,
    direction: 'left' | 'right',
    newValue: number
  ) {
    this.isTransitioningFruit = true;
    playFruitHarvestSound();

    const parentX = parentNode.x || 430;
    const parentY = parentNode.y || 100;
    const depth = (parentNode.depth || 0) + 1;
    const hOffset = Math.max(46, Math.round(90 / Math.pow(1.3, depth)));
    const newX = direction === 'left' ? parentX - hOffset : parentX + hOffset;
    const newY = parentY + 68;

    const newNode: TreeNodeData = {
      id: `planted_${newValue}`,
      value: newValue,
      label: `${newValue}`,
      role: 'Planted Leaf',
      depth,
      x: newX,
      y: newY,
      left: null,
      right: null,
      isNew: true
    };

    if (direction === 'left') {
      parentNode.left = newNode;
    } else {
      parentNode.right = newNode;
    }

    this.nodeMap.set(newValue, newNode);

    // Redraw branches to connect new node
    this.redrawBranches();

    // Render new node on screen
    this.renderNodes(newNode);

    // Animate planting burst
    const sprite = this.nodeSprites.get(newValue);
    if (sprite) {
      sprite.fruitAura.setFillStyle(0x10b981, 0.8);
      sprite.fruitCircle.setFillStyle(0x059669, 1);
      sprite.fruitCircle.setStrokeStyle(3, 0x34d399, 1);
      this.tweens.add({
        targets: sprite.container,
        scale: { from: 0.2, to: 1.25 },
        duration: 320,
        yoyo: true,
        ease: 'Back.easeOut'
      });
    }

    // Move player avatar to newly planted node
    this.movePlayerToNode(newValue, true);

    // Award coins and update count
    this.plantedCount++;
    this.itemsCleared = this.plantedCount;
    const coinGain = Math.round(10 * this.coinMultiplier);
    this.coinsCollected += coinGain;
    if (this.callbacks.onCoinCollected) {
      this.callbacks.onCoinCollected(this.coinsCollected, coinGain);
    }

    this.currentFruitIndex++;
    this.currentInsertStep = 0;

    const fruits = this.levelConfig.fruitsToInsert || [];
    if (this.currentFruitIndex < fruits.length) {
      this.time.delayedCall(750, () => {
        this.movePlayerToNode(this.rootNode.value, true);
        this.isTransitioningFruit = false;
        this.notifyCallbacks();
      });
    } else {
      // All fruits planted!
      this.time.delayedCall(850, () => {
        this.isTransitioningFruit = false;
        this.triggerVictory();
      });
    }

    this.notifyCallbacks();
  }

  /**
   * BST Search: Left / Right navigation & Target confirmation
   */
  private handleSearchStep(direction: 'left' | 'right') {
    const currentNode = this.nodeMap.get(this.currentNodeVal);
    if (!currentNode) return;

    if (this.currentSearchTarget === currentNode.value) {
      this.triggerMistake(`You are already at node ${currentNode.value}! Tap 'CONFIRM FOUND' to verify!`);
      return;
    }

    const expectedDir = this.currentSearchTarget < currentNode.value ? 'left' : 'right';

    if (direction === expectedDir) {
      const nextNode = direction === 'left' ? currentNode.left : currentNode.right;
      if (nextNode) {
        playBstCorrectChoiceSound();
        this.movePlayerToNode(nextNode.value, true);
        this.searchStepIndex++;
        this.notifyCallbacks();
      } else {
        this.triggerMistake(`Node does not exist in this branch!`);
      }
    } else {
      const relation = this.currentSearchTarget < currentNode.value ? 'smaller (<)' : 'larger (>)';
      const correctDir = this.currentSearchTarget < currentNode.value ? 'LEFT' : 'RIGHT';
      this.triggerMistake(
        `Target ${this.currentSearchTarget} is ${relation} than current node ${currentNode.value}, so BST search must go ${correctDir}!`
      );
    }
  }

  public confirmSearchTargetFound() {
    if (this.searchPhase !== 'search') return;

    if (this.currentNodeVal === this.currentSearchTarget) {
      playSuccessSound();
      this.harvestFruitVisual(this.currentSearchTarget);

      this.currentSearchTargetIndex++;
      const targets = this.levelConfig.searchTargets || [];

      if (this.currentSearchTargetIndex < targets.length) {
        this.currentSearchTarget = targets[this.currentSearchTargetIndex].target;
        this.searchStepIndex = 0;
        this.movePlayerToNode(this.rootNode.value, true);
        this.notifyCallbacks();
      } else {
        // Move to Tree Height calculation phase!
        this.searchPhase = 'height';
        this.itemsCleared = 2; // 2 targets found
        this.notifyCallbacks();
      }
    } else {
      this.triggerMistake(
        `Target is ${this.currentSearchTarget}, but your climber is currently at node ${this.currentNodeVal}!`
      );
    }
  }

  /**
   * Tree Height answer selection
   */
  public submitTreeHeightAnswer(answer: number) {
    if (this.searchPhase !== 'height') return;

    const correct = this.levelConfig.treeHeightChallenge?.correctHeight || 3;

    if (answer === correct) {
      playSuccessSound();
      this.itemsCleared = 3;
      this.notifyCallbacks();
      this.triggerVictory();
    } else {
      this.triggerMistake(
        `Height calculation mismatch! Count the number of edges from Root (depth 0) to deepest leaf 95 (depth 3).`
      );
    }
  }

  private triggerMistake(reason: string) {
    playErrorSound();
    this.cameras.main.shake(200, 0.008);

    if (this.callbacks.onHeartLost) {
      this.callbacks.onHeartLost();
    }

    if (this.callbacks.onLevelFailed) {
      // Optional failure notification
    }
  }

  private triggerVictory() {
    this.isVictory = true;
    playSuccessSound();

    const completionTime = Math.round((Date.now() - this.levelStartTime) / 100) / 10;

    if (this.callbacks.onLevelComplete) {
      this.callbacks.onLevelComplete({
        itemsCleared: this.itemsCleared,
        coinsCollected: this.coinsCollected,
        completionTime
      });
    }
  }

  private notifyCallbacks() {
    const fruits = this.levelConfig.fruitsToInsert || [];
    const incomingFruit =
      this.levelConfig.type === 'bst_insertion' && this.currentFruitIndex < fruits.length
        ? fruits[this.currentFruitIndex].value
        : undefined;

    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: this.itemsCleared,
        total: this.levelConfig.targetCount,
        coins: this.coinsCollected,
        currentNodeVal: this.currentNodeVal,
        harvestedValues: [...this.harvestedValues],
        incomingFruit,
        searchTarget: this.currentSearchTarget
      });
    }

    if (this.callbacks.onTreeStateUpdated) {
      this.callbacks.onTreeStateUpdated({
        harvestedValues: [...this.harvestedValues],
        currentNodeVal: this.currentNodeVal,
        incomingFruit,
        searchTarget: this.currentSearchTarget,
        searchPhase: this.searchPhase,
        plantedCount: this.plantedCount
      });
    }
  }
}
