import Phaser from 'phaser';
import { playJumpSound, playCoinSound, playErrorSound, playSuccessSound, playStepSound } from '../../utils/audio.ts';

export interface LevelConfig {
  id: number;
  type: string;
  treeCount: number;
  speed: number;
  coinPattern?: string;
  hasRiver?: boolean;
  riverPosition?: number;
  outerTarget?: number;
  innerTarget?: number;
}

export interface SceneCallbacks {
  onProgressUpdate?: (data: { current: number; total: number; coins: number; outerLoop?: number; innerLoop?: number }) => void;
  onJumpExecuted?: (treeIndex: number) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: { treesCleared: number; coinsCollected: number; completionTime: number; perfectJumps: boolean }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
}

export class LoopForestScene extends Phaser.Scene {
  private levelConfig!: LevelConfig;
  private callbacks!: SceneCallbacks;
  private characterId: string = 'bit_byte';
  
  // Game objects
  private player!: Phaser.GameObjects.Container;
  private playerBody!: Phaser.GameObjects.Rectangle;
  private playerHead!: Phaser.GameObjects.Rectangle;
  private playerVisor!: Phaser.GameObjects.Rectangle;
  private playerLegLeft!: Phaser.GameObjects.Rectangle;
  private playerLegRight!: Phaser.GameObjects.Rectangle;
  
  private groundTile!: Phaser.GameObjects.TileSprite;
  private bgStars!: Phaser.GameObjects.Graphics;
  private bgTreesBack!: Phaser.GameObjects.Graphics;
  private bgTreesMid!: Phaser.GameObjects.Graphics;
  
  private treesGroup!: Phaser.GameObjects.Group;
  private coinsGroup!: Phaser.GameObjects.Group;
  private beaconsGroup!: Phaser.GameObjects.Group;
  private riverObject: Phaser.GameObjects.Container | null = null;
  private bridgeObject: Phaser.GameObjects.Container | null = null;
  
  // State
  private isRunning: boolean = false;
  private isJumping: boolean = false;
  private jumpVelocityY: number = 0;
  private runAnimTimer: number = 0;
  private treesPassed: number = 0;
  private coinsCollected: number = 0;
  private isGameOver: boolean = false;
  private isVictory: boolean = false;
  private automatedMode: boolean = false;
  private bridgeDeployed: boolean = false;
  private scriptSequence: Array<{ action: string; duration?: number; targetIndex?: number; loopInfo?: { outer?: number; inner?: number } }> = [];
  private currentStepIndex: number = 0;
  private stepTimer: number = 0;

  // Manual Jump timing buffer
  private currentApproachingTreeIndex: number = 0;
  private treePositions: number[] = [];
  private jumpedTrees: Set<number> = new Set();
  private collectedCoins: Set<number> = new Set();

  // Multipliers & Timers
  private coinMultiplier: number = 1;
  private speedMultiplier: number = 1.0;
  private levelStartTime: number = 0;

  constructor() {
    super({ key: 'LoopForestScene' });
  }

  init(data: {
    levelConfig: LevelConfig;
    callbacks: SceneCallbacks;
    characterId: string;
    coinMultiplier?: number;
    speedMultiplier?: number;
  }) {
    this.levelConfig = data.levelConfig;
    this.callbacks = data.callbacks || {};
    this.characterId = data.characterId || 'bit_byte';
    this.coinMultiplier = data.coinMultiplier || 1;
    this.speedMultiplier = data.speedMultiplier || 1.0;
    this.treesPassed = 0;
    this.coinsCollected = 0;
    this.isGameOver = false;
    this.isVictory = false;
    // Manual leap runs immediately; automated loop levels stay idle until RUN CODE is pressed
    this.isRunning = this.levelConfig.type === 'manual_jump';
    this.automatedMode = this.levelConfig.type !== 'manual_jump';
    this.bridgeDeployed = false;
    this.isJumping = false;
    this.jumpVelocityY = 0;
    this.currentApproachingTreeIndex = 0;
    this.scriptSequence = [];
    this.currentStepIndex = 0;
    this.jumpedTrees.clear();
    this.collectedCoins.clear();
  }

  preload() {
    // Generate all textures procedurally with Phaser Graphics
    this.createProceduralTextures();
  }

  private createProceduralTextures() {
    // 1. Particle Glow texture
    if (!this.textures.exists('particle_dot')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0x22d3ee, 1);
      g.fillCircle(8, 8, 8);
      g.fillStyle(0xffffff, 0.8);
      g.fillCircle(8, 8, 4);
      g.generateTexture('particle_dot', 16, 16);
      g.destroy();
    }

    // 2. Tree Texture (Glowing bioluminescent cyber tree)
    if (!this.textures.exists('cyber_tree')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      // Trunk
      g.fillStyle(0x1e1b4b, 1);
      g.fillRect(18, 50, 16, 50);
      g.lineStyle(2, 0x8b5cf6, 0.8);
      g.strokeRect(18, 50, 16, 50);

      // Bioluminescent circuit on trunk
      g.lineStyle(2, 0x06b6d4, 0.9);
      g.beginPath();
      g.moveTo(26, 95);
      g.lineTo(26, 60);
      g.lineTo(30, 52);
      g.stroke();

      // Crown / Canopy (3-tier cyber crystalline foliage)
      g.fillStyle(0x047857, 0.9);
      g.fillTriangle(26, 10, 2, 55, 50, 55);
      g.lineStyle(2, 0x10b981, 1);
      g.strokeTriangle(26, 10, 2, 55, 50, 55);

      g.fillStyle(0x059669, 0.9);
      g.fillTriangle(26, 0, 8, 38, 44, 38);
      g.lineStyle(2, 0x34d399, 1);
      g.strokeTriangle(26, 0, 8, 38, 44, 38);

      // Glowing crystal tip
      g.fillStyle(0x6ee7b7, 1);
      g.fillCircle(26, 2, 4);

      g.generateTexture('cyber_tree', 52, 100);
      g.destroy();
    }

    // 3. Coin / Algorithm Crystal Texture
    if (!this.textures.exists('crystal_coin')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      // Diamond crystal outer
      g.fillStyle(0xfbbf24, 1);
      g.beginPath();
      g.moveTo(14, 2);
      g.lineTo(26, 14);
      g.lineTo(14, 26);
      g.lineTo(2, 14);
      g.closePath();
      g.fill();

      // Crystal facet inner highlight
      g.fillStyle(0xfef08a, 0.9);
      g.beginPath();
      g.moveTo(14, 5);
      g.lineTo(22, 14);
      g.lineTo(14, 14);
      g.closePath();
      g.fill();

      // Outline
      g.lineStyle(1.5, 0xffffff, 1);
      g.beginPath();
      g.moveTo(14, 2);
      g.lineTo(26, 14);
      g.lineTo(14, 26);
      g.lineTo(2, 14);
      g.closePath();
      g.stroke();

      g.generateTexture('crystal_coin', 28, 28);
      g.destroy();
    }

    // 4. Ground Pattern Texture
    if (!this.textures.exists('cyber_ground')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0x0f0a24, 1);
      g.fillRect(0, 0, 64, 64);
      // Top glowing neon grass/barrier line
      g.fillStyle(0x6366f1, 1);
      g.fillRect(0, 0, 64, 6);
      g.fillStyle(0x22d3ee, 1);
      g.fillRect(0, 0, 64, 2);
      // Cyber circuit line
      g.lineStyle(1, 0x2e1065, 1);
      g.beginPath();
      g.moveTo(0, 24);
      g.lineTo(32, 24);
      g.lineTo(44, 48);
      g.lineTo(64, 48);
      g.stroke();
      g.generateTexture('cyber_ground', 64, 64);
      g.destroy();
    }

    // 5. Jump Beacon Indicator
    if (!this.textures.exists('jump_beacon')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0x22d3ee, 0.35);
      g.fillRoundedRect(0, 0, 48, 8, 4);
      g.lineStyle(1.5, 0x38bdf8, 0.8);
      g.strokeRoundedRect(0, 0, 48, 8, 4);
      g.generateTexture('jump_beacon', 48, 8);
      g.destroy();
    }

    // 6. Holographic Grove Gateway (for Level 4 Nested Loop)
    if (!this.textures.exists('grove_gate')) {
      const g = this.make.graphics({ x: 0, y: 0 });
      g.fillStyle(0xa855f7, 0.3);
      g.fillRect(0, 0, 6, 120);
      g.lineStyle(2, 0xc084fc, 0.9);
      g.strokeRect(0, 0, 6, 120);
      g.fillStyle(0x22d3ee, 1);
      g.fillCircle(3, 4, 6);
      g.generateTexture('grove_gate', 6, 120);
      g.destroy();
    }
  }

  create() {
    const { width, height } = this.scale;
    const groundY = height - 70;

    // Background Gradient / Distant Sky
    this.createParallaxBackground(width, height, groundY);

    // Ground tile sprite
    this.groundTile = this.add.tileSprite(width / 2, height - 35, width, 70, 'cyber_ground');

    // Create Groups
    this.beaconsGroup = this.add.group();
    this.treesGroup = this.add.group();
    this.coinsGroup = this.add.group();

    // Spawn obstacles according to level config
    this.setupObstacles(groundY);

    // Create Animated Character
    this.createPlayerCharacter(groundY);

    // Record start time for star speed scoring
    this.levelStartTime = Date.now();

    // Keyboard Spacebar input listener for manual jump
    if (this.input.keyboard) {
      this.input.keyboard.on('keydown-SPACE', () => {
        if (!this.automatedMode) {
          this.triggerPlayerJump();
        }
      });
    }

    // Click/Touch on canvas to jump as well
    this.input.on('pointerdown', () => {
      if (!this.automatedMode && !this.isGameOver && !this.isVictory) {
        this.triggerPlayerJump();
      }
    });

    // Notify React initial count
    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: 0,
        total: this.levelConfig.treeCount,
        coins: 0
      });
    }
  }

  private createParallaxBackground(width: number, height: number, groundY: number) {
    // Night sky stars
    this.bgStars = this.add.graphics();
    this.bgStars.fillStyle(0xffffff, 0.7);
    for (let i = 0; i < 45; i++) {
      const rx = Phaser.Math.Between(0, width);
      const ry = Phaser.Math.Between(10, groundY - 120);
      const r = Phaser.Math.Between(1, 2.5);
      this.bgStars.fillCircle(rx, ry, r);
    }

    // Glowing Neon Moon
    const moon = this.add.graphics();
    moon.fillStyle(0x7c3aed, 0.3);
    moon.fillCircle(width - 90, 75, 45);
    moon.fillStyle(0x06b6d4, 0.6);
    moon.fillCircle(width - 90, 75, 30);
    moon.fillStyle(0xffffff, 0.9);
    moon.fillCircle(width - 90, 75, 20);

    // Far silhouette mountains
    const mountains = this.add.graphics();
    mountains.fillStyle(0x130d32, 0.9);
    mountains.beginPath();
    mountains.moveTo(0, groundY);
    mountains.lineTo(60, groundY - 110);
    mountains.lineTo(160, groundY - 40);
    mountains.lineTo(290, groundY - 130);
    mountains.lineTo(440, groundY - 30);
    mountains.lineTo(620, groundY - 120);
    mountains.lineTo(width, groundY - 50);
    mountains.lineTo(width, groundY);
    mountains.closePath();
    mountains.fill();

    // Midground silhouette trees
    this.bgTreesMid = this.add.graphics();
    this.drawMidgroundTrees(width, groundY);
  }

  private drawMidgroundTrees(width: number, groundY: number) {
    this.bgTreesMid.clear();
    this.bgTreesMid.fillStyle(0x1e1548, 0.85);
    for (let x = 0; x < width + 100; x += 65) {
      const treeH = 65 + (x % 3) * 15;
      this.bgTreesMid.fillTriangle(x, groundY - treeH, x - 22, groundY, x + 22, groundY);
    }
  }

  private createPlayerCharacter(groundY: number) {
    const startX = 140;
    const startY = groundY - 32;

    this.player = this.add.container(startX, startY);

    // Character color palette based on selected character
    let primaryColor = 0x06b6d4; // Bit Byte cyan
    let secondaryColor = 0x38bdf8;
    if (this.characterId === 'algo_fox') {
      primaryColor = 0xea580c;
      secondaryColor = 0xfbbf24;
    } else if (this.characterId === 'cyber_nova') {
      primaryColor = 0xa855f7;
      secondaryColor = 0xec4899;
    } else if (this.characterId === 'pixel_knight') {
      primaryColor = 0x10b981;
      secondaryColor = 0x34d399;
    }

    // Legs
    this.playerLegLeft = this.add.rectangle(-6, 20, 5, 16, 0x1e293b);
    this.playerLegRight = this.add.rectangle(6, 20, 5, 16, 0x1e293b);

    // Torso / Jetpack
    const jetpack = this.add.rectangle(-14, 0, 8, 18, 0x475569);
    this.playerBody = this.add.rectangle(0, 0, 20, 26, primaryColor);

    // Head
    this.playerHead = this.add.rectangle(0, -18, 18, 16, primaryColor);
    this.playerVisor = this.add.rectangle(4, -18, 10, 6, secondaryColor);

    const ornaments: Phaser.GameObjects.GameObject[] = [];

    // Distinct Avatar Headgear & Ornaments
    if (this.characterId === 'algo_fox') {
      // Fox cyber ears
      const leftEar = this.add.triangle(-6, -27, 0, 0, 8, 0, 4, -10, 0xea580c);
      const rightEar = this.add.triangle(6, -27, 0, 0, 8, 0, 4, -10, 0xea580c);
      // Bushy cyber tail
      const tail = this.add.triangle(-18, 10, 0, 0, 10, -6, 12, 10, 0xea580c);
      ornaments.push(leftEar, rightEar, tail);
    } else if (this.characterId === 'pixel_knight') {
      // Golden crest plume
      const plume = this.add.rectangle(0, -28, 4, 10, 0xfbbf24);
      const crest = this.add.triangle(0, -32, -4, 0, 4, 0, 0, -6, 0xf59e0b);
      ornaments.push(plume, crest);
    } else if (this.characterId === 'cyber_nova') {
      // Cosmic horns & halo ring
      const horn1 = this.add.triangle(-5, -28, -2, 0, 2, 0, 0, -8, 0xc084fc);
      const horn2 = this.add.triangle(5, -28, -2, 0, 2, 0, 0, -8, 0xc084fc);
      const halo = this.add.ellipse(0, -18, 26, 8, 0x000000, 0);
      halo.setStrokeStyle(1.5, 0xe879f9);
      ornaments.push(horn1, horn2, halo);
    } else {
      // Bit Byte cyan antenna
      const antennaLine = this.add.rectangle(0, -28, 2, 8, 0x38bdf8);
      const antennaTip = this.add.circle(0, -32, 3, 0x22d3ee);
      ornaments.push(antennaLine, antennaTip);
    }

    // Assemble player container
    this.player.add([
      jetpack,
      this.playerLegLeft,
      this.playerLegRight,
      this.playerBody,
      this.playerHead,
      this.playerVisor,
      ...ornaments
    ]);
    this.player.setSize(24, 52);
  }

  private setupObstacles(groundY: number) {
    const startOffset = 520;
    this.treePositions = [];

    const total = this.levelConfig.treeCount;
    const isNested = this.levelConfig.type === 'nested_loop';
    const treesPerGrove = this.levelConfig.innerTarget || 4;
    let accumulatedX = startOffset;

    for (let i = 0; i < total; i++) {
      if (isNested && i > 0 && i % treesPerGrove === 0) {
        accumulatedX += 220; // Distinct gap between groves in nested loop
      } else if (i > 0) {
        accumulatedX += 350; // Standard spacing between trees
      }

      const posX = accumulatedX;
      this.treePositions.push(posX);

      // If start of a grove in nested loop, create holographic Grove Marker Gateway
      if (isNested && i % treesPerGrove === 0) {
        const groveNum = Math.floor(i / treesPerGrove) + 1;
        const totalGroves = this.levelConfig.outerTarget || 3;
        
        const gate = this.add.sprite(posX - 90, groundY - 55, 'grove_gate');
        this.beaconsGroup.add(gate);

        const groveText = this.add.text(posX - 90, groundY - 125, `GROVE ${groveNum}/${totalGroves}`, {
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: '11px',
          color: '#c084fc',
          stroke: '#030712',
          strokeThickness: 3
        }).setOrigin(0.5);
        this.beaconsGroup.add(groveText);
      }

      // Beacon indicator on floor
      const beacon = this.add.sprite(posX - 90, groundY - 2, 'jump_beacon');
      beacon.setData('index', i);
      this.beaconsGroup.add(beacon);

      // Tree Obstacle
      const tree = this.add.sprite(posX, groundY - 50, 'cyber_tree');
      tree.setData('index', i);
      tree.setData('cleared', false);
      this.treesGroup.add(tree);

      // Collectible coins placement based on level configuration pattern
      let shouldSpawnCoin = false;
      let coinX = posX;
      let coinY = groundY - 110;

      if (this.levelConfig.coinPattern === 'floating_above') {
        shouldSpawnCoin = true;
        coinX = posX - 45;
        coinY = groundY - 95;
      } else if (this.levelConfig.coinPattern === 'every_other_tree') {
        shouldSpawnCoin = i % 2 === 0;
        coinX = posX;
        coinY = groundY - 110;
      } else if (this.levelConfig.coinPattern === 'on_tree') {
        shouldSpawnCoin = true;
        coinX = posX;
        coinY = groundY - 110;
      } else if (this.levelConfig.coinPattern === 'grove_end') {
        shouldSpawnCoin = true;
        coinX = posX;
        coinY = (i + 1) % 4 === 0 ? groundY - 125 : groundY - 105;
      } else if (this.levelConfig.coinPattern === 'river_trail') {
        shouldSpawnCoin = i % 2 === 1;
        coinX = posX;
        coinY = groundY - 110;
      }

      if (shouldSpawnCoin) {
        const coin = this.add.sprite(coinX, coinY, 'crystal_coin');
        coin.setData('index', i);
        coin.setData('collected', false);
        this.coinsGroup.add(coin);
      }
    }

    // Level 5 River & Bridge setup
    if (this.levelConfig.hasRiver) {
      const riverX = accumulatedX + 440;
      this.createRiverAndBridge(riverX, groundY);

      // Floating crystal rewards across the river bridge
      [-60, 0, 60].forEach((offset, idx) => {
        const bridgeCoin = this.add.sprite(riverX + offset, groundY - 65, 'crystal_coin');
        bridgeCoin.setData('index', total + idx);
        bridgeCoin.setData('collected', false);
        this.coinsGroup.add(bridgeCoin);
      });
    }
  }

  private createRiverAndBridge(posX: number, groundY: number) {
    // River Container
    this.riverObject = this.add.container(posX, groundY + 10);
    const riverWater = this.add.rectangle(0, 0, 240, 50, 0x0284c7, 0.85);
    const riverWave1 = this.add.rectangle(-60, -15, 80, 4, 0x38bdf8);
    const riverWave2 = this.add.rectangle(40, -5, 90, 4, 0x38bdf8);
    const riverGlow = this.add.rectangle(0, -22, 240, 6, 0x67e8f9);

    this.riverObject.add([riverWater, riverWave1, riverWave2, riverGlow]);

    // Bridge starts invisible until loop condition breaks safely
    this.bridgeObject = this.add.container(posX, groundY - 8);
    const bridgePlank = this.add.rectangle(0, 0, 260, 10, 0xa855f7);
    const bridgeRail = this.add.rectangle(0, -10, 260, 3, 0xec4899);
    this.bridgeObject.add([bridgePlank, bridgeRail]);
    this.bridgeObject.setAlpha(0); // Appears on break
  }

  update(time: number, delta: number) {
    if (this.isGameOver || this.isVictory) return;

    const deltaSec = delta / 1000;
    const speed = this.isRunning ? (this.levelConfig.speed * this.speedMultiplier) : 0;

    // Scroll ground and background
    if (this.groundTile) {
      this.groundTile.tilePositionX += speed * deltaSec;
    }

    // Run animation (legs moving)
    if (this.isRunning && !this.isJumping) {
      this.runAnimTimer += delta * 0.018;
      const legOffset = Math.sin(this.runAnimTimer) * 8;
      this.playerLegLeft.y = 20 + legOffset;
      this.playerLegRight.y = 20 - legOffset;
      this.playerBody.y = Math.abs(Math.sin(this.runAnimTimer)) * 2;
      this.playerHead.y = -18 + Math.abs(Math.sin(this.runAnimTimer)) * 2;
    }

    // Handle Jump physics arc
    if (this.isJumping) {
      this.jumpVelocityY += 1900 * deltaSec; // Snappy physics
      this.player.y += this.jumpVelocityY * deltaSec;
      const groundY = this.scale.height - 70 - 32;

      if (this.player.y >= groundY) {
        this.player.y = groundY;
        this.isJumping = false;
        this.jumpVelocityY = 0;
        this.playerLegLeft.y = 20;
        this.playerLegRight.y = 20;
      }
    }

    // Move all obstacles leftward to simulate forward running
    const moveX = speed * deltaSec;

    // Move beacons
    this.beaconsGroup.getChildren().forEach((obj) => {
      const beacon = obj as Phaser.GameObjects.Sprite;
      beacon.x -= moveX;
    });

    // Move trees
    this.treesGroup.getChildren().forEach((obj) => {
      const tree = obj as Phaser.GameObjects.Sprite;
      tree.x -= moveX;

      const treeIndex = tree.getData('index') as number;
      const cleared = tree.getData('cleared') as boolean;

      // Check collision/vault when tree is close to player (player.x = 140)
      const dist = tree.x - this.player.x;

      // Proximity check for manual jump (Level 1)
      if (!this.automatedMode && !cleared) {
        // If tree is right in front (-20 to 25px) and player is NOT jumping -> CRASH!
        if (dist > -20 && dist < 22) {
          if (!this.isJumping || this.player.y > (this.scale.height - 70 - 65)) {
            // Player hit tree!
            this.handlePlayerTrip('Ouch! You ran straight into a tree! Time your jump as you approach the beacon.');
            return;
          }
        }

        // Successfully passed over tree
        if (dist <= -20 && !cleared) {
          tree.setData('cleared', true);
          this.treesPassed += 1;
          this.spawnSuccessParticles(tree.x + 20, tree.y);
          if (this.callbacks.onJumpExecuted) {
            this.callbacks.onJumpExecuted(treeIndex);
          }
          if (this.callbacks.onProgressUpdate) {
            this.callbacks.onProgressUpdate({
              current: this.treesPassed,
              total: this.levelConfig.treeCount,
              coins: this.coinsCollected
            });
          }
        }
      }
    });

    // Move Coins & Check Pickup
    this.coinsGroup.getChildren().forEach((obj) => {
      const coin = obj as Phaser.GameObjects.Sprite;
      coin.x -= moveX;
      coin.angle += 2; // subtle spin

      const collected = coin.getData('collected') as boolean;
      if (!collected && Math.abs(coin.x - this.player.x) < 32 && Math.abs(coin.y - this.player.y) < 40) {
        coin.setData('collected', true);
        this.collectCoin(coin);
      }
    });

    // Move River & Bridge if Level 5
    if (this.riverObject) {
      this.riverObject.x -= moveX;
      if (this.bridgeObject) {
        this.bridgeObject.x = this.riverObject.x;
      }

      // If player reaches river
      const riverDist = this.riverObject.x - this.player.x;
      if (riverDist < 30 && riverDist > -70) {
        // If bridge is NOT active -> fell in water
        if (!this.bridgeDeployed || (this.bridgeObject && this.bridgeObject.alpha < 0.5)) {
          this.handlePlayerTrip('Splash! The while loop crashed into the river without deploying the bridge! Always specify a break/exit condition.');
          return;
        }
      }
    }

    // Check automated script progress
    if (this.automatedMode && this.isRunning) {
      this.updateAutomatedExecution(delta);
    }

    // Check Level Complete in manual mode
    if (!this.automatedMode && this.treesPassed >= this.levelConfig.treeCount && !this.isVictory) {
      this.handleLevelSuccess();
    }
  }

  /**
   * Automated Execution Engine (Used for Levels 2, 3, 4, 5)
   * The React UI sends the user's compiled loop commands.
   * Characters jumps & acts in sync with incoming trees.
   */
  public executeAutomatedScript(commands: Array<{ action: string; duration?: number; targetIndex?: number; loopInfo?: { outer?: number; inner?: number } }>) {
    this.automatedMode = true;
    this.isRunning = true;
    this.scriptSequence = commands;
    this.currentStepIndex = 0;
    this.stepTimer = 0;
  }

  private updateAutomatedExecution(delta: number) {
    if (this.scriptSequence.length === 0) {
      this.handlePlayerTrip('Loop condition evaluated to False from the start! Zero jump instructions were generated.');
      return;
    }

    // Check incoming tree to sync jump
    const nextTree = this.treesGroup.getChildren().find((obj) => {
      const tree = obj as Phaser.GameObjects.Sprite;
      return !tree.getData('cleared') && tree.x > (this.player.x - 20);
    }) as Phaser.GameObjects.Sprite | undefined;

    if (nextTree) {
      const dist = nextTree.x - this.player.x;

      // When approaching tree (within 105px)
      if (dist <= 105) {
        // If still in the landing buffer of a prior jump, snap to ground so jump executes immediately
        if (this.isJumping && dist <= 50) {
          this.player.y = this.scale.height - 70 - 32;
          this.isJumping = false;
          this.jumpVelocityY = 0;
        }

        if (!this.isJumping) {
          if (this.currentStepIndex >= this.scriptSequence.length) {
            // Script finished too early before all trees were cleared
            if (dist <= 25) {
              this.handlePlayerTrip(`Loop ended early! Cleared ${this.treesPassed} out of ${this.levelConfig.treeCount} trees.`);
            }
            return;
          }

          const step = this.scriptSequence[this.currentStepIndex];
          if (step.action === 'jump') {
            this.triggerPlayerJump();
            nextTree.setData('cleared', true);
            this.treesPassed += 1;
            this.spawnSuccessParticles(nextTree.x + 10, nextTree.y);

            const loopInfo = (step as { loopInfo?: { outer?: number; inner?: number } }).loopInfo;
            if (this.callbacks.onProgressUpdate) {
              this.callbacks.onProgressUpdate({
                current: this.treesPassed,
                total: this.levelConfig.treeCount,
                coins: this.coinsCollected,
                outerLoop: loopInfo?.outer,
                innerLoop: loopInfo?.inner
              });
            }
            if (this.callbacks.onJumpExecuted) {
              this.callbacks.onJumpExecuted(this.treesPassed - 1);
            }
            this.currentStepIndex++;
          } else if (step.action === 'collect_coin') {
            this.currentStepIndex++;
          }
        }
      }
    } else if (this.levelConfig.hasRiver && this.riverObject) {
      // All trees passed, river approaching!
      const riverDist = this.riverObject.x - this.player.x;

      // Deploy bridge when river is within 280px
      if (riverDist <= 280 && !this.bridgeDeployed) {
        const step = this.scriptSequence[this.currentStepIndex];
        if (step && (step.action === 'deploy_bridge' || step.action === 'break')) {
          this.deployBridge();
          this.currentStepIndex++;
        }
      }

      // If player passed river onto safe ground
      if (this.riverObject.x < (this.player.x - 140) && !this.isVictory) {
        this.handleLevelSuccess();
      }
    } else {
      // Non-river level: check if all trees are cleared
      if (this.treesPassed >= this.levelConfig.treeCount && !this.isVictory) {
        this.handleLevelSuccess();
      }
    }
  }

  public deployBridge() {
    this.bridgeDeployed = true;
    if (this.bridgeObject) {
      this.tweens.add({
        targets: this.bridgeObject,
        alpha: 1,
        y: this.scale.height - 70 - 10,
        duration: 350,
        ease: 'Back.easeOut'
      });
      playCoinSound();
    }
  }

  public triggerPlayerJump() {
    if (this.isJumping) return;
    this.isJumping = true;
    this.jumpVelocityY = -520; // Upward impulse
    playJumpSound();

    // Particle burst at feet
    this.spawnJumpDust(this.player.x, this.player.y + 26);
  }

  private collectCoin(coin: Phaser.GameObjects.Sprite) {
    playCoinSound();
    const value = this.coinMultiplier || 1;
    this.coinsCollected += value;
    this.spawnCoinSparkles(coin.x, coin.y);
    this.spawnFloatingText(coin.x, coin.y - 14, `+${value}`, value > 1 ? '#fbbf24' : '#22d3ee');

    this.tweens.add({
      targets: coin,
      y: coin.y - 40,
      alpha: 0,
      scaleX: 1.5,
      scaleY: 1.5,
      duration: 250,
      onComplete: () => coin.destroy()
    });

    if (this.callbacks.onCoinCollected) {
      this.callbacks.onCoinCollected(this.coinsCollected, value);
    }
    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: this.treesPassed,
        total: this.levelConfig.treeCount,
        coins: this.coinsCollected
      });
    }
  }

  private spawnFloatingText(x: number, y: number, text: string, color: string = '#22d3ee') {
    const floatText = this.add.text(x, y, text, {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '14px',
      color: color,
      stroke: '#030712',
      strokeThickness: 3
    }).setOrigin(0.5);

    this.tweens.add({
      targets: floatText,
      y: y - 30,
      alpha: 0,
      duration: 550,
      ease: 'Cubic.easeOut',
      onComplete: () => floatText.destroy()
    });
  }

  private spawnJumpDust(x: number, y: number) {
    const emitter = this.add.particles(x, y, 'particle_dot', {
      speed: { min: 40, max: 120 },
      angle: { min: 200, max: 340 },
      scale: { start: 0.6, end: 0 },
      alpha: { start: 0.9, end: 0 },
      lifespan: 250,
      quantity: 5
    });
    this.time.delayedCall(250, () => emitter.destroy());
  }

  private spawnSuccessParticles(x: number, y: number) {
    const emitter = this.add.particles(x, y, 'particle_dot', {
      speed: { min: 60, max: 160 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.8, end: 0 },
      tint: [0x22d3ee, 0x10b981, 0xc084fc],
      lifespan: 400,
      quantity: 8
    });
    this.time.delayedCall(400, () => emitter.destroy());
  }

  private spawnCoinSparkles(x: number, y: number) {
    const emitter = this.add.particles(x, y, 'particle_dot', {
      speed: { min: 70, max: 180 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.9, end: 0 },
      tint: [0xfbbf24, 0xfef08a, 0xffffff],
      lifespan: 450,
      quantity: 12
    });
    this.time.delayedCall(450, () => emitter.destroy());
  }

  private handlePlayerTrip(reason: string) {
    if (this.isGameOver) return;
    this.isGameOver = true;
    this.isRunning = false;
    playErrorSound();

    // Screen Shake on failure!
    this.cameras.main.shake(350, 0.025);

    // Trip animation: rotate player & drop
    this.tweens.add({
      targets: this.player,
      angle: 90,
      y: this.player.y + 15,
      duration: 300,
      ease: 'Bounce.easeOut'
    });

    if (this.callbacks.onHeartLost) {
      this.callbacks.onHeartLost();
    }

    this.time.delayedCall(500, () => {
      if (this.callbacks.onLevelFailed) {
        this.callbacks.onLevelFailed(reason);
      }
    });
  }

  private handleLevelSuccess() {
    if (this.isVictory) return;
    this.isVictory = true;
    this.isRunning = false;
    playSuccessSound();

    const durationSec = Math.max(1, Math.round((Date.now() - this.levelStartTime) / 100) / 10);

    // Victory celebration jump
    this.tweens.add({
      targets: this.player,
      y: this.player.y - 45,
      yoyo: true,
      duration: 350,
      repeat: 1
    });

    this.time.delayedCall(600, () => {
      if (this.callbacks.onLevelComplete) {
        this.callbacks.onLevelComplete({
          treesCleared: this.treesPassed,
          coinsCollected: this.coinsCollected,
          completionTime: durationSec,
          perfectJumps: true
        });
      }
    });
  }

  public resetScene() {
    this.scene.restart();
  }
}
