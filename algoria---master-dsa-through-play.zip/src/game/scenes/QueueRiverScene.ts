import Phaser from 'phaser';
import {
  playCoinSound,
  playErrorSound,
  playSuccessSound,
  playBoatWhistleSound,
  playEnqueueSound,
  playDequeueSound,
  playSnakeTurnSound,
  playPriorityChime
} from '../../utils/audio.ts';

export interface BoatData {
  id: string;
  name: string;
  ticketNumber: number;
  cargo: string;
  color: number;
  priority?: number; // 1 = VIP (highest), 2 = Express, 3 = Standard
  isVip?: boolean;
}

export interface QueueLevelConfig {
  id: number;
  type: string;
  targetCount: number;
  gridSize?: { cols: number; rows: number };
  initialLength?: number;
  speedMs?: number;
  hasObstacles?: boolean;
  obstacleCount?: number;
  boatStream?: BoatData[];
}

export interface QueueSceneCallbacks {
  onProgressUpdate?: (data: { current: number; total: number; coins: number; frontItem?: any; rearItem?: any; queueSize?: number }) => void;
  onQueueUpdated?: (data: { queue: any[]; lastAction: string }) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: { itemsCleared: number; coinsCollected: number; completionTime: number; perfectJumps?: boolean }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
}

export class QueueRiverScene extends Phaser.Scene {
  private levelConfig!: QueueLevelConfig;
  private callbacks!: QueueSceneCallbacks;
  private characterId: string = 'bit_byte';
  private coinMultiplier: number = 1;
  private speedMultiplier: number = 1.0;

  // General State
  private isGameOver: boolean = false;
  private isVictory: boolean = false;
  private levelStartTime: number = 0;
  private coinsCollected: number = 0;
  private itemsCleared: number = 0;

  // Snake Queue Mode State (Levels 1 & 2)
  private snakeBody: Array<{ x: number; y: number }> = [];
  private snakeDir: { x: number; y: number } = { x: 1, y: 0 };
  private nextSnakeDir: { x: number; y: number } = { x: 1, y: 0 };
  private foodPos: { x: number; y: number } = { x: 10, y: 5 };
  private obstacles: Array<{ x: number; y: number }> = [];
  private snakeTimer: number = 0;
  private snakeStepInterval: number = 170;
  private cols: number = 18;
  private rows: number = 10;
  private cellW: number = 42;
  private cellH: number = 32;
  private gridOffsetX: number = 50;
  private gridOffsetY: number = 24;

  // Visual label references
  private frontLabelText!: Phaser.GameObjects.Text;
  private rearLabelText!: Phaser.GameObjects.Text;
  private snakeGraphics!: Phaser.GameObjects.Graphics;
  private foodSprite!: Phaser.GameObjects.Graphics;

  // Boat Queue Mode State (Levels 3, 4, 5)
  private boatQueue: BoatData[] = [];
  private pendingArrivals: BoatData[] = [];
  private boatContainers: Map<string, Phaser.GameObjects.Container> = new Map();
  private maxDockSlots: number = 5;
  private dockPositions: Array<{ x: number; y: number }> = [];
  private waterRipples!: Phaser.GameObjects.Graphics;
  private riverTimer: number = 0;
  private dockIndicatorLabels: Phaser.GameObjects.Text[] = [];

  constructor() {
    super({ key: 'QueueRiverScene' });
  }

  init(data: {
    levelConfig: QueueLevelConfig;
    callbacks: QueueSceneCallbacks;
    characterId?: string;
    coinMultiplier?: number;
    speedMultiplier?: number;
  }) {
    this.levelConfig = data.levelConfig;
    this.callbacks = data.callbacks || {};
    this.characterId = data.characterId || 'bit_byte';
    this.coinMultiplier = data.coinMultiplier || 1;
    this.speedMultiplier = data.speedMultiplier || 1.0;

    this.isGameOver = false;
    this.isVictory = false;
    this.coinsCollected = 0;
    this.itemsCleared = 0;
    this.levelStartTime = Date.now();

    // Reset snake mode
    this.snakeBody = [];
    this.snakeDir = { x: 1, y: 0 };
    this.nextSnakeDir = { x: 1, y: 0 };
    this.obstacles = [];

    // Reset boat mode
    this.boatQueue = [];
    this.pendingArrivals = [];
    this.boatContainers.clear();
  }

  create() {
    const { width, height } = this.scale;

    // Draw ambient cyber water background
    this.createCyberRiverBackground(width, height);

    if (this.levelConfig.type === 'snake_queue') {
      this.setupSnakeQueueMode();
    } else {
      this.setupBoatQueueMode();
    }

    // Keyboard controls for snake
    if (this.input.keyboard) {
      this.input.keyboard.on('keydown-UP', () => this.setDirection('up'));
      this.input.keyboard.on('keydown-W', () => this.setDirection('up'));
      this.input.keyboard.on('keydown-DOWN', () => this.setDirection('down'));
      this.input.keyboard.on('keydown-S', () => this.setDirection('down'));
      this.input.keyboard.on('keydown-LEFT', () => this.setDirection('left'));
      this.input.keyboard.on('keydown-A', () => this.setDirection('left'));
      this.input.keyboard.on('keydown-RIGHT', () => this.setDirection('right'));
      this.input.keyboard.on('keydown-D', () => this.setDirection('right'));
    }

    // Initial progress sync
    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: 0,
        total: this.levelConfig.targetCount,
        coins: 0,
        queueSize: this.levelConfig.type === 'snake_queue' ? this.snakeBody.length : this.boatQueue.length
      });
    }
  }

  private createCyberRiverBackground(width: number, height: number) {
    const bg = this.add.graphics();
    // Deep neon blue/indigo water gradient
    bg.fillGradientStyle(0x06112d, 0x06112d, 0x032147, 0x032147, 1);
    bg.fillRect(0, 0, width, height);

    // Riverbanks (top & bottom neon border barriers)
    bg.fillStyle(0x090d24, 0.9);
    bg.fillRect(0, 0, width, 18);
    bg.fillRect(0, height - 18, width, 18);

    // Glowing neon water boundary lines
    bg.lineStyle(2, 0x06b6d4, 0.8);
    bg.lineBetween(0, 18, width, 18);
    bg.lineBetween(0, height - 18, width, height - 18);

    // Dynamic water ripples
    this.waterRipples = this.add.graphics();
  }

  // ==========================================
  // SNAKE QUEUE MODE (Levels 1 & 2)
  // ==========================================
  private setupSnakeQueueMode() {
    this.cols = this.levelConfig.gridSize?.cols || 18;
    this.rows = this.levelConfig.gridSize?.rows || 10;
    this.snakeStepInterval = Math.max(90, (this.levelConfig.speedMs || 170) / (this.speedMultiplier || 1.0));

    // Calculate grid layout centered
    this.cellW = 40;
    this.cellH = 30;
    this.gridOffsetX = Math.floor((this.scale.width - this.cols * this.cellW) / 2);
    this.gridOffsetY = Math.floor((this.scale.height - this.rows * this.cellH) / 2);

    // Grid wireframe background
    const gridGfx = this.add.graphics();
    gridGfx.lineStyle(1, 0x0284c7, 0.18);
    for (let c = 0; c <= this.cols; c++) {
      gridGfx.lineBetween(
        this.gridOffsetX + c * this.cellW,
        this.gridOffsetY,
        this.gridOffsetX + c * this.cellW,
        this.gridOffsetY + this.rows * this.cellH
      );
    }
    for (let r = 0; r <= this.rows; r++) {
      gridGfx.lineBetween(
        this.gridOffsetX,
        this.gridOffsetY + r * this.cellH,
        this.gridOffsetX + this.cols * this.cellW,
        this.gridOffsetY + r * this.cellH
      );
    }

    // Spawn Obstacles if Level 2
    if (this.levelConfig.hasObstacles) {
      const obstacleCoords = [
        { x: 5, y: 3 },
        { x: 12, y: 3 },
        { x: 5, y: 6 },
        { x: 12, y: 6 }
      ];
      this.obstacles = obstacleCoords;
      const rockGfx = this.add.graphics();
      rockGfx.fillStyle(0x475569, 0.95);
      rockGfx.lineStyle(2, 0x94a3b8, 1);
      this.obstacles.forEach((obs) => {
        const ox = this.gridOffsetX + obs.x * this.cellW;
        const oy = this.gridOffsetY + obs.y * this.cellH;
        rockGfx.fillRoundedRect(ox + 4, oy + 4, this.cellW - 8, this.cellH - 8, 6);
        rockGfx.strokeRoundedRect(ox + 4, oy + 4, this.cellW - 8, this.cellH - 8, 6);
      });
    }

    // Initial snake queue body: [Tail (front), Body, Head (rear)]
    // In Queue terminology: items leave at FRONT (tail), new items enter at REAR (head)
    const startY = 4;
    this.snakeBody = [
      { x: 4, y: startY }, // FRONT (oldest, dequeued on next step unless eating)
      { x: 5, y: startY },
      { x: 6, y: startY }  // REAR (newest, where motion enqueues new cell)
    ];

    this.snakeGraphics = this.add.graphics();
    this.foodSprite = this.add.graphics();

    // Floating Queue Labels on screen
    this.frontLabelText = this.add.text(0, 0, 'FRONT [DEQUEUE]', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '11px',
      color: '#ec4899',
      stroke: '#030712',
      strokeThickness: 3
    }).setOrigin(0.5);

    this.rearLabelText = this.add.text(0, 0, 'REAR [ENQUEUE]', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '11px',
      color: '#22d3ee',
      stroke: '#030712',
      strokeThickness: 3
    }).setOrigin(0.5);

    // Spawn first food
    this.spawnFood();

    // Render initial snake
    this.renderSnake();
    this.notifyQueueState('INITIAL');
  }

  public setDirection(dirName: 'up' | 'down' | 'left' | 'right') {
    if (this.isGameOver || this.isVictory) return;

    let targetDir = { x: 0, y: 0 };
    if (dirName === 'up') targetDir = { x: 0, y: -1 };
    if (dirName === 'down') targetDir = { x: 0, y: 1 };
    if (dirName === 'left') targetDir = { x: -1, y: 0 };
    if (dirName === 'right') targetDir = { x: 1, y: 0 };

    // Prevent immediate 180-degree self-reversal
    if (this.snakeDir.x + targetDir.x === 0 && this.snakeDir.y + targetDir.y === 0) {
      return;
    }

    this.nextSnakeDir = targetDir;
    playSnakeTurnSound();
  }

  private stepSnake() {
    if (this.isGameOver || this.isVictory) return;

    this.snakeDir = this.nextSnakeDir;
    const currentHead = this.snakeBody[this.snakeBody.length - 1];
    const newHead = {
      x: currentHead.x + this.snakeDir.x,
      y: currentHead.y + this.snakeDir.y
    };

    // 1. Check Boundary Collision
    if (newHead.x < 0 || newHead.x >= this.cols || newHead.y < 0 || newHead.y >= this.rows) {
      this.handleSnakeCrash('Collision with riverbank! Keep the snake queue within safe water channels.');
      return;
    }

    // 2. Check Obstacle Collision
    const hitObstacle = this.obstacles.some((obs) => obs.x === newHead.x && obs.y === newHead.y);
    if (hitObstacle) {
      this.handleSnakeCrash('Collision with river basalt rock! Steer around obstacles.');
      return;
    }

    // 3. Check Self Collision (ignoring tail if tail will be dequeued)
    const eating = (newHead.x === this.foodPos.x && newHead.y === this.foodPos.y);
    const bodyToCheck = eating ? this.snakeBody : this.snakeBody.slice(1);
    const hitSelf = bodyToCheck.some((seg) => seg.x === newHead.x && seg.y === newHead.y);
    if (hitSelf) {
      this.handleSnakeCrash('Queue looped into itself! Avoid crossing your own trail.');
      return;
    }

    // 4. Perform Queue Operations
    // ENQUEUE new head at the REAR
    this.snakeBody.push(newHead);
    playEnqueueSound();

    if (eating) {
      // EAT CRYSTAL: Do NOT dequeue tail! The queue grows by 1!
      playCoinSound();
      this.itemsCleared++;
      const gained = 15 * this.coinMultiplier;
      this.coinsCollected += gained;
      this.spawnSparklesAtGrid(newHead.x, newHead.y);

      if (this.callbacks.onCoinCollected) {
        this.callbacks.onCoinCollected(this.coinsCollected, gained);
      }
      if (this.callbacks.onProgressUpdate) {
        this.callbacks.onProgressUpdate({
          current: this.itemsCleared,
          total: this.levelConfig.targetCount,
          coins: this.coinsCollected,
          frontItem: this.snakeBody[0],
          rearItem: newHead,
          queueSize: this.snakeBody.length
        });
      }

      this.notifyQueueState('ENQUEUE (GROW)');

      // Check Victory
      if (this.itemsCleared >= this.levelConfig.targetCount) {
        this.handleLevelSuccess();
        return;
      }

      this.spawnFood();
    } else {
      // NORMAL MOVE: DEQUEUE oldest segment from FRONT
      this.snakeBody.shift();
      playDequeueSound();
      this.notifyQueueState('DEQUEUE (SLIDE)');
    }

    this.renderSnake();
  }

  private renderSnake() {
    this.snakeGraphics.clear();

    const len = this.snakeBody.length;
    for (let i = 0; i < len; i++) {
      const seg = this.snakeBody[i];
      const px = this.gridOffsetX + seg.x * this.cellW;
      const py = this.gridOffsetY + seg.y * this.cellH;

      if (i === len - 1) {
        // REAR / HEAD (Selected avatar cyber head)
        let headFill = 0x06b6d4;
        let headStroke = 0x38bdf8;
        if (this.characterId === 'algo_fox') {
          headFill = 0xea580c;
          headStroke = 0xfbbf24;
        } else if (this.characterId === 'cyber_nova') {
          headFill = 0xa855f7;
          headStroke = 0xf472b6;
        } else if (this.characterId === 'pixel_knight') {
          headFill = 0x10b981;
          headStroke = 0x6ee7b7;
        }

        this.snakeGraphics.fillStyle(headFill, 1);
        this.snakeGraphics.fillRoundedRect(px + 2, py + 2, this.cellW - 4, this.cellH - 4, 8);
        this.snakeGraphics.lineStyle(2, headStroke, 1);
        this.snakeGraphics.strokeRoundedRect(px + 2, py + 2, this.cellW - 4, this.cellH - 4, 8);

        // Cyber visor eyes
        this.snakeGraphics.fillStyle(0xffffff, 1);
        const eyeX = px + this.cellW / 2 + this.snakeDir.x * 10;
        const eyeY = py + this.cellH / 2 + this.snakeDir.y * 8;
        this.snakeGraphics.fillCircle(eyeX, eyeY, 3.5);
      } else if (i === 0) {
        // FRONT / TAIL (Pink glowing segment being dequeued)
        this.snakeGraphics.fillStyle(0xec4899, 0.95);
        this.snakeGraphics.fillRoundedRect(px + 3, py + 3, this.cellW - 6, this.cellH - 6, 7);
        this.snakeGraphics.lineStyle(2, 0xf472b6, 1);
        this.snakeGraphics.strokeRoundedRect(px + 3, py + 3, this.cellW - 6, this.cellH - 6, 7);
      } else {
        // Body segment (Gradient purple cyber links)
        const alpha = 0.6 + (i / len) * 0.35;
        this.snakeGraphics.fillStyle(0x8b5cf6, alpha);
        this.snakeGraphics.fillRoundedRect(px + 3, py + 3, this.cellW - 6, this.cellH - 6, 5);
        this.snakeGraphics.lineStyle(1.5, 0xa78bfa, 0.8);
        this.snakeGraphics.strokeRoundedRect(px + 3, py + 3, this.cellW - 6, this.cellH - 6, 5);
      }
    }

    // Update Floating Front & Rear Labels
    const tail = this.snakeBody[0];
    const head = this.snakeBody[len - 1];

    if (tail && this.frontLabelText) {
      const tailX = this.gridOffsetX + tail.x * this.cellW + this.cellW / 2;
      const tailY = this.gridOffsetY + tail.y * this.cellH - 12;
      this.frontLabelText.setPosition(tailX, tailY);
    }

    if (head && this.rearLabelText) {
      const headX = this.gridOffsetX + head.x * this.cellW + this.cellW / 2;
      const headY = this.gridOffsetY + head.y * this.cellH + this.cellH + 12;
      this.rearLabelText.setPosition(headX, headY);
    }
  }

  private spawnFood() {
    let valid = false;
    let newPos = { x: 0, y: 0 };
    let attempts = 0;

    while (!valid && attempts < 100) {
      attempts++;
      newPos = {
        x: Phaser.Math.Between(1, this.cols - 2),
        y: Phaser.Math.Between(1, this.rows - 2)
      };

      const onSnake = this.snakeBody.some((seg) => seg.x === newPos.x && seg.y === newPos.y);
      const onObstacle = this.obstacles.some((obs) => obs.x === newPos.x && obs.y === newPos.y);

      if (!onSnake && !onObstacle) {
        valid = true;
      }
    }

    this.foodPos = newPos;

    // Render pulsing food crystal
    this.foodSprite.clear();
    const fx = this.gridOffsetX + this.foodPos.x * this.cellW + this.cellW / 2;
    const fy = this.gridOffsetY + this.foodPos.y * this.cellH + this.cellH / 2;

    this.foodSprite.fillStyle(0xfbbf24, 1);
    this.foodSprite.beginPath();
    this.foodSprite.moveTo(fx, fy - 11);
    this.foodSprite.lineTo(fx + 10, fy);
    this.foodSprite.lineTo(fx, fy + 11);
    this.foodSprite.lineTo(fx - 10, fy);
    this.foodSprite.closePath();
    this.foodSprite.fill();

    this.foodSprite.fillStyle(0xfef08a, 0.9);
    this.foodSprite.fillCircle(fx, fy, 4);

    this.foodSprite.lineStyle(1.5, 0xffffff, 1);
    this.foodSprite.strokeCircle(fx, fy, 7);
  }

  private handleSnakeCrash(reason: string) {
    if (this.isGameOver) return;
    this.isGameOver = true;
    playErrorSound();
    this.cameras.main.shake(300, 0.025);

    if (this.callbacks.onHeartLost) {
      this.callbacks.onHeartLost();
    }

    this.time.delayedCall(450, () => {
      if (this.callbacks.onLevelFailed) {
        this.callbacks.onLevelFailed(reason);
      }
    });
  }

  private notifyQueueState(actionName: string) {
    if (this.callbacks.onQueueUpdated) {
      const items = this.snakeBody.map((seg, idx) => ({
        id: `seg_${idx}`,
        label: idx === 0 ? 'FRONT (Tail)' : idx === this.snakeBody.length - 1 ? 'REAR (Head)' : `Body #${idx}`,
        isFront: idx === 0,
        isRear: idx === this.snakeBody.length - 1
      }));
      this.callbacks.onQueueUpdated({
        queue: items,
        lastAction: actionName
      });
    }
  }

  // ==========================================
  // BOAT QUEUE MODE (Levels 3, 4, 5)
  // ==========================================
  private setupBoatQueueMode() {
    const stream = [...(this.levelConfig.boatStream || [])];
    this.maxDockSlots = 5;

    // Precalculate dock slip positions along the river canal
    // Dock 0 = FRONT (Leftmost, near departure)
    // Dock 4 = REAR (Rightmost, where arrivals enter)
    this.dockPositions = [];
    const startX = 140;
    const spacingX = 145;
    const dockY = 180;

    for (let i = 0; i < this.maxDockSlots; i++) {
      this.dockPositions.push({
        x: startX + i * spacingX,
        y: dockY
      });
    }

    // Draw docks on canvas
    this.drawMarinaDocks();

    // Initial boats docking
    const initialCount = Math.min(4, stream.length);
    this.boatQueue = stream.slice(0, initialCount);
    this.pendingArrivals = stream.slice(initialCount);

    // Create container for each docked boat
    this.boatQueue.forEach((boat, idx) => {
      this.createBoatObject(boat, idx);
    });

    this.notifyBoatQueueState('INITIAL DOCKING');
  }

  private drawMarinaDocks() {
    const dockGfx = this.add.graphics();
    this.dockIndicatorLabels = [];

    this.dockPositions.forEach((pos, idx) => {
      // Wood/cyber dock slip outline
      dockGfx.fillStyle(0x0f172a, 0.8);
      dockGfx.fillRoundedRect(pos.x - 55, pos.y - 70, 110, 140, 12);
      dockGfx.lineStyle(2, idx === 0 ? 0xec4899 : 0x0284c7, 0.7);
      dockGfx.strokeRoundedRect(pos.x - 55, pos.y - 70, 110, 140, 12);

      // Mooring post
      dockGfx.fillStyle(0x38bdf8, 1);
      dockGfx.fillCircle(pos.x - 45, pos.y - 55, 4);
      dockGfx.fillCircle(pos.x + 45, pos.y - 55, 4);

      // Dock Slip Label
      const tag = idx === 0 ? 'SLIP 1 · FRONT' : idx === this.maxDockSlots - 1 ? 'SLIP 5 · REAR' : `SLIP ${idx + 1}`;
      const label = this.add.text(pos.x, pos.y - 82, tag, {
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: '10px',
        fontStyle: 'bold',
        color: idx === 0 ? '#f472b6' : '#38bdf8'
      }).setOrigin(0.5);
      this.dockIndicatorLabels.push(label);
    });

    // Big glowing departure exit gate on left
    const gateGfx = this.add.graphics();
    gateGfx.lineStyle(3, 0x10b981, 0.9);
    gateGfx.strokeRect(30, 80, 12, 200);
    gateGfx.fillStyle(0x10b981, 0.2);
    gateGfx.fillRect(30, 80, 12, 200);

    this.add.text(36, 180, '◀ DEQUEUE OUTFLOW', {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '9px',
      color: '#34d399',
      stroke: '#030712',
      strokeThickness: 3
    }).setOrigin(0.5).setAngle(-90);
  }

  private createBoatObject(boat: BoatData, dockIndex: number) {
    const pos = this.dockPositions[dockIndex];
    if (!pos) return;

    const container = this.add.container(pos.x, pos.y);
    const hullColor = boat.color || 0x06b6d4;

    // Boat Hull
    const hull = this.add.graphics();
    hull.fillStyle(hullColor, 1);
    hull.beginPath();
    hull.moveTo(-44, 20);
    hull.lineTo(-30, -22);
    hull.lineTo(30, -22);
    hull.lineTo(44, 20);
    hull.closePath();
    hull.fill();

    hull.lineStyle(2, 0xffffff, 0.8);
    hull.strokePath();

    // Cabin / Bridge
    const cabin = this.add.rectangle(0, -6, 36, 20, 0x0f172a);
    const windshield = this.add.rectangle(0, -10, 26, 6, 0x38bdf8);

    // Ticket Number Badge on Boat
    const ticketBg = this.add.rectangle(0, 8, 28, 14, 0x1e293b);
    const ticketText = this.add.text(0, 8, `#${boat.ticketNumber}`, {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '10px',
      fontStyle: 'bold',
      color: '#fbbf24'
    }).setOrigin(0.5);

    // Name label
    const nameText = this.add.text(0, 32, boat.name, {
      fontFamily: 'JetBrains Mono, monospace',
      fontSize: '9px',
      color: '#cbd5e1',
      stroke: '#030712',
      strokeThickness: 2
    }).setOrigin(0.5);

    container.add([hull, cabin, windshield, ticketBg, ticketText, nameText]);

    // Priority Queue VIP Badge (for Level 5)
    if (boat.priority !== undefined) {
      const isP1 = boat.priority === 1;
      const isP2 = boat.priority === 2;
      const badgeColor = isP1 ? 0xf59e0b : isP2 ? 0xa855f7 : 0x64748b;
      const badgeText = isP1 ? 'VIP P1' : isP2 ? 'EXP P2' : 'STD P3';

      const prioBg = this.add.rectangle(0, -32, 48, 14, badgeColor);
      const prioTxt = this.add.text(0, -32, badgeText, {
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: '9px',
        fontStyle: 'bold',
        color: '#ffffff'
      }).setOrigin(0.5);

      if (isP1) {
        // Glowing aura for VIP P1
        const aura = this.add.graphics();
        aura.lineStyle(2, 0xfde047, 1);
        aura.strokeCircle(0, 0, 48);
        container.add(aura);

        this.tweens.add({
          targets: aura,
          alpha: 0.3,
          duration: 400,
          yoyo: true,
          repeat: -1
        });
      }

      container.add([prioBg, prioTxt]);
    }

    // Interactive Click Handler
    container.setSize(100, 110);
    container.setInteractive({ useHandCursor: true });
    container.on('pointerdown', () => {
      this.handleBoatTapped(boat.id);
    });

    // Hover effect
    container.on('pointerover', () => {
      container.setScale(1.05);
    });
    container.on('pointerout', () => {
      container.setScale(1.0);
    });

    this.boatContainers.set(boat.id, container);
  }

  /**
   * Dispatches the specified boat or front boat
   */
  public handleBoatTapped(boatId?: string) {
    if (this.isGameOver || this.isVictory || this.boatQueue.length === 0) return;

    if (this.levelConfig.type === 'priority_queue') {
      // Level 5: Priority Queue Mode
      this.processPriorityQueueDispatch(boatId);
    } else {
      // Levels 3 & 4: Standard FIFO Queue Mode
      this.processFifoQueueDispatch(boatId);
    }
  }

  private processFifoQueueDispatch(boatId?: string) {
    const frontBoat = this.boatQueue[0];
    const targetBoat = boatId ? this.boatQueue.find((b) => b.id === boatId) : frontBoat;

    if (!targetBoat) return;

    // Strict FIFO check: targetBoat MUST be the front boat!
    if (targetBoat.id !== frontBoat.id) {
      this.handleQueueViolation(
        `FIFO Violation! Boat #${targetBoat.ticketNumber} is waiting in line! In FIFO, you must dispatch Boat #${frontBoat.ticketNumber} from the FRONT first.`
      );
      return;
    }

    // Success! Dequeue front boat
    this.dispatchBoat(frontBoat);
  }

  private processPriorityQueueDispatch(boatId?: string) {
    // Find highest priority currently waiting in queue (lowest numeric value: 1 > 2 > 3)
    let bestPriority = 999;
    this.boatQueue.forEach((b) => {
      const p = b.priority || 3;
      if (p < bestPriority) bestPriority = p;
    });

    // Among boats with bestPriority, the one with lowest ticketNumber (FIFO tie-breaker) is the right one
    const eligibleBoats = this.boatQueue.filter((b) => (b.priority || 3) === bestPriority);
    const expectedBoat = eligibleBoats.reduce((earliest, cur) =>
      cur.ticketNumber < earliest.ticketNumber ? cur : earliest
    );

    const targetBoat = boatId ? this.boatQueue.find((b) => b.id === boatId) : expectedBoat;
    if (!targetBoat) return;

    // Priority check
    const targetPriority = targetBoat.priority || 3;
    if (targetPriority > bestPriority) {
      this.handleQueueViolation(
        `Priority Queue Violation! A VIP vessel with Priority 1 is waiting and must be served before Priority ${targetPriority} vessels!`
      );
      return;
    }

    if (targetBoat.id !== expectedBoat.id) {
      this.handleQueueViolation(
        `Tie-breaker error! When two vessels share Priority ${bestPriority}, the one that arrived earlier (Ticket #${expectedBoat.ticketNumber}) must be dispatched first!`
      );
      return;
    }

    // Success!
    if (targetBoat.priority === 1) {
      playPriorityChime();
    }
    this.dispatchBoat(targetBoat);
  }

  private dispatchBoat(boat: BoatData) {
    playBoatWhistleSound();
    playDequeueSound();

    // Remove boat from active queue
    const boatIdx = this.boatQueue.findIndex((b) => b.id === boat.id);
    if (boatIdx >= 0) {
      this.boatQueue.splice(boatIdx, 1);
    }

    const container = this.boatContainers.get(boat.id);
    if (container) {
      // Animate boat accelerating downstream to the left
      this.tweens.add({
        targets: container,
        x: -120,
        y: container.y + 15,
        alpha: 0,
        duration: 550,
        ease: 'Cubic.easeIn',
        onComplete: () => {
          container.destroy();
          this.boatContainers.delete(boat.id);
        }
      });
    }

    this.itemsCleared++;
    const value = (boat.isVip ? 30 : 20) * this.coinMultiplier;
    this.coinsCollected += value;

    if (this.callbacks.onCoinCollected) {
      this.callbacks.onCoinCollected(this.coinsCollected, value);
    }

    // Shift remaining boats forward to their new dock slots
    this.realignBoatsInDocks();

    // If there are pending arrivals, enqueue next boat to the rear dock
    if (this.pendingArrivals.length > 0 && this.boatQueue.length < this.maxDockSlots) {
      const nextBoat = this.pendingArrivals.shift()!;
      this.boatQueue.push(nextBoat);
      this.createBoatObject(nextBoat, this.boatQueue.length - 1);
      playEnqueueSound();
    }

    // Progress update
    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: this.itemsCleared,
        total: this.levelConfig.targetCount,
        coins: this.coinsCollected,
        frontItem: this.boatQueue[0],
        rearItem: this.boatQueue[this.boatQueue.length - 1],
        queueSize: this.boatQueue.length
      });
    }

    this.notifyBoatQueueState('DEQUEUE SUCCESS');

    // Check Victory
    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(500, () => this.handleLevelSuccess());
    }
  }

  private realignBoatsInDocks() {
    this.boatQueue.forEach((boat, idx) => {
      const container = this.boatContainers.get(boat.id);
      const targetPos = this.dockPositions[idx];
      if (container && targetPos) {
        this.tweens.add({
          targets: container,
          x: targetPos.x,
          y: targetPos.y,
          duration: 350,
          ease: 'Cubic.easeOut'
        });
      }
    });
  }

  private handleQueueViolation(reason: string) {
    if (this.isGameOver) return;
    playErrorSound();
    this.cameras.main.shake(250, 0.02);

    if (this.callbacks.onHeartLost) {
      this.callbacks.onHeartLost();
    }

    if (this.callbacks.onLevelFailed) {
      this.callbacks.onLevelFailed(reason);
    }
  }

  private notifyBoatQueueState(actionName: string) {
    if (this.callbacks.onQueueUpdated) {
      const items = this.boatQueue.map((boat, idx) => ({
        id: boat.id,
        label: `${boat.name} (#${boat.ticketNumber})`,
        ticket: boat.ticketNumber,
        priority: boat.priority,
        isVip: boat.isVip,
        isFront: idx === 0,
        isRear: idx === this.boatQueue.length - 1
      }));
      this.callbacks.onQueueUpdated({
        queue: items,
        lastAction: actionName
      });
    }
  }

  // ==========================================
  // GENERAL LOOP & REWARDS
  // ==========================================
  update(time: number, delta: number) {
    if (this.isGameOver || this.isVictory) return;

    // Animate water flow waves
    this.riverTimer += delta * 0.002;
    this.waterRipples.clear();
    this.waterRipples.lineStyle(1.5, 0x38bdf8, 0.25);

    const { width, height } = this.scale;
    for (let y = 30; y < height - 30; y += 45) {
      this.waterRipples.beginPath();
      for (let x = 0; x < width; x += 30) {
        const waveY = y + Math.sin(this.riverTimer + x * 0.03 + y * 0.02) * 4;
        if (x === 0) this.waterRipples.moveTo(x, waveY);
        else this.waterRipples.lineTo(x, waveY);
      }
      this.waterRipples.stroke();
    }

    // Step Snake timer if Snake mode
    if (this.levelConfig.type === 'snake_queue') {
      this.snakeTimer += delta;
      if (this.snakeTimer >= this.snakeStepInterval) {
        this.snakeTimer = 0;
        this.stepSnake();
      }
    }
  }

  private spawnSparklesAtGrid(gridX: number, gridY: number) {
    const px = this.gridOffsetX + gridX * this.cellW + this.cellW / 2;
    const py = this.gridOffsetY + gridY * this.cellH + this.cellH / 2;

    const emitter = this.add.particles(px, py, 'particle_dot', {
      speed: { min: 40, max: 130 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.8, end: 0 },
      tint: [0xfbbf24, 0x22d3ee, 0x34d399],
      lifespan: 350,
      quantity: 10
    });
    this.time.delayedCall(350, () => emitter.destroy());
  }

  private handleLevelSuccess() {
    if (this.isVictory) return;
    this.isVictory = true;
    playSuccessSound();

    const durationSec = Math.max(1, Math.round((Date.now() - this.levelStartTime) / 100) / 10);

    this.time.delayedCall(600, () => {
      if (this.callbacks.onLevelComplete) {
        this.callbacks.onLevelComplete({
          itemsCleared: this.itemsCleared,
          coinsCollected: this.coinsCollected,
          completionTime: durationSec,
          perfectJumps: true
        });
      }
    });
  }

  public resetScene() {
    this.scene.restart();
  }
}
