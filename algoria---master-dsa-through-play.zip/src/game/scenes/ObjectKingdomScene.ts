import Phaser from 'phaser';
import {
  playCoinSound,
  playErrorSound,
  playSuccessSound,
  playFruitHarvestSound,
  playBranchClimbSound,
  playBstCorrectChoiceSound
} from '../../utils/audio.ts';

export interface ObjectKingdomCallbacks {
  onProgressUpdate?: (data: {
    current: number;
    total: number;
    coins?: number;
    activeStep?: number;
    consoleLog?: string[];
  }) => void;
  onCoinCollected?: (totalCoins: number, valueGained: number) => void;
  onLevelComplete?: (stats: {
    itemsCleared: number;
    coinsCollected: number;
    completionTime: number;
    perfect?: boolean;
  }) => void;
  onLevelFailed?: (reason: string) => void;
  onHeartLost?: () => void;
}

export class ObjectKingdomScene extends Phaser.Scene {
  private levelConfig!: any;
  private callbacks!: ObjectKingdomCallbacks;
  private characterId: string = 'bit_byte';
  private coinMultiplier: number = 1;

  private isGameOver: boolean = false;
  private isVictory: boolean = false;
  private levelStartTime: number = 0;
  private coinsCollected: number = 0;
  private itemsCleared: number = 0;
  private consoleLogs: string[] = [];

  // Visual Assets
  private playerAvatar!: Phaser.GameObjects.Container;
  private citadelGraphics!: Phaser.GameObjects.Graphics;
  private beamGraphics!: Phaser.GameObjects.Graphics;
  private robotContainers: Phaser.GameObjects.Container[] = [];
  private coreReactor!: Phaser.GameObjects.Arc;
  private coreRing!: Phaser.GameObjects.Arc;

  constructor() {
    super({ key: 'ObjectKingdomScene' });
  }

  init(data: {
    levelConfig: any;
    characterId?: string;
    coinMultiplier?: number;
    callbacks?: ObjectKingdomCallbacks;
  }) {
    this.levelConfig = data.levelConfig;
    this.characterId = data.characterId || 'bit_byte';
    this.coinMultiplier = data.coinMultiplier || 1;
    this.callbacks = data.callbacks || {};

    this.isGameOver = false;
    this.isVictory = false;
    this.levelStartTime = Date.now();
    this.coinsCollected = 0;
    this.itemsCleared = 0;
    this.consoleLogs = [`[OOP Kernel] Initialized Level ${this.levelConfig.id}: ${this.levelConfig.concept}`];
    this.robotContainers = [];
  }

  create() {
    const { width, height } = this.scale;

    // 1. Cyber-Citadel Background
    this.createCitadelAtmosphere(width, height);

    // 2. Citadel Towers & Floor Matrix
    this.drawCitadelArchitecture(width, height);

    // 3. Central Power Core
    this.createPowerCore(width / 2, height / 2 - 20);

    // 4. Beam graphics
    this.beamGraphics = this.add.graphics();
    this.beamGraphics.setDepth(15);

    // 5. Climbing / Exploring Player Avatar
    this.createPlayerAvatar(width / 2, height - 60);

    // 6. Level-specific initial staging
    this.setupLevelStaging(width, height);

    // 7. Initial callbacks
    this.notifyCallbacks();
  }

  private createCitadelAtmosphere(width: number, height: number) {
    const bg = this.add.graphics();
    // Royal Deep Violet to Cyber Indigo gradient
    bg.fillGradientStyle(0x1a0b36, 0x1a0b36, 0x070414, 0x070414, 1);
    bg.fillRect(0, 0, width, height);

    // Subtle isometric grid lines
    const grid = this.add.graphics();
    grid.lineStyle(1, 0x8b5cf6, 0.12);
    for (let x = 0; x < width; x += 40) {
      grid.lineBetween(x, 0, x, height);
    }
    for (let y = 0; y < height; y += 40) {
      grid.lineBetween(0, y, width, y);
    }

    // Floating arcane gold sparks
    const sparkGraphic = this.make.graphics({ x: 0, y: 0 });
    sparkGraphic.fillStyle(0xfde047, 0.9);
    sparkGraphic.fillCircle(3, 3, 3);
    sparkGraphic.generateTexture('arcaneSpark', 6, 6);
    sparkGraphic.destroy();

    this.add.particles(0, 0, 'arcaneSpark', {
      x: { min: 30, max: width - 30 },
      y: { min: 20, max: height - 40 },
      speedY: { min: -10, max: -30 },
      speedX: { min: -8, max: 8 },
      scale: { start: 0.8, end: 0.1 },
      alpha: { start: 0.8, end: 0 },
      lifespan: 2400,
      frequency: 250
    });
  }

  private drawCitadelArchitecture(width: number, height: number) {
    this.citadelGraphics = this.add.graphics();

    // Central Assembly Platform
    this.citadelGraphics.fillStyle(0x130a2e, 0.95);
    this.citadelGraphics.fillRoundedRect(width / 2 - 280, height / 2 - 95, 560, 190, 24);
    this.citadelGraphics.lineStyle(2, 0xa855f7, 0.6);
    this.citadelGraphics.strokeRoundedRect(width / 2 - 280, height / 2 - 95, 560, 190, 24);

    // Castle Citadel Battlement Towers (Left & Right)
    this.drawTower(80, height / 2 + 10, 'CLASS BLUEPRINT');
    this.drawTower(width - 80, height / 2 + 10, 'OBJECT HEAP');

    // Bottom Banner
    const ground = this.add.graphics();
    ground.fillStyle(0x0e0722, 0.92);
    ground.fillRoundedRect(16, height - 34, width - 32, 28, 14);
    ground.lineStyle(1.5, 0x8b5cf6, 0.4);
    ground.strokeRoundedRect(16, height - 34, width - 32, 28, 14);

    this.add.text(width / 2, height - 20, 'CITADEL OF OBJECTS · OBJECT-ORIENTED RUNTIME ENGINE', {
      fontSize: '10px',
      color: '#c084fc',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);
  }

  private drawTower(x: number, y: number, label: string) {
    const tower = this.add.graphics();
    // Tower base
    tower.fillStyle(0x1e1145, 0.9);
    tower.fillRoundedRect(x - 42, y - 60, 84, 120, 12);
    tower.lineStyle(2, 0x8b5cf6, 0.7);
    tower.strokeRoundedRect(x - 42, y - 60, 84, 120, 12);

    // Tower battlements
    tower.fillStyle(0x2e1a66, 1);
    tower.fillRect(x - 42, y - 72, 24, 14);
    tower.fillRect(x + 18, y - 72, 24, 14);

    // Label
    this.add.text(x, y + 44, label, {
      fontSize: '8px',
      color: '#e9d5ff',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);
  }

  private createPowerCore(x: number, y: number) {
    this.coreRing = this.add.circle(x, y, 38, 0xa855f7, 0.2);
    this.coreRing.setStrokeStyle(2, 0xc084fc, 0.8);

    this.coreReactor = this.add.circle(x, y, 22, 0x9333ea, 0.95);
    this.coreReactor.setStrokeStyle(2, 0xfde047, 1);

    // Glowing core pulse
    this.tweens.add({
      targets: this.coreRing,
      scale: 1.25,
      alpha: 0.05,
      duration: 1000,
      yoyo: true,
      repeat: -1
    });

    const coreLabel = this.add.text(x, y, 'CORE', {
      fontSize: '9px',
      color: '#ffffff',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);
  }

  private createPlayerAvatar(x: number, y: number) {
    this.playerAvatar = this.add.container(x, y);

    let auraColor = 0x06b6d4;
    let bodyColor = 0x0891b2;
    let strokeColor = 0x67e8f9;
    let label = 'BIT BYTE';

    if (this.characterId === 'algo_fox') {
      auraColor = 0xea580c;
      bodyColor = 0xc2410c;
      strokeColor = 0xfbbf24;
      label = 'ALGO FOX';
    } else if (this.characterId === 'cyber_nova') {
      auraColor = 0xa855f7;
      bodyColor = 0x7e22ce;
      strokeColor = 0xf472b6;
      label = 'CYBER NOVA';
    } else if (this.characterId === 'pixel_knight') {
      auraColor = 0x10b981;
      bodyColor = 0x047857;
      strokeColor = 0x6ee7b7;
      label = 'PIXEL KNIGHT';
    }

    const aura = this.add.circle(0, 0, 16, auraColor, 0.45);
    const body = this.add.circle(0, 0, 11, bodyColor, 1);
    body.setStrokeStyle(2, strokeColor, 1);

    const visor = this.add.rectangle(1, -2, 10, 4, 0xffffff, 0.95);

    const tag = this.add.text(0, -18, label, {
      fontSize: '8px',
      color: `#${strokeColor.toString(16).padStart(6, '0')}`,
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    this.playerAvatar.add([aura, body, visor, tag]);
    this.playerAvatar.setDepth(25);
  }

  private setupLevelStaging(width: number, height: number) {
    // Staging pedestals across the platform
    const pedestalX = [width / 2 - 160, width / 2, width / 2 + 160];
    const pedestalY = height / 2 + 25;

    pedestalX.forEach((x, idx) => {
      const pad = this.add.ellipse(x, pedestalY, 80, 24, 0x241154, 0.9);
      pad.setStrokeStyle(1.5, 0x8b5cf6, 0.7);

      const label = this.add.text(x, pedestalY + 16, `SLOT [${idx}]`, {
        fontSize: '8px',
        color: '#a78bfa',
        fontFamily: 'monospace'
      }).setOrigin(0.5);
    });
  }

  /**
   * Level 1: Instantiate an object
   */
  public executeInstantiateRobot(index: number) {
    if (this.isGameOver || this.isVictory) return;

    const instances = this.levelConfig.requiredInstances || [];
    if (index >= instances.length) return;

    const data = instances[index];
    const { width, height } = this.scale;
    const targetX = width / 2 - 160 + index * 160;
    const targetY = height / 2 + 15;

    playBstCorrectChoiceSound();

    // Laser assembly animation
    this.beamGraphics.clear();
    this.beamGraphics.lineStyle(3, 0x38bdf8, 0.9);
    this.beamGraphics.lineBetween(80, height / 2 - 40, targetX, targetY);

    this.tweens.add({
      targets: this.beamGraphics,
      alpha: { from: 1, to: 0 },
      duration: 350,
      onComplete: () => this.beamGraphics.clear()
    });

    // Robot Container
    const robot = this.add.container(targetX, targetY - 20);
    const aura = this.add.circle(0, 0, 22, 0x38bdf8, 0.4);
    const body = this.add.circle(0, 0, 16, 0x0284c7, 1);
    body.setStrokeStyle(2, 0x38bdf8, 1);
    const eye = this.add.rectangle(0, -3, 14, 5, 0xffffff, 0.95);

    const nameText = this.add.text(0, -28, data.name, {
      fontSize: '9px',
      color: '#38bdf8',
      fontStyle: 'bold',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    const roleText = this.add.text(0, 26, `${data.coreType} · ${data.energyLevel}EP`, {
      fontSize: '8px',
      color: '#fde047',
      fontFamily: 'monospace'
    }).setOrigin(0.5);

    robot.add([aura, body, eye, nameText, roleText]);
    robot.setScale(0);
    this.robotContainers.push(robot);

    this.tweens.add({
      targets: robot,
      scale: 1,
      duration: 400,
      ease: 'Back.easeOut'
    });

    playFruitHarvestSound();

    this.itemsCleared = Math.min(3, this.itemsCleared + 1);
    this.consoleLogs.push(`> new GuardianRobot("${data.name}", "${data.coreType}", ${data.energyLevel}) → Instance created!`);
    this.awardCoins(10);
    this.notifyCallbacks();

    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(600, () => this.triggerVictory());
    }
  }

  /**
   * Level 2: Test Encapsulation Setter / Getter
   */
  public executeEncapsulationTest(ruleIndex: number) {
    if (this.isGameOver || this.isVictory) return;

    const rules = this.levelConfig.encapsulationRules || [];
    if (ruleIndex >= rules.length) return;

    const rule = rules[ruleIndex];
    playFruitHarvestSound();

    // Deflection shield effect
    const { width, height } = this.scale;
    const shield = this.add.circle(width / 2, height / 2 - 20, 50, 0x10b981, 0.35);
    shield.setStrokeStyle(3, 0x34d399, 1);

    this.tweens.add({
      targets: shield,
      scale: 1.4,
      alpha: 0,
      duration: 500,
      onComplete: () => shield.destroy()
    });

    this.itemsCleared = Math.min(4, this.itemsCleared + 1);
    this.consoleLogs.push(`[DEFENDER] Field: #${rule.field} = ${rule.attackPayload} → INTERCEPTED: ${rule.expectedResult}`);
    this.awardCoins(10);
    this.notifyCallbacks();

    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(600, () => this.triggerVictory());
    }
  }

  /**
   * Level 3: Inheritance & Subclassing
   */
  public executeInheritanceDerivation(subclassIndex: number) {
    if (this.isGameOver || this.isVictory) return;

    const subclasses = this.levelConfig.hierarchyData?.subclasses || [];
    if (subclassIndex >= subclasses.length) return;

    const sub = subclasses[subclassIndex];
    const { width, height } = this.scale;
    const targetX = width / 2 - 160 + subclassIndex * 160;
    const targetY = height / 2 + 15;

    playFruitHarvestSound();

    // Chaining lightning line from Core to Subclass
    const lightning = this.add.graphics();
    lightning.lineStyle(2.5, 0xfde047, 0.9);
    lightning.lineBetween(width / 2, height / 2 - 20, targetX, targetY);

    this.tweens.add({
      targets: lightning,
      alpha: 0,
      duration: 400,
      onComplete: () => lightning.destroy()
    });

    const badge = this.add.container(targetX, targetY - 15);
    const circle = this.add.circle(0, 0, 20, 0x8b5cf6, 1);
    circle.setStrokeStyle(2, 0xfde047, 1);
    const iconText = this.add.text(0, -2, '▲', { fontSize: '14px', color: '#ffffff' }).setOrigin(0.5);
    const label = this.add.text(0, 26, sub.name, { fontSize: '8px', color: '#c084fc', fontFamily: 'monospace', fontStyle: 'bold' }).setOrigin(0.5);

    badge.add([circle, iconText, label]);
    badge.setScale(0);
    this.tweens.add({ targets: badge, scale: 1, duration: 350, ease: 'Back.easeOut' });

    this.itemsCleared = Math.min(3, this.itemsCleared + 1);
    this.consoleLogs.push(`> class ${sub.name} extends BaseGuardian { ${sub.superCall}; } → Derived!`);
    this.awardCoins(12);
    this.notifyCallbacks();

    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(600, () => this.triggerVictory());
    }
  }

  /**
   * Level 4: Polymorphic Dispatch
   */
  public executePolymorphicDispatch(botIndex: number) {
    if (this.isGameOver || this.isVictory) return;

    const team = this.levelConfig.polymorphicTeam || [];
    if (botIndex >= team.length) return;

    const bot = team[botIndex];
    const { width, height } = this.scale;
    const targetX = width / 2 - 160 + botIndex * 160;

    playSuccessSound();

    // Particle burst for unique ability
    const burst = this.add.particles(targetX, height / 2, 'arcaneSpark', {
      speed: { min: 60, max: 140 },
      angle: { min: 0, max: 360 },
      scale: { start: 1.2, end: 0 },
      alpha: { start: 1, end: 0 },
      lifespan: 600,
      quantity: 18
    });
    this.time.delayedCall(700, () => burst.destroy());

    this.itemsCleared = Math.min(3, this.itemsCleared + 1);
    this.consoleLogs.push(`> ${bot.name}.activateAbility() → [${bot.classType}]: ${bot.overrideAction}`);
    this.awardCoins(12);
    this.notifyCallbacks();

    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(600, () => this.triggerVictory());
    }
  }

  /**
   * Level 5: Abstraction Interface Contract
   */
  public executeContractMethod(methodIndex: number) {
    if (this.isGameOver || this.isVictory) return;

    const methods = this.levelConfig.abstractContract?.abstractMethods || [];
    if (methodIndex >= methods.length) return;

    const m = methods[methodIndex];
    playSuccessSound();

    // Pulse power core
    this.tweens.add({
      targets: this.coreReactor,
      scale: 1.4,
      duration: 200,
      yoyo: true
    });

    this.itemsCleared = Math.min(3, this.itemsCleared + 1);
    this.consoleLogs.push(`> Implemented contract method: ${m.name} → FULFILLED!`);
    this.awardCoins(15);
    this.notifyCallbacks();

    if (this.itemsCleared >= this.levelConfig.targetCount) {
      this.time.delayedCall(600, () => this.triggerVictory());
    }
  }

  private awardCoins(val: number) {
    const gain = Math.round(val * this.coinMultiplier);
    this.coinsCollected += gain;
    playCoinSound();
    if (this.callbacks.onCoinCollected) {
      this.callbacks.onCoinCollected(this.coinsCollected, gain);
    }
  }

  private triggerVictory() {
    this.isVictory = true;
    playSuccessSound();

    const completionTime = Math.round((Date.now() - this.levelStartTime) / 100) / 10;

    if (this.callbacks.onLevelComplete) {
      this.callbacks.onLevelComplete({
        itemsCleared: this.itemsCleared,
        coinsCollected: this.coinsCollected,
        completionTime
      });
    }
  }

  private notifyCallbacks() {
    if (this.callbacks.onProgressUpdate) {
      this.callbacks.onProgressUpdate({
        current: this.itemsCleared,
        total: this.levelConfig.targetCount,
        coins: this.coinsCollected,
        consoleLog: [...this.consoleLogs]
      });
    }
  }
}
