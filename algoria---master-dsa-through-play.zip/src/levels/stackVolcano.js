/**
 * Stack Volcano - Level Configurations
 * Extensible configuration file for World 2: Stack Volcano.
 * Teaches LIFO (Last-In, First-Out) operations: push, pop, peek, undo, and reversal.
 */

export const STACK_VOLCANO_LEVELS = [
  {
    id: 1,
    title: 'Level 1: Basalt Foundation',
    concept: 'Stack Push (LIFO Introduction)',
    subtitle: 'Push 3 basalt boulders onto the pedestal',
    type: 'push_basics',
    targetCount: 3,
    initialStack: [],
    availableRocks: [
      { id: 'r1', label: 'Basalt 1', color: '#f97316', value: 10 },
      { id: 'r2', label: 'Basalt 2', color: '#ea580c', value: 20 },
      { id: 'r3', label: 'Basalt 3', color: '#c2410c', value: 30 }
    ],
    targetTime: 12,
    coinReward: 15,
    novaIntro: {
      mood: 'serious',
      message: "Welcome to Stack Volcano! Lava surrounds us. To build an escape tower, we use a STACK data structure. Tap PUSH to place 3 basalt rocks onto the pedestal one by one!"
    },
    hint: "Algorithm Hint: A Stack only allows adding elements to the TOP. Press PUSH 3 times to stack all 3 boulders!",
    failureMessage: "The tower collapsed before reaching 3 boulders! Rebuild from the foundation.",
    successMessage: "Tower foundation secured! Notice how each new boulder rests directly on TOP of the previous one.",
    recap: {
      conceptName: 'Stack Push: Adding to the Top',
      simpleSummary: 'A STACK is a linear data structure where elements are added and removed only from one end: the TOP.',
      pythonCode: [
        '# Initialize an empty stack',
        'stack = []',
        '',
        '# Push elements onto the stack',
        'stack.append("Basalt 1")  # Index 0 (Bottom)',
        'stack.append("Basalt 2")  # Index 1',
        'stack.append("Basalt 3")  # Index 2 (TOP)'
      ],
      jsCode: [
        '// Initialize empty array as a stack',
        'const stack = [];',
        '',
        '// Push elements onto the top',
        'stack.push("Basalt 1"); // Bottom',
        'stack.push("Basalt 2");',
        'stack.push("Basalt 3"); // Top'
      ],
      explanationLines: [
        'Each "push" operation places the new element on the TOP of the stack.',
        'Items below cannot be directly accessed until the top items are removed.',
        'This forms the foundation of LIFO: Last-In, First-Out!'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: Magma Surge Pop',
    concept: 'Stack Pop (LIFO Removal)',
    subtitle: 'Pop the unstable top rock before rising lava strikes',
    type: 'pop_removal',
    targetCount: 2,
    initialStack: [
      { id: 'b1', label: 'Stable Base', color: '#ea580c', value: 10 },
      { id: 'b2', label: 'Mid Basalt', color: '#f97316', value: 20 },
      { id: 'b3', label: 'Unstable Core', color: '#ef4444', value: 50, unstable: true }
    ],
    targetTime: 10,
    coinReward: 20,
    novaIntro: {
      mood: 'surprised',
      message: "Warning! The top boulder is superheated and attracting rising magma! We must remove it immediately. In a Stack, you can only remove the TOP element using POP! Tap POP to vent the unstable rock!"
    },
    hint: "Algorithm Hint: In LIFO, you cannot pull rocks out from the middle or bottom. You MUST pop the TOP element first!",
    failureMessage: "The superheated top boulder exploded into the lava! Always POP the top first.",
    successMessage: "Vented successfully! LIFO means Last-In, First-Out: the last rock added was the first one removed!",
    recap: {
      conceptName: 'Stack Pop: Last-In, First-Out (LIFO)',
      simpleSummary: 'LIFO: The LAST item pushed is the FIRST item popped! You cannot pull items from the bottom without popping the top.',
      pythonCode: [
        '# Current stack: ["Stable Base", "Mid Basalt", "Unstable Core"]',
        '# Pop removes and returns the TOP item',
        'vented = stack.pop()',
        '',
        'print("Removed from top:", vented)  # "Unstable Core"',
        'print("Remaining height:", len(stack))  # 2'
      ],
      jsCode: [
        '// Current stack with 3 items',
        'const vented = stack.pop(); // Removes TOP',
        '',
        'console.log("Removed:", vented); // "Unstable Core"',
        'console.log("Remaining:", stack.length); // 2'
      ],
      explanationLines: [
        'POP removes the most recently added element from the top.',
        'Time Complexity: O(1) constant time — instantaneous because only the top is touched!',
        'No elements need to shift positions, making stacks extremely fast.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: Thermal Peek Inspection',
    concept: 'Stack Peek / Top Inspection',
    subtitle: 'Inspect the top rock temperature without disturbing the stack',
    type: 'peek_inspection',
    targetCount: 3,
    initialStack: [
      { id: 'p1', label: 'Granite', color: '#78716c', value: 15 },
      { id: 'p2', label: 'Pumice', color: '#a8a29e', value: 25 },
      { id: 'p3', label: 'Lava Crystal', color: '#fbbf24', value: 60 }
    ],
    targetTime: 12,
    coinReward: 25,
    novaIntro: {
      mood: 'curious',
      message: "Our volcanic sensor needs to read the energy signature of the top rock without popping it! That's called PEEK. Press PEEK to inspect the top rock safely!"
    },
    hint: "Algorithm Hint: PEEK (or top) lets you look at the top element without removing it from the stack.",
    failureMessage: "Don't pop the rock! We just need to PEEK at its energy reading.",
    successMessage: "Reading acquired! The top rock is glowing at 1200°C. Peek inspected it without changing stack size!",
    recap: {
      conceptName: 'Stack Peek: Inspecting Without Modifying',
      simpleSummary: 'PEEK (or top) reads the value of the top element without deleting it from the stack.',
      pythonCode: [
        '# Peek does NOT remove the element',
        'top_element = stack[-1]  # Python list indexing',
        '',
        'print("Top element is:", top_element)  # "Lava Crystal"',
        'print("Stack size remains:", len(stack))  # Still 3!'
      ],
      jsCode: [
        '// Peek without modifying the array',
        'const topElement = stack[stack.length - 1];',
        '',
        'console.log("Top item:", topElement);',
        'console.log("Stack size:", stack.length); // Still 3!'
      ],
      explanationLines: [
        'PEEK allows checking conditions (e.g. is top safe? what is the value?) before deciding to pop.',
        'Unlike POP, PEEK does not alter the stack in any way.',
        'Time Complexity: O(1) constant time.'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: The Magma Undo Puzzle',
    concept: 'Stack for Undo / History Management',
    subtitle: 'Use POP as an UNDO command to reverse an accidental placement',
    type: 'undo_puzzle',
    targetCount: 3,
    targetWord: ['Basalt', 'Obsidian', 'Diamond'],
    initialStack: [
      { id: 'u1', label: 'Basalt', color: '#ea580c' },
      { id: 'u2', label: 'Obsidian', color: '#312e81' },
      { id: 'u3', label: 'Diamond', color: '#06b6d4' },
      { id: 'u4', label: 'Toxic Slag', color: '#84cc16', isFaulty: true } // Must be undone!
    ],
    targetTime: 14,
    coinReward: 30,
    novaIntro: {
      mood: 'surprised',
      message: "An accidental 'Toxic Slag' was pushed on top of our crystal tower! Text editors and games use STACKS for Ctrl+Z (Undo)! Tap UNDO (POP) to reverse the bad placement and seal the vent!"
    },
    hint: "Algorithm Hint: Every action is pushed to an undo stack. Pressing UNDO simply POPs the most recent action!",
    failureMessage: "Toxic Slag compromised the structure! Tap UNDO to remove the faulty top rock.",
    successMessage: "Faulty rock reverted! Stacks power the 'Undo' button in every software app on Earth!",
    recap: {
      conceptName: 'Undo Buffers: Real-World Stack Application',
      simpleSummary: 'Every time you press Ctrl+Z in software, you are popping the most recent action off an Undo Stack.',
      pythonCode: [
        '# History stack tracks user actions',
        'history = ["Basalt", "Obsidian", "Diamond", "Toxic Slag"]',
        '',
        '# User clicks Undo (Ctrl+Z):',
        'undone_action = history.pop()',
        'print("Undid:", undone_action)  # Removes "Toxic Slag"'
      ],
      jsCode: [
        '// Undo mechanism powered by stack',
        'const history = ["Basalt", "Obsidian", "Diamond", "Toxic Slag"];',
        '',
        '// Undo the latest action',
        'const undone = history.pop();',
        'console.log("Reverted:", undone);'
      ],
      explanationLines: [
        'Because recent actions are at the top, undoing naturally operates in LIFO order.',
        'Redo stacks work similarly by storing popped actions.',
        'Browser back/forward history is also implemented using two stacks!'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: Volcanic Rune Word Reversal',
    concept: 'Reversing Data with a Stack',
    subtitle: 'Push letters N-O-V-A, then pop all to reverse the word',
    type: 'word_reversal',
    wordLetters: ['N', 'O', 'V', 'A'],
    targetReversed: ['A', 'V', 'O', 'N'],
    targetTime: 18,
    coinReward: 40,
    novaIntro: {
      mood: 'excited',
      message: "The Caldera Gate is locked with an ancient cipher! The door displays 'NOVA'. When you push letters into a stack and pop them out, they come out in REVERSE order! Push N, O, V, A, then POP them all to forge 'AVON'!"
    },
    hint: "Algorithm Hint: Push letters in forward order: N -> O -> V -> A. Then pop them all: the first pop will be 'A', reversing the entire string!",
    failureMessage: "Letters were popped in the wrong order! Push all letters first, then pop them all.",
    successMessage: "Caldera Gate Unlocked! Reversing sequences is one of the classic demonstrations of LIFO stacks! You are now a Stack Climber!",
    recap: {
      conceptName: 'Sequence Reversal: The Ultimate LIFO Property',
      simpleSummary: 'Because a stack reverses the order of entry, pushing a sequence and popping it back out automatically reverses it!',
      pythonCode: [
        'word = ["N", "O", "V", "A"]',
        'stack = []',
        '',
        '# Step 1: Push all characters',
        'for char in word:',
        '    stack.append(char)',
        '',
        '# Step 2: Pop all characters into reversed list',
        'reversed_word = []',
        'while len(stack) > 0:',
        '    reversed_word.append(stack.pop())',
        '',
        '# Result: ["A", "V", "O", "N"]'
      ],
      jsCode: [
        'const word = ["N", "O", "V", "A"];',
        'const stack = [];',
        'word.forEach(char => stack.push(char));',
        '',
        'const reversed = [];',
        'while (stack.length > 0) {',
        '    reversed.push(stack.pop());',
        '}',
        '// Result: ["A", "V", "O", "N"]'
      ],
      explanationLines: [
        'First-In becomes Last-Out. Last-In becomes First-Out.',
        'Any sequence pushed and completely popped will be inverted.',
        'This is used in expression evaluation, palindrome verification, and syntax parsing!'
      ]
    }
  }
];
