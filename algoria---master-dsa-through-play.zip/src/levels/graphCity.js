/**
 * Graph City - Level Configurations
 * Extensible configuration file for World 5: Graph City.
 * Teaches Graph Data Structures & Algorithms:
 * 1) Vertices, Edges & Adjacency Lists
 * 2) Breadth-First Search (BFS) ring-by-ring with Queue (FIFO)
 * 3) Depth-First Search (DFS) deep-first with Stack (LIFO) & Backtracking
 * 4) Weighted Graphs & Shortest Path (Dijkstra's Algorithm)
 * 5) Visited Sets, Cycle Avoidance & Hamiltonian Navigation in a Collapsing Grid
 */

export const GRAPH_CITY_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The Cyber Grid',
    concept: 'Nodes, Edges & Adjacency Lists',
    subtitle: 'Navigate connected roads to collect 3 energy cells and reach the extraction node!',
    type: 'graph_explore',
    targetCount: 3,
    targetTime: 25,
    coinReward: 25,
    startNodeId: 'node_A',
    exitNodeId: 'node_F',
    safeZone: {
      initialRadius: 260,
      minRadius: 100,
      shrinkRate: 3.5, // pixels per second
      centerX: 430,
      centerY: 180
    },
    nodes: [
      { id: 'node_A', label: 'Alpha (A)', x: 120, y: 180, isStart: true, hasEnergy: false },
      { id: 'node_B', label: 'Beta (B)', x: 280, y: 80, hasEnergy: true },
      { id: 'node_C', label: 'Gamma (C)', x: 280, y: 280, hasEnergy: true },
      { id: 'node_D', label: 'Delta (D)', x: 500, y: 80, hasEnergy: false },
      { id: 'node_E', label: 'Epsilon (E)', x: 500, y: 280, hasEnergy: true },
      { id: 'node_F', label: 'Extraction (F)', x: 720, y: 180, isExit: true, hasEnergy: false }
    ],
    edges: [
      { from: 'node_A', to: 'node_B' },
      { from: 'node_A', to: 'node_C' },
      { from: 'node_B', to: 'node_D' },
      { from: 'node_B', to: 'node_C' },
      { from: 'node_C', to: 'node_E' },
      { from: 'node_D', to: 'node_F' },
      { from: 'node_E', to: 'node_F' },
      { from: 'node_D', to: 'node_E' }
    ],
    novaIntro: {
      mood: 'excited',
      message: "Welcome to Graph City, Runner! The city is modeled as a GRAPH of vertices (nodes) connected by edges (cyber roads). The Glitch Storm is contracting the safe zone perimeter! Travel along connected edges, gather all 3 glowing Energy Cells, and reach Extraction Node F!"
    },
    hint: "Algorithm Hint: In a graph, you can only travel along connected EDGES. From Node A, check the Adjacency List: you can move to B or C. Plan your route so you hit B, C, and E before exiting at F!",
    failureMessage: "Glitch storm caught you or you attempted to traverse an unconnected gap! Always follow valid connected edges.",
    successMessage: "Flawless route! You navigated the cyber grid via adjacency connections and extracted all energy cells!",
    recap: {
      conceptName: 'Graph Representation: Adjacency Lists',
      simpleSummary: 'A graph G = (V, E) consists of Vertices (nodes) and Edges (connections). An Adjacency List stores each node with a list of its direct neighbors.',
      graphType: 'adjacency_list',
      pythonCode: [
        '# Graph representation using an Adjacency List (Dict)',
        'graph = {',
        "    'A': ['B', 'C'],",
        "    'B': ['A', 'C', 'D'],",
        "    'C': ['A', 'B', 'E'],",
        "    'D': ['B', 'E', 'F'],",
        "    'E': ['C', 'D', 'F'],",
        "    'F': ['D', 'E']",
        '}',
        '',
        'def get_valid_moves(current_node):',
        '    # Lookup takes O(1) time in a hash table',
        '    return graph.get(current_node, [])'
      ],
      jsCode: [
        '// Graph representation using an Adjacency List (Object or Map)',
        'const graph = {',
        "  A: ['B', 'C'],",
        "  B: ['A', 'C', 'D'],",
        "  C: ['A', 'B', 'E'],",
        "  D: ['B', 'E', 'F'],",
        "  E: ['C', 'D', 'F'],",
        "  F: ['D', 'E']",
        '};',
        '',
        'function getValidMoves(currentNode) {',
        '  // Fast O(1) neighbor lookup',
        '  return graph[currentNode] || [];',
        '}'
      ],
      explanationLines: [
        'Vertices (V) represent locations/entities; Edges (E) represent direct routes between them.',
        'An Adjacency List is memory-efficient: space complexity is O(V + E).',
        'Querying neighbors of any vertex is instantaneous using a dictionary or hash map.'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: The Radial Wave (BFS)',
    concept: 'Breadth-First Search: Ring-by-Ring with Queue',
    subtitle: 'Activate nodes in strict BFS order: all 1-hop neighbors first, then 2-hop neighbors!',
    type: 'bfs_traversal',
    targetCount: 6,
    targetTime: 28,
    coinReward: 30,
    startNodeId: 'node_Core',
    safeZone: {
      initialRadius: 280,
      minRadius: 130,
      shrinkRate: 3.0,
      centerX: 430,
      centerY: 180
    },
    nodes: [
      { id: 'node_Core', label: 'Core [L0]', x: 430, y: 180, isStart: true, layer: 0, hasEnergy: false },
      // Ring 1 (1-hop neighbors from Core)
      { id: 'node_R1_A', label: 'North Hub [L1]', x: 430, y: 70, layer: 1, hasEnergy: true },
      { id: 'node_R1_B', label: 'East Hub [L1]', x: 610, y: 180, layer: 1, hasEnergy: true },
      { id: 'node_R1_C', label: 'West Hub [L1]', x: 250, y: 180, layer: 1, hasEnergy: true },
      // Ring 2 (2-hop neighbors)
      { id: 'node_R2_A', label: 'Sector N-East [L2]', x: 610, y: 70, layer: 2, hasEnergy: true },
      { id: 'node_R2_B', label: 'Sector N-West [L2]', x: 250, y: 70, layer: 2, hasEnergy: true },
      { id: 'node_R2_C', label: 'South Relay [L2]', x: 430, y: 300, layer: 2, hasEnergy: true }
    ],
    edges: [
      // Core to Ring 1
      { from: 'node_Core', to: 'node_R1_A' },
      { from: 'node_Core', to: 'node_R1_B' },
      { from: 'node_Core', to: 'node_R1_C' },
      // Ring 1 to Ring 2
      { from: 'node_R1_A', to: 'node_R2_A' },
      { from: 'node_R1_A', to: 'node_R2_B' },
      { from: 'node_R1_B', to: 'node_R2_A' },
      { from: 'node_R1_C', to: 'node_R2_B' },
      { from: 'node_R1_B', to: 'node_R2_C' },
      { from: 'node_R1_C', to: 'node_R2_C' }
    ],
    // BFS expects: Core (L0) -> All L1 nodes (North, East, West) -> All L2 nodes (N-East, N-West, South Relay)
    bfsLayers: {
      0: ['node_Core'],
      1: ['node_R1_A', 'node_R1_B', 'node_R1_C'],
      2: ['node_R2_A', 'node_R2_B', 'node_R2_C']
    },
    novaIntro: {
      mood: 'excited',
      message: "The grid generator needs a concentric harmonic pulse! In BREADTH-FIRST SEARCH (BFS), we expand outward like ripples in water: visit ALL nearest neighbors (Distance 1 / Ring 1) before exploring any further distance (Ring 2). A QUEUE (FIFO) guarantees this order!"
    },
    hint: "Algorithm Hint: BFS = Ring by ring! Visit all Layer 1 nodes (North, East, West) first before stepping onto any Layer 2 node. Our Queue enqueues neighbors and dequeues the oldest first!",
    failureMessage: "BFS Sequence breached! You attempted to explore a distance-2 node before visiting all distance-1 neighbors. BFS requires clearing each level first!",
    successMessage: "Harmonic radial wave complete! Every concentric ring was traversed in pristine BFS queue order!",
    recap: {
      conceptName: 'Breadth-First Search (BFS) & Queue (FIFO)',
      simpleSummary: 'BFS searches a graph level by level, finding the shortest unweighted path. It relies on a QUEUE (First-In, First-Out) to process nodes in the order they were discovered.',
      graphType: 'bfs_queue',
      pythonCode: [
        'from collections import deque',
        '',
        'def bfs(graph, start):',
        '    visited = set([start])',
        '    queue = deque([start])  # FIFO Queue',
        '    traversal_order = []',
        '',
        '    while queue:',
        '        # Dequeue the oldest node from the front',
        '        current = queue.popleft()',
        '        traversal_order.append(current)',
        '',
        '        for neighbor in graph[current]:',
        '            if neighbor not in visited:',
        '                visited.add(neighbor)',
        '                queue.append(neighbor)  # Enqueue at rear',
        '',
        '    return traversal_order'
      ],
      jsCode: [
        'function bfs(graph, start) {',
        '  const visited = new Set([start]);',
        '  const queue = [start]; // FIFO Queue',
        '  const traversalOrder = [];',
        '',
        '  while (queue.length > 0) {',
        '    // Dequeue from front (shift)',
        '    const current = queue.shift();',
        '    traversalOrder.push(current);',
        '',
        '    for (const neighbor of graph[current]) {',
        '      if (!visited.has(neighbor)) {',
        '        visited.add(neighbor);',
        '        queue.push(neighbor); // Enqueue at rear',
        '      }',
        '    }',
        '  }',
        '  return traversalOrder;',
        '}'
      ],
      explanationLines: [
        'BFS explores vertices in order of their distance from the start: 0 hops, then 1 hop, then 2 hops.',
        'A Queue (FIFO) is mandatory: older discovered neighbors are dequeued and processed first.',
        'BFS guarantees finding the shortest path on unweighted graphs in O(V + E) time.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: The Deep Backtrack (DFS)',
    concept: 'Depth-First Search: Go Deep First with Stack',
    subtitle: 'Plunge down an entire branch to the leaf, then backtrack to the most recent fork!',
    type: 'dfs_traversal',
    targetCount: 6,
    targetTime: 30,
    coinReward: 35,
    startNodeId: 'node_Root',
    safeZone: {
      initialRadius: 290,
      minRadius: 140,
      shrinkRate: 2.8,
      centerX: 430,
      centerY: 180
    },
    nodes: [
      { id: 'node_Root', label: 'Origin [Start]', x: 130, y: 180, isStart: true, depth: 0, hasEnergy: false },
      // Branch Alpha (Deep dive path)
      { id: 'node_A1', label: 'Alpha-1 [D1]', x: 300, y: 90, depth: 1, branch: 'A', hasEnergy: true },
      { id: 'node_A2', label: 'Alpha-2 [D2]', x: 480, y: 70, depth: 2, branch: 'A', hasEnergy: true },
      { id: 'node_A3', label: 'Alpha-Terminus [D3]', x: 670, y: 70, depth: 3, branch: 'A', isLeaf: true, hasEnergy: true },
      // Branch Beta
      { id: 'node_B1', label: 'Beta-1 [D1]', x: 300, y: 270, depth: 1, branch: 'B', hasEnergy: true },
      { id: 'node_B2', label: 'Beta-2 [D2]', x: 480, y: 290, depth: 2, branch: 'B', hasEnergy: true },
      { id: 'node_B3', label: 'Beta-Terminus [D3]', x: 670, y: 290, depth: 3, branch: 'B', isLeaf: true, hasEnergy: true }
    ],
    edges: [
      // Branch A pipeline
      { from: 'node_Root', to: 'node_A1' },
      { from: 'node_A1', to: 'node_A2' },
      { from: 'node_A2', to: 'node_A3' },
      // Branch B pipeline
      { from: 'node_Root', to: 'node_B1' },
      { from: 'node_B1', to: 'node_B2' },
      { from: 'node_B2', to: 'node_B3' },
      // Inter-hub backtrack connection
      { from: 'node_A1', to: 'node_B1' }
    ],
    novaIntro: {
      mood: 'curious',
      message: "Now we invert our strategy! In DEPTH-FIRST SEARCH (DFS), we dive as deep as possible down one path until hitting a dead-end (terminus), then BACKTRACK to the nearest fork. DFS is driven by a STACK (LIFO) or recursion. Let's trace the deep conduits!"
    },
    hint: "Algorithm Hint: DFS = Go all the way down! Follow Alpha-1 → Alpha-2 → Alpha-Terminus to the very end before backtracking. Notice how our Stack pushes on exploration and pops when retreating!",
    failureMessage: "DFS sequence broken! You jumped across branches prematurely before exhausting the active depth path.",
    successMessage: "Deep conduit explored and backtracked successfully! DFS recursive mastery unlocked!",
    recap: {
      conceptName: 'Depth-First Search (DFS) & Stack (LIFO)',
      simpleSummary: 'DFS explores as deep as possible along each branch before backtracking. It operates using a STACK (Last-In, First-Out) or call-stack recursion.',
      graphType: 'dfs_stack',
      pythonCode: [
        'def dfs(graph, start):',
        '    visited = set()',
        '    stack = [start]  # LIFO Stack',
        '    traversal_order = []',
        '',
        '    while stack:',
        '        # Pop the most recently added node (deepest)',
        '        current = stack.pop()',
        '',
        '        if current not in visited:',
        '            visited.add(current)',
        '            traversal_order.append(current)',
        '',
        '            # Push unvisited neighbors onto the stack',
        '            for neighbor in reversed(graph[current]):',
        '                if neighbor not in visited:',
        '                    stack.append(neighbor)',
        '',
        '    return traversal_order'
      ],
      jsCode: [
        'function dfs(graph, start) {',
        '  const visited = new Set();',
        '  const stack = [start]; // LIFO Stack',
        '  const traversalOrder = [];',
        '',
        '  while (stack.length > 0) {',
        '    // Pop the deepest node (top of stack)',
        '    const current = stack.pop();',
        '',
        '    if (!visited.has(current)) {',
        '      visited.add(current);',
        '      traversalOrder.push(current);',
        '',
        '      for (const neighbor of graph[current].slice().reverse()) {',
        '        if (!visited.has(neighbor)) {',
        '          stack.push(neighbor);',
        '        }',
        '      }',
        '    }',
        '  }',
        '  return traversalOrder;',
        '}'
      ],
      explanationLines: [
        'DFS pursues every path to its maximum depth (leaf/terminus) before retreating.',
        'A Stack (LIFO) or recursive call stack holds the trail of breadcrumbs for backtracking.',
        'DFS is ideal for maze solving, cycle detection, topological sorting, and game-tree decision making.'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: The Vector Path (Dijkstra)',
    concept: 'Weighted Graphs & Dijkstra Shortest Path',
    subtitle: 'Find the path with minimum total edge weight to reach the Safe Haven Bunker in time!',
    type: 'dijkstra_shortest_path',
    targetCount: 1, // Safe haven reached via shortest path
    targetTime: 25,
    coinReward: 40,
    startNodeId: 'node_Entry',
    targetNodeId: 'node_Bunker',
    safeZone: {
      initialRadius: 270,
      minRadius: 80,
      shrinkRate: 3.6,
      centerX: 650,
      centerY: 180
    },
    nodes: [
      { id: 'node_Entry', label: 'Entry Gate', x: 120, y: 180, isStart: true, hasEnergy: false },
      { id: 'node_Bridge', label: 'Neon Bridge', x: 290, y: 80, hasEnergy: true },
      { id: 'node_Tunnel', label: 'Mag-Tunnel', x: 290, y: 280, hasEnergy: true },
      { id: 'node_Relay', label: 'Power Relay', x: 470, y: 80, hasEnergy: true },
      { id: 'node_Plaza', label: 'Central Plaza', x: 470, y: 280, hasEnergy: true },
      { id: 'node_Bunker', label: 'Safe Bunker', x: 700, y: 180, isExit: true, hasEnergy: false }
    ],
    // Weighted edges: player must find the cheapest total path!
    // Path 1: Entry -> Bridge (4) -> Relay (3) -> Bunker (5) = 12
    // Path 2: Entry -> Tunnel (2) -> Plaza (4) -> Bunker (3) = 9  <-- SHORTEST PATH!
    // Path 3: Entry -> Bridge (4) -> Plaza (7) -> Bunker (3) = 14
    // Path 4: Entry -> Tunnel (2) -> Relay (8) -> Bunker (5) = 15
    edges: [
      { from: 'node_Entry', to: 'node_Bridge', weight: 4 },
      { from: 'node_Entry', to: 'node_Tunnel', weight: 2 },
      { from: 'node_Bridge', to: 'node_Relay', weight: 3 },
      { from: 'node_Tunnel', to: 'node_Plaza', weight: 4 },
      { from: 'node_Bridge', to: 'node_Plaza', weight: 7 },
      { from: 'node_Tunnel', to: 'node_Relay', weight: 8 },
      { from: 'node_Relay', to: 'node_Bunker', weight: 5 },
      { from: 'node_Plaza', to: 'node_Bunker', weight: 3 }
    ],
    optimalCost: 9,
    optimalPath: ['node_Entry', 'node_Tunnel', 'node_Plaza', 'node_Bunker'],
    novaIntro: {
      mood: 'serious',
      message: "Emergency! The Glitch Storm is contracting rapidly directly onto the Safe Bunker! Each road has an energy transit cost (weight). The shortest unweighted path isn't necessarily the fastest! We need DIJKSTRA'S ALGORITHM to calculate the minimum-weight path: Total Cost 9 vs 12 vs 15!"
    },
    hint: "Algorithm Hint: Look at the road weights: Entry → Mag-Tunnel is only 2 (vs 4 for Bridge). Then Tunnel → Central Plaza is 4, and Plaza → Safe Bunker is 3. Total cost = 2 + 4 + 3 = 9! Compare all paths!",
    failureMessage: "Suboptimal route took too much energy delay, and the glitch storm engulfed the corridor! Choose the path with minimal accumulated edge weights.",
    successMessage: "Perfect calculation! You navigated the absolute shortest weighted route (Cost = 9) safely into the bunker!",
    recap: {
      conceptName: "Dijkstra's Shortest Path & Priority Queue",
      simpleSummary: "Dijkstra's Algorithm finds the shortest path between nodes in a weighted graph by greedily visiting the lowest-cost unvisited vertex using a Min-Heap (Priority Queue).",
      graphType: 'dijkstra',
      pythonCode: [
        'import heapq',
        '',
        'def dijkstra(graph, start, target):',
        '    # distances dict initialized to infinity',
        '    distances = {node: float("inf") for node in graph}',
        '    distances[start] = 0',
        '    # Priority queue stores tuples: (distance, node)',
        '    pq = [(0, start)]',
        '',
        '    while pq:',
        '        current_dist, current_node = heapq.heappop(pq)',
        '',
        '        if current_node == target:',
        '            return current_dist  # Found optimal path!',
        '',
        '        if current_dist > distances[current_node]:',
        '            continue',
        '',
        '        for neighbor, weight in graph[current_node].items():',
        '            distance = current_dist + weight',
        '            if distance < distances[neighbor]:',
        '                distances[neighbor] = distance',
        '                heapq.heappush(pq, (distance, neighbor))',
        '',
        '    return distances[target]'
      ],
      jsCode: [
        '// Dijkstra Shortest Path implementation',
        'function dijkstra(graph, start, target) {',
        '  const distances = {};',
        '  for (const node in graph) distances[node] = Infinity;',
        '  distances[start] = 0;',
        '  const pq = [{ node: start, dist: 0 }];',
        '',
        '  while (pq.length > 0) {',
        '    pq.sort((a, b) => a.dist - b.dist); // Min-heap behavior',
        '    const { node: curr, dist: d } = pq.shift();',
        '',
        '    if (curr === target) return d;',
        '    if (d > distances[curr]) continue;',
        '',
        '    for (const [neighbor, weight] of Object.entries(graph[curr])) {',
        '      const newDist = d + weight;',
        '      if (newDist < distances[neighbor]) {',
        '        distances[neighbor] = newDist;',
        '        pq.push({ node: neighbor, dist: newDist });',
        '      }',
        '    }',
        '  }',
        '  return distances[target];',
        '}'
      ],
      explanationLines: [
        'Edge weights represent distances, transit times, or bandwidth costs.',
        'Dijkstra operates greedily: always relaxing edges from the currently closest vertex.',
        'With a binary heap, Dijkstra runs in O((V + E) log V) time, powering modern GPS navigation!'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: The Collapsing Grid',
    concept: 'Visited Sets & Hamiltonian Cycle Avoidance',
    subtitle: 'Every road collapsed once exited! Gather all 4 energy cells without revisiting any node!',
    type: 'avoid_visited_nodes',
    targetCount: 4,
    targetTime: 32,
    coinReward: 50,
    startNodeId: 'node_N1',
    exitNodeId: 'node_Safe',
    safeZone: {
      initialRadius: 280,
      minRadius: 100,
      shrinkRate: 3.2,
      centerX: 430,
      centerY: 180
    },
    nodes: [
      { id: 'node_N1', label: 'Pod-1 [Start]', x: 140, y: 100, isStart: true, hasEnergy: false },
      { id: 'node_N2', label: 'Cell Station Alpha', x: 340, y: 90, hasEnergy: true },
      { id: 'node_N3', label: 'Cell Station Beta', x: 540, y: 90, hasEnergy: true },
      { id: 'node_N4', label: 'Cell Station Gamma', x: 540, y: 270, hasEnergy: true },
      { id: 'node_N5', label: 'Cell Station Delta', x: 340, y: 270, hasEnergy: true },
      { id: 'node_Safe', label: 'Central Citadel', x: 710, y: 180, isExit: true, hasEnergy: false }
    ],
    // Connected cycle and diagonal bridges
    edges: [
      { from: 'node_N1', to: 'node_N2' },
      { from: 'node_N1', to: 'node_N5' },
      { from: 'node_N2', to: 'node_N3' },
      { from: 'node_N2', to: 'node_N5' },
      { from: 'node_N3', to: 'node_N4' },
      { from: 'node_N3', to: 'node_Safe' },
      { from: 'node_N4', to: 'node_N5' },
      { from: 'node_N4', to: 'node_Safe' }
    ],
    novaIntro: {
      mood: 'serious',
      message: "CRITICAL SECTOR COLLAPSE! The glitch storm destabilizes any node you leave: once you travel through a node, its cyber platform vaporizes into the void! You must maintain a STRICT VISITED SET. Collect all 4 energy cells and reach the Central Citadel without ever hitting a collapsed node!"
    },
    hint: "Algorithm Hint: Think like a Hamiltonian Path: N1 → N2 → N5 is a trap because you cut off N4! Instead, loop cleanly: Start N1 → N5 (Cell 1) → N4 (Cell 2) → N3 (Cell 3) ... or N1 → N2 → N3 → N4 → Safe! Plan your visited set so you never get boxed in!",
    failureMessage: "Dead-end collision! You either tried to step onto an already-collapsed node or got trapped in a cycle with no unvisited edges left.",
    successMessage: "INCREDIBLE! You navigated the collapsing grid flawlessly, collected all energy cells, and secured safe harbor in the Central Citadel! Graph Master badge earned!",
    recap: {
      conceptName: 'Visited Sets, Cycle Prevention & Hamiltonian Paths',
      simpleSummary: 'In graph algorithms, tracking `visited = set()` is fundamental to prevent infinite loops, cycle traps, and redundant computations. A path visiting every vertex exactly once is a Hamiltonian Path.',
      graphType: 'visited_sets',
      pythonCode: [
        '# Cycle prevention & visited set tracking',
        'def traverse_without_cycles(graph, start, target):',
        '    visited = set([start])',
        '    path = [start]',
        '',
        '    def backtrack(current):',
        '        if current == target and len(visited) == len(graph):',
        '            return True  # Found Hamiltonian Path!',
        '',
        '        for neighbor in graph[current]:',
        '            # STRICT RULE: Never step on a visited node',
        '            if neighbor not in visited:',
        '                visited.add(neighbor)',
        '                path.append(neighbor)',
        '',
        '                if backtrack(neighbor):',
        '                    return True',
        '',
        '                # Backtrack if path leads to dead-end',
        '                visited.remove(neighbor)',
        '                path.pop()',
        '',
        '        return False',
        '',
        '    backtrack(start)',
        '    return path'
      ],
      jsCode: [
        '// Visited Sets & Hamiltonian Path verification',
        'function traverseWithoutCycles(graph, start, target) {',
        '  const visited = new Set([start]);',
        '  const path = [start];',
        '',
        '  function backtrack(current) {',
        '    if (current === target && visited.size === Object.keys(graph).length) {',
        '      return true; // Visited all vertices exactly once!',
        '    }',
        '',
        '    for (const neighbor of graph[current]) {',
        '      if (!visited.has(neighbor)) {',
        '        visited.add(neighbor);',
        '        path.push(neighbor);',
        '',
        '        if (backtrack(neighbor)) return true;',
        '',
        '        // Backtrack',
        '        visited.delete(neighbor);',
        '        path.pop();',
        '      }',
        '    }',
        '    return false;',
        '  }',
        '',
        '  backtrack(start);',
        '  return path;',
        '}'
      ],
      explanationLines: [
        'Without a `visited` set, graph traversals can fall into infinite cycles or recalculate subproblems.',
        'A path that visits every vertex in a graph exactly once is known as a Hamiltonian Path (NP-Complete in general).',
        'Visited set tracking is the backbone of Cycle Detection, Topological Sorting, and DFS/BFS algorithms.'
      ]
    }
  }
];
