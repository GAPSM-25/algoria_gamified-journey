/**
 * Queue River - Level Configurations
 * Extensible configuration file for World 3: Queue River.
 * Teaches FIFO (First-In, First-Out) operations: enqueue, dequeue, front, rear, and Priority Queue.
 */

export const QUEUE_RIVER_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The Snake Queue',
    concept: 'Queue Enqueue & Dequeue (FIFO Fundamentals)',
    subtitle: 'The snake is a moving Queue: eating enqueues at head, moving dequeues from tail!',
    type: 'snake_queue',
    targetCount: 5,
    gridSize: { cols: 18, rows: 10 },
    initialLength: 3,
    speedMs: 170,
    hasObstacles: false,
    targetTime: 20,
    coinReward: 20,
    novaIntro: {
      mood: 'excited',
      message: "Welcome to Queue River! Did you know a classic Snake is actually a FIFO QUEUE? As the snake moves, a new head position is ENQUEUED at the rear, and the old tail position is DEQUEUED from the front! When you eat a crystal, it enqueues WITHOUT dequeueing, growing the snake! Eat 5 crystals!"
    },
    hint: "Algorithm Hint: Watch the FRONT and REAR labels! Every step forward pops (dequeues) the oldest tail segment and pushes (enqueues) the new head segment. Eat 5 glowing data crystals to expand the queue!",
    failureMessage: "Collision detected! The snake collided with the boundary. Steer carefully and maintain the queue flow!",
    successMessage: "Splendid slithering! You saw FIFO queue mechanics in motion: elements entered at the head and departed from the tail!",
    recap: {
      conceptName: 'Queue: First-In, First-Out (FIFO)',
      simpleSummary: 'A QUEUE is a linear data structure that operates on FIFO: First-In, First-Out. The first element added is the first one removed.',
      pythonCode: [
        'from collections import deque',
        '',
        '# Snake body maintained as a FIFO queue',
        'snake_queue = deque([(5, 5), (5, 6), (5, 7)])',
        '',
        '# Move forward: enqueue new head at rear',
        'snake_queue.append(new_head)',
        '',
        '# If not eating crystal: dequeue oldest tail from front',
        'if not eating_crystal:',
        '    old_tail = snake_queue.popleft()  # FIFO removal!'
      ],
      jsCode: [
        '// Snake body implemented as a Queue array',
        'const snakeQueue = [[5, 5], [5, 6], [5, 7]];',
        '',
        '// Enqueue new head position to rear',
        'snakeQueue.push(newHead);',
        '',
        '// If no food eaten: dequeue oldest segment from front',
        'if (!eatingFood) {',
        '    const oldTail = snakeQueue.shift(); // FIFO removal!',
        '}'
      ],
      explanationLines: [
        'Enqueue (append/push): Adds a new element to the REAR of the queue.',
        'Dequeue (popleft/shift): Removes the oldest element from the FRONT of the queue.',
        'Unlike Stacks (LIFO), Queues preserve the original chronological arrival order!'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: Memory Rapids',
    concept: 'Queue Dynamic Growth & Flow',
    subtitle: 'Maneuver around river basalt rocks to grow the snake queue to 8 segments!',
    type: 'snake_queue',
    targetCount: 8,
    gridSize: { cols: 18, rows: 10 },
    initialLength: 3,
    speedMs: 155,
    hasObstacles: true,
    obstacleCount: 4,
    targetTime: 25,
    coinReward: 25,
    novaIntro: {
      mood: 'serious',
      message: "River basalt rocks have surfaced! Steer through the currents. As the queue grows to 8 elements, notice how the snake body maintains strict FIFO memory order from head to tail. Eat 8 crystals without hitting rocks or your own tail!"
    },
    hint: "Algorithm Hint: As the queue length increases, your tail takes longer to catch up because it represents positions from many iterations ago. Plan turns in advance!",
    failureMessage: "Crashed into a basalt boulder or tail segment! Keep the FIFO stream clear and try again.",
    successMessage: "Masterful navigation! The queue successfully held 8 synchronized spatial coordinates in FIFO order!",
    recap: {
      conceptName: 'Queue Sizing: Front & Rear Pointers',
      simpleSummary: 'In memory, a Queue tracks two pointers: FRONT (where items leave) and REAR (where items enter).',
      pythonCode: [
        '# Tracking Front and Rear in a Queue',
        'class SnakeQueue:',
        '    def __init__(self):',
        '        self.items = []',
        '',
        '    def enqueue(self, pos):',
        '        self.items.append(pos)  # Added to REAR',
        '',
        '    def dequeue(self):',
        '        return self.items.pop(0)  # Removed from FRONT',
        '',
        '    def peek_front(self):',
        '        return self.items[0]  # Oldest tail segment'
      ],
      jsCode: [
        'class SnakeQueue {',
        '    constructor() {',
        '        this.items = [];',
        '    }',
        '    enqueue(pos) {',
        '        this.items.push(pos); // Added to REAR',
        '    }',
        '    dequeue() {',
        '        return this.items.shift(); // Removed from FRONT',
        '    }',
        '    peekFront() {',
        '        return this.items[0]; // Oldest tail',
        '    }',
        '}'
      ],
      explanationLines: [
        'The FRONT pointer always references the oldest active item waiting in line.',
        'The REAR pointer references where new arrivals are enqueued.',
        'Queues are vital for buffering printer jobs, network packets, and CPU scheduling.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: Ferry Marina',
    concept: 'FIFO River Docking (Front Serving)',
    subtitle: 'Boats dock in a line. Tap the FRONT boat to dispatch it in strict FIFO order!',
    type: 'fifo_boats',
    targetCount: 6,
    targetTime: 18,
    coinReward: 30,
    boatStream: [
      { id: 'b1', name: 'Alpha Ferry', ticketNumber: 1, cargo: 'Crystals', color: 0x06b6d4 },
      { id: 'b2', name: 'Beta Cruiser', ticketNumber: 2, cargo: 'Data Core', color: 0xa855f7 },
      { id: 'b3', name: 'Gamma Barge', ticketNumber: 3, cargo: 'Solar Cells', color: 0x10b981 },
      { id: 'b4', name: 'Delta Skiff', ticketNumber: 4, cargo: 'Quantum RAM', color: 0xf59e0b },
      { id: 'b5', name: 'Epsilon Tug', ticketNumber: 5, cargo: 'Photon Wire', color: 0xec4899 },
      { id: 'b6', name: 'Zeta Yacht', ticketNumber: 6, cargo: 'Cyber Emerald', color: 0x3b82f6 }
    ],
    novaIntro: {
      mood: 'happy',
      message: "Here at the Marina docks, boats line up in the river queue! The rule of FIFO is strict: the boat that arrived FIRST (at the FRONT of the queue) MUST be served first! Tap the FRONT boat to clear its slip and let the line advance!"
    },
    hint: "Algorithm Hint: Look for Ticket #1 at the FRONT of the river line. Tap it (or click Dispatch Front Boat) to dequeue it! Tapping boats further back in the line violates FIFO order.",
    failureMessage: "Queue violation! You tapped a boat waiting in line. In a FIFO queue, only the FRONT item can be processed!",
    successMessage: "All 6 boats dispatched in pristine FIFO order! The line moved forward seamlessly after every dequeue.",
    recap: {
      conceptName: 'FIFO Service Order: No Cutting the Line',
      simpleSummary: 'In real-world services and operating systems, Queues guarantee fairness. First to arrive is first to be served.',
      pythonCode: [
        '# River Marina Queue',
        'boat_queue = ["Alpha Ferry #1", "Beta Cruiser #2", "Gamma Barge #3"]',
        '',
        '# Service must always dequeue from the FRONT',
        'while boat_queue:',
        '    served_boat = boat_queue.pop(0)  # FIFO dispatch',
        '    print(f"Dispatched: {served_boat}")'
      ],
      jsCode: [
        'const boatQueue = ["Alpha Ferry #1", "Beta Cruiser #2", "Gamma Barge #3"];',
        '',
        '// Process queue in FIFO order',
        'while (boatQueue.length > 0) {',
        '    const servedBoat = boatQueue.shift(); // Dequeue front',
        '    console.log(`Dispatched: ${servedBoat}`);',
        '}'
      ],
      explanationLines: [
        'A FIFO queue guarantees fair service order: no element can bypass earlier arrivals.',
        'When the front item is dequeued, all subsequent items advance toward the front.',
        'Time Complexity: With linked list queues, enqueue and dequeue are both O(1) operations!'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: High-Tide Rapid Line',
    concept: 'Dynamic Queue Arrivals & Line Throughput',
    subtitle: 'New boats arrive continuously at the REAR! Keep the harbor clear by serving the FRONT.',
    type: 'fifo_boats',
    targetCount: 8,
    targetTime: 22,
    coinReward: 35,
    boatStream: [
      { id: 'b1', name: 'Neon Osprey', ticketNumber: 1, cargo: 'Flux Capacitors', color: 0x38bdf8 },
      { id: 'b2', name: 'Tide Strider', ticketNumber: 2, cargo: 'Laser Diodes', color: 0xc084fc },
      { id: 'b3', name: 'River Ghost', ticketNumber: 3, cargo: 'Cryo Fuel', color: 0x34d399 },
      { id: 'b4', name: 'Vortex Sailer', ticketNumber: 4, cargo: 'Plasma Torches', color: 0xfbbf24 },
      { id: 'b5', name: 'Giga Raft', ticketNumber: 5, cargo: 'Nanobots', color: 0xf43f5e },
      { id: 'b6', name: 'Cobalt Sloop', ticketNumber: 6, cargo: 'Graphene Mesh', color: 0x60a5fa },
      { id: 'b7', name: 'Solar Skiff', ticketNumber: 7, cargo: 'Lithium Crystals', color: 0xa3e635 },
      { id: 'b8', name: 'Aurora Ferry', ticketNumber: 8, cargo: 'Starlight Core', color: 0x2dd4bf }
    ],
    novaIntro: {
      mood: 'surprised',
      message: "High tide alert! Boats are arriving one after another at the REAR of the queue! The harbor capacity is strictly limited. Keep dequeuing from the FRONT to prevent dock overflows!"
    },
    hint: "Algorithm Hint: Stay focused on the FRONT indicator. Whenever you dispatch the front boat, new boats can safely dock at the REAR without overflowing the river buffer!",
    failureMessage: "Line congestion error! You tried to dispatch out of sequence. Stick to the FRONT boat at all times.",
    successMessage: "Harbor grid protected! 8 dynamic arrivals processed with zero bottlenecks through pure FIFO pipeline efficiency!",
    recap: {
      conceptName: 'Queue Buffering & Throughput',
      simpleSummary: 'Queues act as dynamic shock absorbers between producers (arrivals at Rear) and consumers (dispatches at Front).',
      pythonCode: [
        'import queue',
        '',
        '# Thread-safe buffer queue',
        'harbor_buffer = queue.Queue(maxsize=10)',
        '',
        '# Producer: Enqueue at REAR',
        'harbor_buffer.put("Neon Osprey #1")',
        '',
        '# Consumer: Dequeue from FRONT',
        'dispatched = harbor_buffer.get()  # Blocks if empty, preserves FIFO'
      ],
      jsCode: [
        '// Asynchronous job queue pipeline',
        'class JobQueue {',
        '    constructor() { this.queue = []; }',
        '    enqueue(job) { this.queue.push(job); } // Producer',
        '    dequeue() { return this.queue.shift(); } // Consumer',
        '}'
      ],
      explanationLines: [
        'Producers add items to the REAR while consumers process from the FRONT.',
        'This decouples workloads: fast arrivals won’t crash slow processors.',
        'Used in streaming video buffers, web servers, and game packet handling.'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: VIP Priority Rapids',
    concept: 'Priority Queue (VIP Overrides)',
    subtitle: 'VIP vessels take priority! Dispatch highest priority boats before standard ferries.',
    type: 'priority_queue',
    targetCount: 8,
    targetTime: 25,
    coinReward: 50,
    boatStream: [
      { id: 'b1', name: 'Standard Sloop', ticketNumber: 1, cargo: 'Iron Ore', color: 0x64748b, priority: 3 },
      { id: 'b2', name: 'VIP Ambulance 1', ticketNumber: 2, cargo: 'Emergency Core', color: 0xf59e0b, priority: 1, isVip: true },
      { id: 'b3', name: 'Express Mail', ticketNumber: 3, cargo: 'Encrypted Mail', color: 0xa855f7, priority: 2 },
      { id: 'b4', name: 'VIP Rescue 2', ticketNumber: 4, cargo: 'Medical Nanites', color: 0xef4444, priority: 1, isVip: true },
      { id: 'b5', name: 'Standard Tug', ticketNumber: 5, cargo: 'Lumber', color: 0x475569, priority: 3 },
      { id: 'b6', name: 'Express Freight', ticketNumber: 6, cargo: 'Urgent Microchips', color: 0x8b5cf6, priority: 2 },
      { id: 'b7', name: 'VIP Flagship 3', ticketNumber: 7, cargo: 'Diplomatic Seal', color: 0xfacc15, priority: 1, isVip: true },
      { id: 'b8', name: 'Standard Barge', ticketNumber: 8, cargo: 'River Silt', color: 0x334155, priority: 3 }
    ],
    novaIntro: {
      mood: 'serious',
      message: "Urgent harbor alert! Emergency VIP vessels with Priority 1 [P1] are in the river! In a PRIORITY QUEUE, elements are served based on PRIORITY, not just arrival time! Highest priority (Priority 1) MUST be served first. If priorities are equal, follow FIFO arrival order!"
    },
    hint: "Algorithm Hint: Check priority badges! [P1 VIP Gold] > [P2 Express Purple] > [P3 Standard Slate]. Always tap the vessel with the highest priority available. If two have P1, pick the one that arrived earlier!",
    failureMessage: "Priority violation! A VIP vessel with Priority 1 was waiting, but you served a lower priority boat first!",
    successMessage: "Sensational harbor mastership! You've mastered both FIFO queues and Priority Queues! QUEUE CAPTAIN BADGE AWARDED!",
    recap: {
      conceptName: 'Priority Queue: Heaps & Priority Scheduling',
      simpleSummary: 'A Priority Queue serves elements based on importance rather than purely arrival time. High priority jumps ahead of lower priority.',
      pythonCode: [
        'import heapq',
        '',
        '# Priority queue using min-heap (lower number = higher priority)',
        'pq = []',
        '',
        '# heapq stores tuples: (priority, arrival_ticket, boat_name)',
        'heapq.heappush(pq, (3, 1, "Standard Sloop"))',
        'heapq.heappush(pq, (1, 2, "VIP Ambulance"))  # Priority 1 jumps ahead!',
        '',
        '# heappop() always extracts the highest priority element first!',
        'vip_served = heapq.heappop(pq)  # Returns (1, 2, "VIP Ambulance")'
      ],
      jsCode: [
        '// Priority Queue Comparator Order',
        'class PriorityQueue {',
        '    constructor() { this.items = []; }',
        '    enqueue(boat, priority) {',
        '        this.items.push({ boat, priority });',
        '        this.items.sort((a, b) => a.priority - b.priority); // P1 first',
        '    }',
        '    dequeue() {',
        '        return this.items.shift(); // Dequeue highest priority',
        '    }',
        '}'
      ],
      explanationLines: [
        'Priority Queues override strict arrival order to ensure critical tasks are handled first.',
        'Typically implemented with Binary Heaps for lightning-fast O(log N) inserts and removals.',
        'Powers Dijkstra\'s algorithm, hospital triage systems, and CPU interrupt scheduling.'
      ]
    }
  }
];
