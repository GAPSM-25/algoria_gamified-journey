/**
 * Array Arena - Level Configurations
 * Extensible configuration file for World 6: Array Arena.
 * Teaches fundamental Array Data Structures & Core Algorithms:
 * 1) 0-Indexed Memory Slots & O(1) Random Access Arithmetic
 * 2) Bubble Sort & Pairwise Comparison Sorting (O(N^2))
 * 3) Corridor Race: Linear Search O(N) vs Binary Search O(log N)
 * 4) Binary Search Range Halving: Low, Mid, and High Pointer Convergence
 * 5) Two-Pointers Technique & In-Place Array Reversal (O(N) time, O(1) space)
 */

export const ARRAY_ARENA_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The Zero-Indexed Colosseum',
    concept: '0-Based Indexing & O(1) Memory Addressing',
    subtitle: 'Extract target data orbs from contiguous memory slots using zero-indexed math!',
    type: 'array_index_lookup',
    targetCount: 4,
    targetTime: 25,
    coinReward: 30,
    arrayData: [
      { index: 0, value: 42, label: '42', memoryAddr: '0x1000' },
      { index: 1, value: 17, label: '17', memoryAddr: '0x1004' },
      { index: 2, value: 89, label: '89', memoryAddr: '0x1008' },
      { index: 3, value: 5,  label: '5',  memoryAddr: '0x100C' },
      { index: 4, value: 63, label: '63', memoryAddr: '0x1010' },
      { index: 5, value: 99, label: '99', memoryAddr: '0x1014' }
    ],
    // The sequence of 4 index queries Nova presents to the player
    queries: [
      {
        prompt: 'Retrieve the first element: arr[0]',
        targetIndex: 0,
        expectedValue: 42,
        explanation: 'In 0-indexed arrays, the first slot is at offset 0 (Address: base + 0 * size).'
      },
      {
        prompt: 'Retrieve the fourth slot: arr[3]',
        targetIndex: 3,
        expectedValue: 5,
        explanation: 'Index 3 corresponds to the 4th element (0, 1, 2, 3).'
      },
      {
        prompt: 'Retrieve the last element: arr[arr.length - 1]',
        targetIndex: 5,
        expectedValue: 99,
        explanation: 'Length is 6, so the final valid index is 6 - 1 = 5.'
      },
      {
        prompt: 'Python Negative Index: Retrieve arr[-2] (second from last)',
        targetIndex: 4,
        expectedValue: 63,
        explanation: 'Negative index -1 is the last item (99), so -2 is the second from last (63).'
      }
    ],
    // Steps for "Watch Nova do it" replay
    novaReplaySteps: [
      { action: 'select', index: 0, speech: 'Looking for arr[0]. The first memory cell is at index 0!' },
      { action: 'select', index: 3, speech: 'Now arr[3]. Counting 0, 1, 2, 3 -> value is 5!' },
      { action: 'select', index: 5, speech: 'Last slot is length - 1, which is index 5 -> 99!' },
      { action: 'select', index: 4, speech: 'arr[-2] wraps backwards from the end to index 4 -> 63!' }
    ],
    novaIntro: {
      mood: 'excited',
      message: "Welcome to the grand Array Arena, Gladiator! Arrays are contiguous blocks of memory where each element is accessed via a ZERO-BASED INDEX in O(1) instantaneous time. Answer my 4 memory queries by tapping the correct slot!"
    },
    hint: "Algorithm Hint: Remember that computer memory is 0-indexed! The 1st item is at arr[0], 2nd is arr[1], and the last item is always at arr[len - 1]. In Python, arr[-1] is the last item!",
    failureMessage: "Off-by-one error or boundary breach! In 0-indexed systems, always count starting from 0, not 1.",
    successMessage: "Flawless memory addressing! You mastered zero-indexing and O(1) random access!",
    recap: {
      conceptName: 'Array Memory Allocation & 0-Based Indexing',
      simpleSummary: 'An array stores elements consecutively in RAM. Given index i, the hardware calculates memory address: base_address + (i * element_size) in O(1) time.',
      arrayType: 'index_lookup',
      pythonCode: [
        '# Array creation and O(1) index access',
        'scores = [42, 17, 89, 5, 63, 99]',
        '',
        'first_element = scores[0]         # 42 (O(1) time)',
        'fourth_element = scores[3]        # 5',
        'last_element = scores[-1]         # 99 (Python negative index)',
        'second_last = scores[-2]          # 63',
        '',
        '# Array length & bounds',
        'n = len(scores)                   # 6',
        'safe_last = scores[n - 1]         # 99'
      ],
      jsCode: [
        '// Array creation and O(1) index access',
        'const scores = [42, 17, 89, 5, 63, 99];',
        '',
        'const first = scores[0];          // 42 (O(1) time)',
        'const fourth = scores[3];         // 5',
        'const last = scores[scores.length - 1]; // 99',
        'const atMethod = scores.at(-1);   // 99 (Modern JS)',
        '',
        '// Direct memory address formula:',
        '// memory_address = base_addr + (index * element_bytes)'
      ],
      explanationLines: [
        'Arrays are contiguous: all elements sit side-by-side in computer memory.',
        'Zero-indexing represents the offset distance from the first memory byte.',
        'Index lookup takes O(1) constant time, making arrays the fastest structure for random reads.'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: The Bubble Sort Arena',
    concept: 'Bubble Sort & Pairwise Swap Comparisons',
    subtitle: 'Drag orbs or trigger bubble sort to compare adjacent pairs and bubble largest values to the end!',
    type: 'bubble_sort',
    targetCount: 5, // Array length sorted
    targetTime: 30,
    coinReward: 35,
    initialArray: [64, 34, 25, 12, 22],
    sortedArray: [12, 22, 25, 34, 64],
    novaReplaySteps: [
      { action: 'compare_swap', i: 0, j: 1, speech: 'Compare 64 and 34: 64 > 34, so swap!' },
      { action: 'compare_swap', i: 1, j: 2, speech: 'Compare 64 and 25: 64 > 25, so swap!' },
      { action: 'compare_swap', i: 2, j: 3, speech: 'Compare 64 and 12: 64 > 12, so swap!' },
      { action: 'compare_swap', i: 3, j: 4, speech: 'Compare 64 and 22: 64 > 22, so swap! 64 is now locked in place!' },
      { action: 'finish_sort', speech: 'Subsequent passes bubble 34, 25, and 22. Array is fully sorted!' }
    ],
    novaIntro: {
      mood: 'curious',
      message: "Rogue sorting demons scrambled our numerical orbs! In BUBBLE SORT, we compare adjacent pairs: if arr[j] > arr[j+1], we swap them. Watch how the largest values 'bubble up' to the right end like air bubbles in water! You can drag orbs or tap Step / Auto-Sort!"
    },
    hint: "Algorithm Hint: Compare pairs from left to right. When the left orb is bigger than the right orb, swap them! After Pass 1, 64 is guaranteed at the end. After Pass 2, 34 is in place!",
    failureMessage: "Unsorted array submitted! Ensure all values are in strictly ascending order: [12, 22, 25, 34, 64].",
    successMessage: "Bubble sort complete! Every adjacent inversion was resolved and the array is perfectly sorted in O(N^2) time!",
    recap: {
      conceptName: 'Bubble Sort: Pairwise Comparison Sorting',
      simpleSummary: 'Bubble Sort repeatedly steps through the array, compares adjacent elements, and swaps them if they are in the wrong order. Passes continue until no swaps are needed.',
      arrayType: 'bubble_sort',
      pythonCode: [
        'def bubble_sort(arr):',
        '    n = len(arr)',
        '    for i in range(n):',
        '        swapped = False',
        '        # Last i elements are already in place',
        '        for j in range(0, n - i - 1):',
        '            if arr[j] > arr[j + 1]:',
        '                # Swap adjacent elements',
        '                arr[j], arr[j + 1] = arr[j + 1], arr[j]',
        '                swapped = True',
        '        if not swapped:',
        '            break  # Optimized: early stop if sorted',
        '    return arr'
      ],
      jsCode: [
        'function bubbleSort(arr) {',
        '  const n = arr.length;',
        '  for (let i = 0; i < n; i++) {',
        '    let swapped = false;',
        '    for (let j = 0; j < n - i - 1; j++) {',
        '      if (arr[j] > arr[j + 1]) {',
        '        // Swap adjacent elements',
        '        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];',
        '        swapped = true;',
        '      }',
        '    }',
        '    if (!swapped) break; // Optimized early exit',
        '  }',
        '  return arr;',
        '}'
      ],
      explanationLines: [
        'Worst & Average time complexity is O(N^2); Best case on sorted data is O(N).',
        'Space complexity is O(1) (In-place sort: requires no extra memory).',
        'Bubble sort is stable: elements with equal values maintain their original relative order.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: The Corridor Race: Linear vs. Binary',
    concept: 'Time Complexity Showdown: O(N) vs. O(log N)',
    subtitle: 'Race against a Rogue Bot: Linear Search checks 1-by-1, while you halve the array with Binary Search!',
    type: 'search_race',
    targetCount: 4, // 4 binary search steps to defeat the linear bot
    targetTime: 22,
    coinReward: 40,
    targetValue: 81,
    arrayData: [4, 8, 15, 16, 23, 42, 50, 58, 64, 72, 81, 88, 92, 95, 98, 100],
    novaReplaySteps: [
      { action: 'mid_choice', midVal: 58, speech: 'Step 1: Check mid = arr[7] = 58. 58 < 81, discard indices 0..7! Bot is only at index 1.' },
      { action: 'mid_choice', midVal: 88, speech: 'Step 2: Check mid = arr[11] = 88. 88 > 81, discard indices 11..15! Bot is only at index 2.' },
      { action: 'mid_choice', midVal: 72, speech: 'Step 3: Check mid = arr[9] = 72. 72 < 81, discard index 9! Bot is at index 3.' },
      { action: 'mid_choice', midVal: 81, speech: 'Step 4: FOUND 81 at index 10 in just 4 steps! Bot was still at index 4. Binary search wins!' }
    ],
    novaIntro: {
      mood: 'excited',
      message: "COLOSSEUM RACE EVENT! We must find the target orb [81] among 16 sorted slots. In the top corridor, the Rogue Bot runs LINEAR SEARCH, checking index 0, 1, 2, 3... step by step in O(N). In the bottom corridor, you wield BINARY SEARCH in O(log N)! Tap the midpoint to halve the search space and beat the bot!"
    },
    hint: "Algorithm Hint: For 16 items, Linear Search takes up to 16 steps! But Binary Search takes log2(16) = 4 steps! Compare mid to 81: if mid < 81, look to the right. If mid > 81, look to the left!",
    failureMessage: "The Rogue Bot overtook you! Remember: pick the middle element of the remaining range to eliminate half the array each step.",
    successMessage: "SPECTACULAR VICTORY! Binary Search found 81 in 4 steps while Linear Search lagged behind. O(log N) dominance proven!",
    recap: {
      conceptName: 'Linear Search O(N) vs. Binary Search O(log N)',
      simpleSummary: 'Linear search inspects every element sequentially (O(N)). Binary search operates on SORTED arrays by repeatedly dividing the search interval in half (O(log N)).',
      arrayType: 'search_race',
      pythonCode: [
        '# Linear Search: O(N) time complexity',
        'def linear_search(arr, target):',
        '    for index, val in enumerate(arr):',
        '        if val == target: return index  # Takes up to N steps',
        '    return -1',
        '',
        '# Binary Search: O(log N) time complexity',
        'def binary_search(arr, target):',
        '    low, high = 0, len(arr) - 1',
        '    while low <= high:',
        '        mid = (low + high) // 2',
        '        if arr[mid] == target: return mid  # Max ~log2(N) steps',
        '        elif arr[mid] < target: low = mid + 1',
        '        else: high = mid - 1',
        '    return -1'
      ],
      jsCode: [
        '// Linear Search: O(N)',
        'function linearSearch(arr, target) {',
        '  for (let i = 0; i < arr.length; i++) {',
        '    if (arr[i] === target) return i; // Up to N comparisons',
        '  }',
        '  return -1;',
        '}',
        '',
        '// Binary Search: O(log N) on sorted data',
        'function binarySearch(arr, target) {',
        '  let low = 0, high = arr.length - 1;',
        '  while (low <= high) {',
        '    const mid = Math.floor((low + high) / 2);',
        '    if (arr[mid] === target) return mid;',
        '    if (arr[mid] < target) low = mid + 1;',
        '    else high = mid - 1;',
        '  }',
        '  return -1;',
        '}'
      ],
      explanationLines: [
        'For N = 1,000,000 items, Linear Search takes up to 1,000,000 checks.',
        'Binary Search takes only ~20 checks (since 2^20 ≈ 1,000,000)!',
        'Binary Search strictly requires the underlying array to be SORTED.'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: Binary Search with Halving',
    concept: 'Low, Mid & High Interval Halving',
    subtitle: 'Track [LOW], [MID], and [HIGH] brackets to pinpoint Target 55 by discarding entire halves!',
    type: 'binary_search_halving',
    targetCount: 3,
    targetTime: 25,
    coinReward: 45,
    targetValue: 55,
    arrayData: [12, 23, 31, 44, 55, 67, 78, 89, 99],
    novaReplaySteps: [
      { action: 'halve', low: 0, high: 8, mid: 4, midVal: 55, speech: 'low=0, high=8 -> mid = floor((0+8)/2) = 4. arr[4] is exactly 55! Target discovered in 1 check!' }
    ],
    novaIntro: {
      mood: 'excited',
      message: "Here are 9 sorted crystal canisters. Our target value is 55. We calculate mid = (low + high) // 2. If arr[mid] is smaller than 55, we discard the entire left half by setting low = mid + 1! Watch the discarded memory slots dissolve into digital dust!"
    },
    hint: "Algorithm Hint: With low=0 and high=8, calculate mid = (0 + 8) // 2 = 4. Check arr[4] = 55. Bingo! If target was 78, arr[4]=55 < 78, so low becomes mid + 1 = 5!",
    failureMessage: "Incorrect midpoint or pointer assignment! Remember: mid = floor((low + high) / 2).",
    successMessage: "Brilliant convergence! You applied exact interval halving to pinpoint the target in logarithmic time!",
    recap: {
      conceptName: 'Binary Search Mechanics & Pointer Invariants',
      simpleSummary: 'Binary Search maintains the loop invariant that if the target exists, it must lie within the range [low, high]. Each comparison cuts the remaining candidates exactly in half.',
      arrayType: 'binary_search_halving',
      pythonCode: [
        'def binary_search_halving(arr, target):',
        '    low = 0',
        '    high = len(arr) - 1',
        '',
        '    while low <= high:',
        '        # Calculate midpoint without overflow',
        '        mid = low + (high - low) // 2',
        '',
        '        if arr[mid] == target:',
        '            return mid  # Target found at index mid',
        '        elif arr[mid] < target:',
        '            # Discard left half',
        '            low = mid + 1',
        '        else:',
        '            # Discard right half',
        '            high = mid - 1',
        '',
        '    return -1  # Target not present'
      ],
      jsCode: [
        'function binarySearchHalving(arr, target) {',
        '  let low = 0;',
        '  let high = arr.length - 1;',
        '',
        '  while (low <= high) {',
        '    // Safe midpoint calculation',
        '    const mid = low + Math.floor((high - low) / 2);',
        '',
        '    if (arr[mid] === target) {',
        '      return mid; // Target found!',
        '    } else if (arr[mid] < target) {',
        '      // Discard left half',
        '      low = mid + 1;',
        '    } else {',
        '      // Discard right half',
        '      high = mid - 1;',
        '    }',
        '  }',
        '  return -1;',
        '}'
      ],
      explanationLines: [
        'Using `low + (high - low) // 2` prevents integer arithmetic overflow in low-level languages.',
        'At each step, the search space reduces from N to N/2 to N/4 ... down to 1.',
        'Halving gives Binary Search its O(log N) logarithmic efficiency curve.'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: The Two-Pointers Colosseum',
    concept: 'Two-Pointers Technique & In-Place Array Reversal',
    subtitle: 'Converge Left and Right pointers toward the center, swapping elements in-place with O(1) space!',
    type: 'two_pointers',
    targetCount: 3, // 3 pair swaps for a 6-element array
    targetTime: 28,
    coinReward: 50,
    initialArray: [10, 20, 30, 40, 50, 60],
    targetArray: [60, 50, 40, 30, 20, 10],
    novaReplaySteps: [
      { action: 'swap_ptrs', left: 0, right: 5, speech: 'Swap arr[0] (10) and arr[5] (60). Left becomes 1, right becomes 4.' },
      { action: 'swap_ptrs', left: 1, right: 4, speech: 'Swap arr[1] (20) and arr[4] (50). Left becomes 2, right becomes 3.' },
      { action: 'swap_ptrs', left: 2, right: 3, speech: 'Swap arr[2] (30) and arr[3] (40). Pointers cross! Array reversed!' }
    ],
    novaIntro: {
      mood: 'serious',
      message: "FINAL ARENA TRIAL! Memory is strictly constrained: you cannot create a new array. Instead, we use the legendary TWO-POINTERS TECHNIQUE! Position pointer LEFT at index 0 and RIGHT at index 5. Swap their values, then move left++ and right-- until they cross in the center!"
    },
    hint: "Algorithm Hint: Swap arr[left] and arr[right]. Then increment left and decrement right. Repeat until left >= right! Notice how this reverses the entire array in-place without allocating extra memory!",
    failureMessage: "Pointer desynchronization! Ensure left starts at 0, right starts at len - 1, and both move towards the center after each swap.",
    successMessage: "SUPREME MASTERY! You executed the two-pointers in-place reversal flawlessly! You have completed Array Arena and mastered Algoria's Core DSA!",
    recap: {
      conceptName: 'Two-Pointers Technique & In-Place Manipulation',
      simpleSummary: 'The Two-Pointers pattern uses two indices iterating through the array at different speeds or directions. It achieves O(N) time and O(1) auxiliary space, making it a cornerstone of competitive programming.',
      arrayType: 'two_pointers',
      pythonCode: [
        'def reverse_array_in_place(arr):',
        '    left = 0',
        '    right = len(arr) - 1',
        '',
        '    while left < right:',
        '        # Swap elements at both pointers',
        '        arr[left], arr[right] = arr[right], arr[left]',
        '',
        '        # Converge pointers toward the center',
        '        left += 1',
        '        right -= 1',
        '',
        '    return arr  # Reversed in O(N) time, O(1) space!'
      ],
      jsCode: [
        'function reverseArrayInPlace(arr) {',
        '  let left = 0;',
        '  let right = arr.length - 1;',
        '',
        '  while (left < right) {',
        '    // In-place swap',
        '    const temp = arr[left];',
        '    arr[left] = arr[right];',
        '    arr[right] = temp;',
        '',
        '    // Advance pointers inward',
        '    left++;',
        '    right--;',
        '  }',
        '  return arr;',
        '}'
      ],
      explanationLines: [
        'Two-pointers avoids the O(N) extra memory required by naive array copies.',
        'Runs in linear O(N/2) = O(N) time with only N/2 swaps.',
        'Extensively used for palindrome verification, pair sum problems, water container optimization, and sliding windows.'
      ]
    }
  }
];
