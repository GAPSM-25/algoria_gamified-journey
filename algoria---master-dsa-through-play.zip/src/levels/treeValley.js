/**
 * Tree Valley - Level Configurations
 * Extensible configuration file for World 4: Tree Valley.
 * Teaches Binary Trees: Root, Parent, Child, Leaf, Traversals (Preorder, Inorder, Postorder),
 * Binary Search Tree (BST) insertion, BST search, and Tree Height / Max Depth.
 */

export const TREE_VALLEY_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The Preorder Canopy',
    concept: 'Preorder Traversal: Root → Left → Right',
    subtitle: 'Ascend the great binary tree and harvest fruits in Preorder sequence!',
    type: 'tree_traversal',
    traversalMode: 'preorder',
    targetCount: 7,
    targetTime: 22,
    coinReward: 25,
    treeData: {
      id: 'root',
      value: 50,
      label: '50',
      role: 'Root',
      left: {
        id: 'n30',
        value: 30,
        label: '30',
        role: 'Parent',
        left: { id: 'n20', value: 20, label: '20', role: 'Leaf' },
        right: { id: 'n40', value: 40, label: '40', role: 'Leaf' }
      },
      right: {
        id: 'n70',
        value: 70,
        label: '70',
        role: 'Parent',
        left: { id: 'n60', value: 60, label: '60', role: 'Leaf' },
        right: { id: 'n80', value: 80, label: '80', role: 'Leaf' }
      }
    },
    // Preorder: Root (50) -> Left Subtree (30 -> 20 -> 40) -> Right Subtree (70 -> 60 -> 80)
    expectedSequence: [50, 30, 20, 40, 70, 60, 80],
    novaIntro: {
      mood: 'excited',
      message: "Welcome to Tree Valley! Ahead stands the Ancient Binary Tree. Every node has at most two children: Left and Right. In PREORDER traversal, we visit the ROOT first, then recursively traverse the LEFT subtree, then the RIGHT subtree! Watch my ghost path hint, then collect the 7 fruits in order!"
    },
    hint: "Algorithm Hint: PREORDER = [ROOT] first, then dive into the entire [LEFT] branch, and finally the [RIGHT] branch: 50 → 30 → 20 → 40 → 70 → 60 → 80. Click 'Show Ghost Path' anytime to replay the guide!",
    failureMessage: "Traversal breach! You attempted to harvest a node out of Preorder sequence. Remember: Root first, then Left subtree before Right!",
    successMessage: "Splendid climb! You collected all 7 fruits in pristine Preorder (Root → Left → Right) order!",
    recap: {
      conceptName: 'Tree Anatomy & Preorder Traversal (DFS)',
      simpleSummary: 'A Binary Tree organizes data hierarchically. In Preorder traversal, we process the Root node before either of its subtrees.',
      pythonCode: [
        'class TreeNode:',
        '    def __init__(self, val=0, left=None, right=None):',
        '        self.val = val',
        '        self.left = left',
        '        self.right = right',
        '',
        'def preorder_traversal(root):',
        '    if not root:',
        '        return []',
        '    # Preorder: Root -> Left -> Right',
        '    return [root.val] + preorder_traversal(root.left) + preorder_traversal(root.right)',
        '',
        '# Result: [50, 30, 20, 40, 70, 60, 80]'
      ],
      jsCode: [
        'function preorderTraversal(root) {',
        '    if (!root) return [];',
        '    // Preorder: Root -> Left -> Right',
        '    return [',
        '        root.val,',
        '        ...preorderTraversal(root.left),',
        '        ...preorderTraversal(root.right)',
        '    ];',
        '}',
        '// Result: [50, 30, 20, 40, 70, 60, 80]'
      ],
      explanationLines: [
        'Root: The topmost node of the tree with no parent (50).',
        'Children: Left child (30) and Right child (70).',
        'Leaves: Nodes with no children at the tips of branches (20, 40, 60, 80).',
        'Preorder is frequently used to serialize or clone a tree structure.'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: The Inorder Harmony',
    concept: 'Inorder Traversal: Left → Root → Right (Sorted BST)',
    subtitle: 'Harvest the luminous fruits in Inorder sequence: observe the numerical order!',
    type: 'tree_traversal',
    traversalMode: 'inorder',
    targetCount: 7,
    targetTime: 22,
    coinReward: 30,
    treeData: {
      id: 'root',
      value: 50,
      label: '50',
      role: 'Root',
      left: {
        id: 'n30',
        value: 30,
        label: '30',
        role: 'Parent',
        left: { id: 'n20', value: 20, label: '20', role: 'Leaf' },
        right: { id: 'n40', value: 40, label: '40', role: 'Leaf' }
      },
      right: {
        id: 'n70',
        value: 70,
        label: '70',
        role: 'Parent',
        left: { id: 'n60', value: 60, label: '60', role: 'Leaf' },
        right: { id: 'n80', value: 80, label: '80', role: 'Leaf' }
      }
    },
    // Inorder: Left Subtree (20 -> 30 -> 40) -> Root (50) -> Right Subtree (60 -> 70 -> 80)
    expectedSequence: [20, 30, 40, 50, 60, 70, 80],
    novaIntro: {
      mood: 'curious',
      message: "Here is an astonishing secret of computer science: INORDER traversal visits LEFT, then ROOT, then RIGHT! On a Binary Search Tree, Inorder traversal visits every key in strictly ASCENDING sorted order: 20, 30, 40, 50, 60, 70, 80! Watch the ghost path, then climb!"
    },
    hint: "Algorithm Hint: INORDER = [LEFT] subtree deepest leaf first, then its [PARENT/ROOT], then [RIGHT]: 20 → 30 → 40 → 50 → 60 → 70 → 80. Notice how the values are strictly ascending!",
    failureMessage: "Sequence interrupted! Inorder requires visiting the leftmost branch before parent and right siblings.",
    successMessage: "Harmonious traversal! Notice how Inorder naturally transformed our tree into a perfectly sorted array: 20, 30, 40, 50, 60, 70, 80!",
    recap: {
      conceptName: 'Inorder Traversal & BST Sorting Property',
      simpleSummary: 'Inorder traversal processes Left Subtree, then Root, then Right Subtree. On a Binary Search Tree, it always yields elements in sorted order.',
      pythonCode: [
        'def inorder_traversal(root):',
        '    if not root:',
        '        return []',
        '    # Inorder: Left -> Root -> Right',
        '    return inorder_traversal(root.left) + [root.val] + inorder_traversal(root.right)',
        '',
        '# For a BST, this produces sorted order!',
        '# Result: [20, 30, 40, 50, 60, 70, 80]'
      ],
      jsCode: [
        'function inorderTraversal(root) {',
        '    if (!root) return [];',
        '    // Inorder: Left -> Root -> Right',
        '    return [',
        '        ...inorderTraversal(root.left),',
        '        root.val,',
        '        ...inorderTraversal(root.right)',
        '    ];',
        '}',
        '// Result: [20, 30, 40, 50, 60, 70, 80]'
      ],
      explanationLines: [
        'Inorder traversal is the fundamental algorithm used to retrieve sorted keys from a BST.',
        'Time Complexity is O(N) because every node is visited exactly once.',
        'Space Complexity is O(H) on the call stack, where H is the height of the tree.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: The Postorder Roots',
    concept: 'Postorder Traversal: Left → Right → Root (Bottom-Up)',
    subtitle: 'Harvest both children before the parent. The root fruit is collected last!',
    type: 'tree_traversal',
    traversalMode: 'postorder',
    targetCount: 7,
    targetTime: 24,
    coinReward: 35,
    treeData: {
      id: 'root',
      value: 50,
      label: '50',
      role: 'Root',
      left: {
        id: 'n30',
        value: 30,
        label: '30',
        role: 'Parent',
        left: { id: 'n20', value: 20, label: '20', role: 'Leaf' },
        right: { id: 'n40', value: 40, label: '40', role: 'Leaf' }
      },
      right: {
        id: 'n70',
        value: 70,
        label: '70',
        role: 'Parent',
        left: { id: 'n60', value: 60, label: '60', role: 'Leaf' },
        right: { id: 'n80', value: 80, label: '80', role: 'Leaf' }
      }
    },
    // Postorder: Left Subtree (20 -> 40 -> 30) -> Right Subtree (60 -> 80 -> 70) -> Root (50)
    expectedSequence: [20, 40, 30, 60, 80, 70, 50],
    novaIntro: {
      mood: 'serious',
      message: "In POSTORDER traversal, we explore from the bottom up! Both the LEFT and RIGHT subtrees must be completely harvested before their parent, and the ROOT node is harvested dead last! Watch the ghost path: 20, 40, 30, 60, 80, 70, and finally 50!"
    },
    hint: "Algorithm Hint: POSTORDER = [LEFT] child, then [RIGHT] child, then [PARENT]. The main Root (50) must be your very last harvest: 20 → 40 → 30 → 60 → 80 → 70 → 50!",
    failureMessage: "Order violation! In Postorder, you cannot harvest a parent node until both of its children have already been cleared.",
    successMessage: "Flawless bottom-up traversal! Postorder safely cleared all child dependencies before finishing at the Root!",
    recap: {
      conceptName: 'Postorder Traversal & Bottom-Up Evaluation',
      simpleSummary: 'Postorder processes Left Subtree, then Right Subtree, and finishes with the Root. Ideal for deleting trees and evaluating mathematical expression trees.',
      pythonCode: [
        'def postorder_traversal(root):',
        '    if not root:',
        '        return []',
        '    # Postorder: Left -> Right -> Root',
        '    return postorder_traversal(root.left) + postorder_traversal(root.right) + [root.val]',
        '',
        '# Result: [20, 40, 30, 60, 80, 70, 50]'
      ],
      jsCode: [
        'function postorderTraversal(root) {',
        '    if (!root) return [];',
        '    // Postorder: Left -> Right -> Root',
        '    return [',
        '        ...postorderTraversal(root.left),',
        '        ...postorderTraversal(root.right),',
        '        root.val',
        '    ];',
        '}',
        '// Result: [20, 40, 30, 60, 80, 70, 50]'
      ],
      explanationLines: [
        'Bottom-up guarantee: Child nodes are guaranteed to be evaluated before their parent.',
        'Used in syntax trees for compilers (e.g. evaluating 3 + 4 * 2).',
        'Used in memory managers to safely free leaf memory before removing parents.'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: The BST Grafting Garden',
    concept: 'Binary Search Tree Insertion (Left < Node < Right)',
    subtitle: 'Plant new fruits into the BST by choosing Left for smaller and Right for larger!',
    type: 'bst_insertion',
    targetCount: 4,
    targetTime: 25,
    coinReward: 40,
    treeData: {
      id: 'root',
      value: 50,
      label: '50',
      role: 'Root',
      left: {
        id: 'n30',
        value: 30,
        label: '30',
        role: 'Parent',
        left: { id: 'n20', value: 20, label: '20', role: 'Leaf' }
      },
      right: {
        id: 'n70',
        value: 70,
        label: '70',
        role: 'Parent',
        right: { id: 'n80', value: 80, label: '80', role: 'Leaf' }
      }
    },
    fruitsToInsert: [
      {
        value: 25,
        hint: '25 < 50 (Go Left) → 25 < 30 (Go Left) → 25 > 20 (Go Right to plant!)',
        expectedPath: ['left', 'left', 'right']
      },
      {
        value: 65,
        hint: '65 > 50 (Go Right) → 65 < 70 (Go Left to plant!)',
        expectedPath: ['right', 'left']
      },
      {
        value: 15,
        hint: '15 < 50 (Go Left) → 15 < 30 (Go Left) → 15 < 20 (Go Left to plant!)',
        expectedPath: ['left', 'left', 'left']
      },
      {
        value: 85,
        hint: '85 > 50 (Go Right) → 85 > 70 (Go Right) → 85 > 80 (Go Right to plant!)',
        expectedPath: ['right', 'right', 'right']
      }
    ],
    novaIntro: {
      mood: 'happy',
      message: "Time to grow the tree! In a Binary Search Tree (BST), the golden invariant is: values SMALLER than current go LEFT; values LARGER go RIGHT! Compare the incoming fruit value with each node and navigate left or right until you reach the correct empty branch to plant it!"
    },
    hint: "Algorithm Hint: At each branch, ask: 'Is my fruit value < node value?' If YES, click LEFT. If NO (fruit is greater), click RIGHT. Repeat until reaching the empty leaf slot!",
    failureMessage: "Incorrect branch choice! BST rules require smaller numbers on the left and larger numbers on the right.",
    successMessage: "All 4 fruits planted in their optimal BST positions! The tree remains perfectly ordered and balanced!",
    recap: {
      conceptName: 'BST Insertion Algorithm',
      simpleSummary: 'Inserting into a BST compares the new key with the current node: recurse Left if smaller, Right if larger, and insert upon reaching null.',
      pythonCode: [
        'def insert_into_bst(root, val):',
        '    if not root:',
        '        return TreeNode(val)',
        '    if val < root.val:',
        '        root.left = insert_into_bst(root.left, val)',
        '    else:',
        '        root.right = insert_into_bst(root.right, val)',
        '    return root'
      ],
      jsCode: [
        'function insertIntoBST(root, val) {',
        '    if (!root) return new TreeNode(val);',
        '    if (val < root.val) {',
        '        root.left = insertIntoBST(root.left, val);',
        '    } else {',
        '        root.right = insertIntoBST(root.right, val);',
        '    }',
        '    return root;',
        '}'
      ],
      explanationLines: [
        'BST Property: Every node in left subtree is < parent; every node in right subtree is > parent.',
        'Average Insertion Time: O(log N) on a balanced tree.',
        'Inserting maintains order without needing to re-sort existing nodes.'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: The Search & Tree Height',
    concept: 'BST Search O(log N) & Max Depth (Height)',
    subtitle: 'Search target keys in logarithmic time and determine the tree height!',
    type: 'bst_search_and_height',
    targetCount: 3, // Search 1, Search 2, Height calculation
    targetTime: 25,
    coinReward: 50,
    treeData: {
      id: 'root',
      value: 50,
      label: '50',
      role: 'Root',
      depth: 0,
      left: {
        id: 'n25',
        value: 25,
        label: '25',
        role: 'Parent',
        depth: 1,
        left: { id: 'n15', value: 15, label: '15', role: 'Leaf', depth: 2 },
        right: { id: 'n35', value: 35, label: '35', role: 'Leaf', depth: 2 }
      },
      right: {
        id: 'n75',
        value: 75,
        label: '75',
        role: 'Parent',
        depth: 1,
        left: { id: 'n65', value: 65, label: '65', role: 'Leaf', depth: 2 },
        right: {
          id: 'n85',
          value: 85,
          label: '85',
          role: 'Parent',
          depth: 2,
          right: { id: 'n95', value: 95, label: '95', role: 'Deepest Leaf', depth: 3 }
        }
      }
    },
    searchTargets: [
      {
        target: 65,
        prompt: 'Search Target: 65. Navigate the BST from root to locate 65!',
        expectedSteps: ['right', 'left', 'found']
      },
      {
        target: 15,
        prompt: 'Search Target: 15. Navigate the BST from root to locate 15!',
        expectedSteps: ['left', 'left', 'found']
      }
    ],
    treeHeightChallenge: {
      correctHeight: 3, // Levels of edges from root to deepest leaf (nodes 50 -> 75 -> 85 -> 95 = 3 edges, depth 3)
      options: [1, 2, 3, 4],
      explanation: 'The deepest leaf is 95 at depth 3 (50 → 75 → 85 → 95). Max Depth / Height = 3 edges (4 node levels).'
    },
    novaIntro: {
      mood: 'serious',
      message: "The final summit! First, use BST search logic to find target keys in lightning-fast O(log N) time by eliminating half the remaining tree at every step! Then, calculate the Tree Height: the maximum number of edge branches from the Root to the deepest Leaf! TREE WHISPERER BADGE awaits!"
    },
    hint: "Algorithm Hint: Search: at each node, compare Target with Current. If Target < Node, go Left; if Target > Node, go Right; if Target == Node, tap 'FOUND!'. Height: count the edges from Root (depth 0) to deepest leaf 95 (depth 3)!",
    failureMessage: "Search or Height miscalculation! Remember: BST search cuts search space in half each step, and height is the max depth from root to deepest leaf.",
    successMessage: "Incredible mastery! You conquered Preorder, Inorder, Postorder, BST Insertion, BST Search, and Tree Height! TREE WHISPERER BADGE AWARDED!",
    recap: {
      conceptName: 'BST Search & Maximum Depth (Tree Height)',
      simpleSummary: 'BST search halves the search space each step: O(log N). Tree Height (or Max Depth) is the longest path from Root to any Leaf.',
      pythonCode: [
        'def search_bst(root, target):',
        '    if not root or root.val == target:',
        '        return root',
        '    if target < root.val:',
        '        return search_bst(root.left, target)',
        '    return search_bst(root.right, target)',
        '',
        'def max_depth(root):',
        '    if not root:',
        '        return 0',
        '    return 1 + max(max_depth(root.left), max_depth(root.right))',
        '# Result for this tree: Max Depth = 4 nodes (Height = 3 edges)'
      ],
      jsCode: [
        'function searchBST(root, target) {',
        '    if (!root || root.val === target) return root;',
        '    if (target < root.val) return searchBST(root.left, target);',
        '    return searchBST(root.right, target);',
        '}',
        '',
        'function maxDepth(root) {',
        '    if (!root) return 0;',
        '    return 1 + Math.max(maxDepth(root.left), maxDepth(root.right));',
        '}'
      ],
      explanationLines: [
        'BST Search Time Complexity: O(log N) average, O(N) worst case if unbalanced.',
        'Tree Height / Max Depth defines the maximum time complexity for search and insertion.',
        'Self-balancing trees (AVL, Red-Black) maintain height at O(log N) to guarantee peak speed.'
      ]
    }
  }
];
