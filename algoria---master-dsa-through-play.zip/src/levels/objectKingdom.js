/**
 * Object Kingdom - Level Configurations
 * World 7 / OOP Realm: Object Kingdom.
 * Teaches Object-Oriented Programming (OOP) paradigms for MCA Computer Science:
 * 1. Classes & Objects (Blueprints vs Instances, Constructor, State & Behavior)
 * 2. Encapsulation (Private Fields #, Getters, Setters, Data Integrity & Protection)
 * 3. Inheritance (Subclassing, extends, super() chaining, Code Reusability)
 * 4. Polymorphism (Method Overriding, Uniform Interface, Heterogeneous Collections)
 * 5. Abstraction (Abstract Classes, Interface Contracts, Decoupled Architectures)
 */

export const OBJECT_KINGDOM_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The Blueprint Forge',
    concept: 'Classes & Objects: Blueprints vs Instances',
    subtitle: 'Construct class blueprints and instantiate 3 unique Guardian Robots!',
    type: 'oop_classes_objects',
    targetCount: 3,
    targetTime: 25,
    coinReward: 35,
    blueprintConfig: {
      className: 'GuardianRobot',
      constructorParams: ['name', 'coreType', 'energyLevel'],
      methods: ['chargeCore()', 'scanSector()', 'displayStatus()']
    },
    requiredInstances: [
      { id: 'bot_alpha', name: 'Aegis-One', coreType: 'Plasma', energyLevel: 100, role: 'Vanguard Tank' },
      { id: 'bot_beta', name: 'Volt-Spark', coreType: 'Lightning', energyLevel: 85, role: 'Speed Scout' },
      { id: 'bot_gamma', name: 'Cryo-Shield', coreType: 'Glacier', energyLevel: 95, role: 'Frost Defender' }
    ],
    novaIntro: {
      mood: 'excited',
      message: "Welcome to the Object Kingdom! In Object-Oriented Programming, a CLASS is a Blueprint, while an OBJECT is a living Instance built from that blueprint! Let's forge 3 unique Guardian Robots by passing distinct parameters into our class constructor!"
    },
    hint: "Algorithm Hint: A Class defines the template (constructor). Use the 'new' keyword to create independent object instances, each carrying their own unique internal state!",
    failureMessage: "Blueprint error! Ensure all 3 Guardian instances are properly created with valid constructor arguments.",
    successMessage: "All 3 Guardian Robots instantiated! Each object has distinct state while sharing the same class methods!",
    recap: {
      conceptName: 'Classes & Objects (OOP Fundamentals)',
      simpleSummary: 'A Class is a blueprint; an Object is a concrete realization (instance) created with the "new" operator.',
      pythonCode: [
        'class GuardianRobot:',
        '    def __init__(self, name, core_type, energy):',
        '        self.name = name          # Instance state',
        '        self.core_type = core_type',
        '        self.energy = energy',
        '',
        '    def scan_sector(self):',
        '        return f"{self.name} scanning with {self.core_type} core!"',
        '',
        '# Instantiating objects from the class blueprint',
        'bot1 = GuardianRobot("Aegis-One", "Plasma", 100)',
        'bot2 = GuardianRobot("Volt-Spark", "Lightning", 85)'
      ],
      jsCode: [
        'class GuardianRobot {',
        '    constructor(name, coreType, energy) {',
        '        this.name = name;          // Instance state',
        '        this.coreType = coreType;',
        '        this.energy = energy;',
        '    }',
        '    scanSector() {',
        '        return `${this.name} scanning with ${this.coreType} core!`;',
        '    }',
        '}',
        '// Instantiating objects from the class blueprint',
        'const bot1 = new GuardianRobot("Aegis-One", "Plasma", 100);',
        'const bot2 = new GuardianRobot("Volt-Spark", "Lightning", 85);'
      ],
      explanationLines: [
        'Class: Defines the structure (properties) and capabilities (methods).',
        'Object: Specific entity stored in heap memory with individual state.',
        'Constructor: Special initialization routine called when creating an object.'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: The Vault of Encapsulation',
    concept: 'Encapsulation: Private Fields (#), Getters & Setters',
    subtitle: 'Guard critical state against direct corruption using defensive setters!',
    type: 'oop_encapsulation',
    targetCount: 4,
    targetTime: 25,
    coinReward: 40,
    encapsulationRules: [
      {
        field: 'health',
        attackPayload: -50,
        expectedResult: 'Rejected (health cannot be negative)',
        fixCode: 'if (val >= 0 && val <= 100) this.#health = val;'
      },
      {
        field: 'accessPin',
        attackPayload: '0000',
        expectedResult: 'Rejected (invalid security format)',
        fixCode: 'if (val.length === 6) this.#accessPin = val;'
      },
      {
        field: 'shieldCapacity',
        attackPayload: 99999,
        expectedResult: 'Capped at maximum rating (200)',
        fixCode: 'this.#shield = Math.min(200, Math.max(0, val));'
      },
      {
        field: 'operationalMode',
        attackPayload: 'OVERRIDE_ROOT',
        expectedResult: 'Sanitized to safe fallback mode',
        fixCode: 'if (ALLOWED_MODES.includes(val)) this.#mode = val;'
      }
    ],
    novaIntro: {
      mood: 'serious',
      message: "Security Alert! Rogues are trying to corrupt our robot's internal memory by directly modifying variables like health = -500! ENCAPSULATION bundles data with methods and hides raw fields with private access. Only verified getters and setters may access the data!"
    },
    hint: "Algorithm Hint: Encapsulation enforces data integrity. Private fields (#field) cannot be accessed directly from the outside; setters validate input before updating state!",
    failureMessage: "Data breach! Raw fields were exposed without validation. Implement private fields and defensive setters!",
    successMessage: "Fortress secured! Encapsulation intercepted and neutralized all unauthorized state corruption attempts!",
    recap: {
      conceptName: 'Encapsulation & Data Hiding',
      simpleSummary: 'Encapsulation protects object state by making variables private and providing public getters and setters with validation.',
      pythonCode: [
        'class SecureRobot:',
        '    def __init__(self, name):',
        '        self.name = name',
        '        self.__health = 100  # Private attribute with double underscore',
        '',
        '    @property',
        '    def health(self):',
        '        return self.__health',
        '',
        '    @health.setter',
        '    def health(self, value):',
        '        if value < 0:',
        '            raise ValueError("Health cannot be negative!")',
        '        self.__health = min(100, value)'
      ],
      jsCode: [
        'class SecureRobot {',
        '    #health = 100; // Private class field in modern JavaScript',
        '',
        '    get health() {',
        '        return this.#health;',
        '    }',
        '    set health(value) {',
        '        if (value < 0) throw new RangeError("Invalid health");',
        '        this.#health = Math.min(100, value);',
        '    }',
        '}'
      ],
      explanationLines: [
        'Information Hiding: Internal state is hidden from arbitrary external modification.',
        'Data Validation: Setters intercept invalid inputs before state changes occur.',
        'Read-Only Fields: Providing only a getter creates immutable properties.'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: The Royal Dynasty',
    concept: 'Inheritance: Subclassing & Super Chaining',
    subtitle: 'Inherit base Guardian powers and specialize into Paladin and Sorcerer!',
    type: 'oop_inheritance',
    targetCount: 3,
    targetTime: 25,
    coinReward: 45,
    hierarchyData: {
      baseClass: 'BaseGuardian',
      baseMethods: ['patrol()', 'takeDamage()', 'transmitSignal()'],
      subclasses: [
        {
          name: 'PaladinGuardian',
          specialty: 'Heavy Armor & Shield Bash',
          superCall: 'super(name, "HeavyPlate", 150)',
          uniqueMethod: 'castInvulnerabilityAura()'
        },
        {
          name: 'SorcererGuardian',
          specialty: 'Arcane Energy & Teleportation',
          superCall: 'super(name, "ArcaneSilk", 90)',
          uniqueMethod: 'teleportBehindIntruder()'
        },
        {
          name: 'StealthInfiltrator',
          specialty: 'Optical Cloak & Thermal Vision',
          superCall: 'super(name, "CarbonFiber", 110)',
          uniqueMethod: 'cloakFromRadar()'
        }
      ]
    },
    novaIntro: {
      mood: 'curious',
      message: "Why rewrite code when we can INHERIT it? In OOP, INHERITANCE allows derived subclasses to adopt all attributes and methods of a parent class using 'extends', and chain their constructors with 'super()'! Let's build a noble lineage of specialized guardians!"
    },
    hint: "Algorithm Hint: INHERITANCE establishes an 'is-a' relationship. The derived subclass calls super() to initialize parent fields, then adds its own specialized methods!",
    failureMessage: "Inheritance break! Remember that derived classes must call super() before accessing 'this'!",
    successMessage: "Splendid dynasty! Subclasses seamlessly inherited base guardian skills while unleashing their unique specialized powers!",
    recap: {
      conceptName: 'Inheritance & Subclass Specialization',
      simpleSummary: 'Inheritance enables new classes to receive properties and methods from an existing base class, promoting code reuse (DRY).',
      pythonCode: [
        'class BaseGuardian:',
        '    def __init__(self, name, health):',
        '        self.name = name',
        '        self.health = health',
        '    def patrol(self):',
        '        return f"{self.name} is on perimeter duty."',
        '',
        'class PaladinGuardian(BaseGuardian):  # Inherits BaseGuardian',
        '    def __init__(self, name, shield_power):',
        '        super().__init__(name, 150)   # Invokes parent constructor',
        '        self.shield_power = shield_power',
        '    def shield_bash(self):',
        '        return f"{self.name} bashes with {self.shield_power} force!"'
      ],
      jsCode: [
        'class BaseGuardian {',
        '    constructor(name, health) {',
        '        this.name = name;',
        '        this.health = health;',
        '    }',
        '    patrol() {',
        '        return `${this.name} is on perimeter duty.`;',
        '    }',
        '}',
        'class PaladinGuardian extends BaseGuardian {',
        '    constructor(name, shieldPower) {',
        '        super(name, 150); // Calls parent constructor',
        '        this.shieldPower = shieldPower;',
        '    }',
        '    shieldBash() {',
        '        return `${this.name} bashes with ${this.shieldPower} force!`;',
        '    }',
        '}'
      ],
      explanationLines: [
        'Code Reusability: Common logic is defined once in the parent class.',
        'Extensibility: Derived classes extend capabilities without altering base code.',
        'super() Keyword: Bridges derived subclass instantiation to the parent constructor.'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: The Morphing Colosseum',
    concept: 'Polymorphism: Method Overriding & Uniform Dispatch',
    subtitle: 'Execute identical activateAbility() calls across heterogeneous robot teams!',
    type: 'oop_polymorphism',
    targetCount: 3,
    targetTime: 25,
    coinReward: 50,
    polymorphicTeam: [
      {
        id: 'bot_warrior',
        name: 'Gareth the Brawler',
        classType: 'WarriorBot',
        overrideAction: 'Blade Vortex (Physical Cleave 120 DMG)'
      },
      {
        id: 'bot_mage',
        name: 'Astral the Chronomancer',
        classType: 'ChronoMageBot',
        overrideAction: 'Time Warp (Freezes battlefield for 3s)'
      },
      {
        id: 'bot_support',
        name: 'Nightingale Nano',
        classType: 'SupportNanoBot',
        overrideAction: 'Bioluminescent Healing Wave (+80 HP Team)'
      }
    ],
    novaIntro: {
      mood: 'excited',
      message: "Behold the magic of POLYMORPHISM ('many shapes')! We hold a list of different robots. When we call the exact same method name — .activateAbility() — each robot executes its OWN unique, overridden version! One interface, multiple distinct implementations!"
    },
    hint: "Algorithm Hint: Polymorphism allows treating diverse subclasses through a single common interface. Loop over the array: team.forEach(bot => bot.activateAbility())!",
    failureMessage: "Dispatch failure! Ensure each subclass overrides the common method signature with its own specialized behavior.",
    successMessage: "Spectacular polymorphism! A single uniform call orchestrated 3 vastly different, breathtaking abilities!",
    recap: {
      conceptName: 'Polymorphism & Dynamic Method Dispatch',
      simpleSummary: 'Polymorphism allows different classes to define the same method name, executing distinct behavior depending on the runtime object instance.',
      pythonCode: [
        'class WarriorBot:',
        '    def activate_ability(self):',
        '        return "Blade Whirlwind!"',
        '',
        'class ChronoMageBot:',
        '    def activate_ability(self):',
        '        return "Temporal Freeze!"',
        '',
        '# Polymorphic iteration over heterogeneous collection',
        'team = [WarriorBot(), ChronoMageBot()]',
        'for bot in team:',
        '    print(bot.activate_ability())  # Dynamically resolved at runtime!'
      ],
      jsCode: [
        'class WarriorBot {',
        '    activateAbility() { return "Blade Whirlwind!"; }',
        '}',
        'class ChronoMageBot {',
        '    activateAbility() { return "Temporal Freeze!"; }',
        '}',
        '// Polymorphic iteration over heterogeneous collection',
        'const team = [new WarriorBot(), new ChronoMageBot()];',
        'team.forEach(bot => console.log(bot.activateAbility()));'
      ],
      explanationLines: [
        'Uniform Interface: The caller does not need to know the specific subclass type.',
        'Method Overriding: Derived classes provide specialized implementations of inherited methods.',
        'Dynamic Dispatch: The runtime environment determines which method implementation to execute.'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: The Master Citadel',
    concept: 'Abstraction: Abstract Classes & Interface Contracts',
    subtitle: 'Fulfill abstract contract specifications to power up the Citadel Core!',
    type: 'oop_abstraction',
    targetCount: 3,
    targetTime: 25,
    coinReward: 60,
    abstractContract: {
      interfaceName: 'IPowerCitadelCore',
      abstractMethods: [
        {
          name: 'authenticateCoreKey()',
          description: 'Validates cryptographic signature of the Citadel key'
        },
        {
          name: 'stabilizePlasmaFlux()',
          description: 'Regulates harmonic reactor frequencies between 40Hz and 60Hz'
        },
        {
          name: 'igniteCitadelBarrier()',
          description: 'Raises the impenetrable kingdom defensive shield'
        }
      ]
    },
    novaIntro: {
      mood: 'proud',
      message: "The final summit of OOP! ABSTRACTION separates the 'WHAT' from the 'HOW'. An Abstract Class or Interface defines a strict CONTRACT of required methods without dictating the messy internal details. Implement every contract requirement to awaken the Object Citadel!"
    },
    hint: "Algorithm Hint: Abstraction hides complexity. You cannot instantiate an abstract class directly; you must create a concrete class that implements all abstract methods declared in the interface!",
    failureMessage: "Contract violation! A concrete class cannot be instantiated if it leaves any abstract methods unimplemented.",
    successMessage: "OBJECT KINGDOM CONQUERED! You have mastered Classes, Encapsulation, Inheritance, Polymorphism, and Abstraction! OBJECT ARCHITECT BADGE AWARDED!",
    recap: {
      conceptName: 'Abstraction & Interface Contracts',
      simpleSummary: 'Abstraction hides internal implementation details and exposes only high-level contract specifications, decoupling components.',
      pythonCode: [
        'from abc import ABC, abstractmethod',
        '',
        'class CitadelCore(ABC):  # Abstract Base Class',
        '    @abstractmethod',
        '    def authenticate_key(self):',
        '        pass',
        '    @abstractmethod',
        '    def stabilize_flux(self):',
        '        pass',
        '',
        'class ConcreteCitadelCore(CitadelCore):',
        '    def authenticate_key(self):',
        '        return "Signature Verified"',
        '    def stabilize_flux(self):',
        '        return "Reactor Stabilized at 50Hz"'
      ],
      jsCode: [
        '// In TypeScript, interfaces enforce contracts at compile-time',
        'interface CitadelCoreContract {',
        '    authenticateKey(): boolean;',
        '    stabilizeFlux(): string;',
        '}',
        '',
        'class ConcreteCitadelCore implements CitadelCoreContract {',
        '    authenticateKey() { return true; }',
        '    stabilizeFlux() { return "Reactor Stabilized at 50Hz"; }',
        '}'
      ],
      explanationLines: [
        'Contract Enforcement: Ensures every implementor delivers the expected methods.',
        'Decoupling: Systems depend on abstractions rather than concrete implementations (Dependency Inversion Principle).',
        'Simplicity: Consumers interact with a clean, concise API without worrying about internal complexity.'
      ]
    }
  }
];
