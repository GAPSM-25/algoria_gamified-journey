/**
 * Loop Forest - Level Configurations
 * Extensible configuration file for all levels in World 1: Loop Forest.
 */

export const LOOP_FOREST_LEVELS = [
  {
    id: 1,
    title: 'Level 1: The First Leap',
    concept: 'Manual Sequence vs. Repetition',
    subtitle: 'Jump on 5 trees manually to feel the repetition',
    type: 'manual_jump', // Player interacts with space / Jump button
    targetCount: 5,
    treeCount: 5,
    speed: 280,
    coinPattern: 'floating_above', // Coins above each beacon
    targetTime: 14, // seconds for 3-star benchmark
    hasRiver: false,
    novaIntro: {
      mood: 'happy',
      message: "Welcome to Loop Forest, Explorer! Ahead are 5 bioluminescent trees. Tap JUMP (or press SPACE) as you approach each tree to vault safely over them and grab the crystals!"
    },
    hint: "Algorithm Hint: Press JUMP right as you enter the glowing cyan beacon on the ground. A well-timed jump clears the trunk and catches the floating crystal in midair!",
    failureMessage: "Missed the branch! Timing is everything. Keep your eyes on the glowing approach beacons!",
    successMessage: "5 trees cleared! But whew... imagine doing that 100 times manually. There has to be a smarter way!",
    recap: {
      conceptName: 'Sequential Execution vs. The Need for Loops',
      simpleSummary: 'In basic code, every single action requires writing out a new line. 5 jumps meant 5 lines of code!',
      pythonCode: [
        '# Manual sequential jumps',
        'jump()',
        'jump()',
        'jump()',
        'jump()',
        'jump()'
      ],
      jsCode: [
        '// Manual sequential jumps',
        'jump();',
        'jump();',
        'jump();',
        'jump();',
        'jump();'
      ],
      explanationLines: [
        'Line by line execution: every tree needed its own jump instruction.',
        'If we had 10,000 trees, our code file would be 10,000 lines long!',
        'This is why computer science invented the powerful concept of LOOPS.'
      ]
    }
  },
  {
    id: 2,
    title: 'Level 2: The Power of Loops',
    concept: 'For Loop / Count-Controlled Loop',
    subtitle: 'Automate 20 jumps with a single repeat block',
    type: 'for_loop',
    targetCount: 20,
    treeCount: 20,
    speed: 360,
    coinPattern: 'every_other_tree', // Coins along the marathon route
    targetTime: 22,
    hasRiver: false,
    defaultLoopCount: 1,
    minLoopCount: 1,
    maxLoopCount: 30,
    novaIntro: {
      mood: 'excited',
      message: "Whoa, look ahead! There are 20 dense trees in this grove! Tapping 20 times by hand would tire you out. Let's use my REPEAT block! Set it to repeat 20 times and hit RUN CODE!"
    },
    hint: "Algorithm Hint: A 'for loop' repeats a block an exact number of times. Set repeat count to 20 to match the 20 trees ahead. The loop counter will manage each jump automatically!",
    failureMessage: "Your loop count didn't match the grove length! Check the tree count and try again.",
    successMessage: "Spectacular! 20 jumps executed with just 2 lines of code! That's the sheer power of algorithmic iteration!",
    recap: {
      conceptName: 'For Loop: Doing Repeated Work Effortlessly',
      simpleSummary: 'This is a LOOP. One action repeated again and again without rewriting the command.',
      pythonCode: [
        '# A for-loop repeats an indented block N times',
        'for i in range(20):',
        '    jump()  # repeats 20 times automatically!'
      ],
      jsCode: [
        '// A loop repeats a block N times',
        'for (let i = 0; i < 20; i++) {',
        '    jump(); // repeats 20 times automatically!',
        '}'
      ],
      explanationLines: [
        'The loop counter variable "i" starts at 0 and increments on each jump.',
        'When "i" reaches 20, the loop halts automatically.',
        'Time saved: We wrote 2 lines instead of 20 lines!'
      ]
    }
  },
  {
    id: 3,
    title: 'Level 3: Compound Actions',
    concept: 'Multi-Action Loop Body',
    subtitle: 'Repeat multiple actions in sequence: Jump + Collect Coin',
    type: 'compound_loop',
    targetCount: 10,
    treeCount: 10,
    speed: 340,
    coinPattern: 'on_tree',
    targetTime: 18,
    hasRiver: false,
    availableActions: ['jump', 'collect_coin', 'duck'],
    requiredActions: ['jump', 'collect_coin'],
    defaultLoopCount: 10,
    novaIntro: {
      mood: 'curious',
      message: "Floating above each of these 10 trees is an algorithmic energy crystal! Inside a loop, you can pack MULTIPLE commands. Arrange [jump] followed by [collect_coin], then run your loop!"
    },
    hint: "Algorithm Hint: Loops aren't limited to one command! Inside the loop body, code executes sequentially from top to bottom: 1. jump() vaults onto the canopy, then 2. collect_coin() harvests the crystal.",
    failureMessage: "Action sequence was incorrect! Remember: you must jump onto the canopy before you can grab the coin!",
    successMessage: "Double victory! Every tree was scaled and every coin scooped. Multiple instructions in a single loop body!",
    recap: {
      conceptName: 'Loop Body: Executing Multiple Instructions',
      simpleSummary: 'A loop can execute an entire block of instructions sequentially inside each iteration.',
      pythonCode: [
        '# Loop with two actions per iteration',
        'for tree in range(10):',
        '    jump()          # Step 1: leap over trunk',
        '    collect_coin()  # Step 2: grab crystal in midair'
      ],
      jsCode: [
        '// Loop with multiple statements in body',
        'for (let tree = 0; tree < 10; tree++) {',
        '    jump();',
        '    collectCoin();',
        '}'
      ],
      explanationLines: [
        'Each iteration executes all statements inside the block from top to bottom.',
        'First jump(), then collect_coin(), then the loop advances to the next iteration.',
        '10 iterations × 2 actions = 20 coordinated operations perfectly synchronized!'
      ]
    }
  },
  {
    id: 4,
    title: 'Level 4: The Nested Groves',
    concept: 'Nested Loops (Loops within Loops)',
    subtitle: 'Traverse 3 forest groves, with 4 trees in each grove',
    type: 'nested_loop',
    outerTarget: 3,
    innerTarget: 4,
    treeCount: 12,
    speed: 380,
    coinPattern: 'grove_end',
    targetTime: 20,
    hasRiver: false,
    defaultOuterCount: 1,
    defaultInnerCount: 1,
    novaIntro: {
      mood: 'surprised',
      message: "Look at the holographic radar! The forest is split into 3 distinct groves, and each grove contains exactly 4 trees! We need a NESTED LOOP: an outer loop for the groves, and an inner loop for the trees!"
    },
    hint: "Algorithm Hint: Use Nested Loops when dealing with grids or groups! The outer loop iterates through the 3 groves. For each grove, the inner loop repeats 4 jumps. Total jumps = 3 × 4 = 12!",
    failureMessage: "The mathematical loop product didn't match the forest topography! 3 groves × 4 trees = 12 trees.",
    successMessage: "Flawless nested iteration! You've mastered multidimensional loops. 3 × 4 = 12 trees conquered!",
    recap: {
      conceptName: 'Nested Loops: Multi-Layer Iteration',
      simpleSummary: 'A nested loop is a loop inside another loop. The inner loop completes ALL its iterations every time the outer loop ticks once.',
      pythonCode: [
        '# Outer loop runs 3 times (once per grove)',
        'for grove in range(3):',
        '    # Inner loop runs 4 times (once per tree in grove)',
        '    for tree in range(4):',
        '        jump()  # Total executions: 3 * 4 = 12 jumps!'
      ],
      jsCode: [
        'for (let grove = 0; grove < 3; grove++) {',
        '    for (let tree = 0; tree < 4; tree++) {',
        '        jump();',
        '    }',
        '}'
      ],
      explanationLines: [
        'Outer loop: "grove 0" -> Inner loop runs 4 times (tree 0, 1, 2, 3)',
        'Outer loop: "grove 1" -> Inner loop runs 4 times (tree 0, 1, 2, 3)',
        'Outer loop: "grove 2" -> Inner loop runs 4 times (tree 0, 1, 2, 3)',
        'Nested loops are essential for 2D grids, game boards, matrices, and image processing!'
      ]
    }
  },
  {
    id: 5,
    title: 'Level 5: The River of Infinity',
    concept: 'While Loop & Conditional Break',
    subtitle: 'Keep jumping while a tree is ahead; break when the river appears',
    type: 'while_loop',
    treeCount: 14,
    speed: 390,
    coinPattern: 'river_trail',
    targetTime: 24,
    hasRiver: true,
    riverPosition: 14, // after 14 trees
    novaIntro: {
      mood: 'serious',
      message: "Warning! Sensor alerts! There's an unknown count of trees followed by a raging cyber river! We cannot use a fixed count loop because we don't know the exact count in advance. We must use a WHILE LOOP!"
    },
    hint: "Algorithm Hint: When the end condition is unknown beforehand, use a 'while loop'. Set the condition to 'while tree_ahead(): jump()'. On loop finish, specify 'deploy_neon_bridge()' to safely cross!",
    failureMessage: "You plunged into the river! Remember to check for the river condition and halt jumping to cross the bridge!",
    successMessage: "Incredible! You adapted dynamically to unknown terrain with a while loop! You have earned the LOOP MASTER BADGE!",
    recap: {
      conceptName: 'While Loops: Condition-Driven Execution',
      simpleSummary: 'Unlike for-loops with a fixed count, a WHILE loop runs as long as a condition remains true, and stops when the condition changes.',
      pythonCode: [
        '# Keep looping as long as a tree is ahead',
        'while tree_ahead():',
        '    jump()',
        '',
        '# When tree_ahead() becomes False, we cross the river!',
        'deploy_neon_bridge()'
      ],
      jsCode: [
        'while (treeAhead()) {',
        '    jump();',
        '}',
        'deployNeonBridge();'
      ],
      explanationLines: [
        'Before every jump, the condition "tree_ahead()" is evaluated.',
        'True -> jump() is called.',
        'False (river reached!) -> loop terminates immediately and bridge is crossed safely.',
        'While loops are fundamental when waiting for events, user input, or unknown data streams!'
      ]
    }
  }
];

export const WORLDS = [
  {
    id: 'loop_forest',
    name: 'Loop Forest',
    dsaTopic: 'Loops & Iteration (For, Nested, While)',
    color: '#10b981',
    accentColor: '#34d399',
    description: 'Subway Surfers-style cyber runner. Vault trees and collect energy crystals by programming iterations!',
    totalLevels: 5,
    unlocked: true,
    badgeId: 'loop_master',
    badgeTitle: 'Loop Master',
    icon: 'Trees'
  },
  {
    id: 'stack_volcano',
    name: 'Stack Volcano',
    dsaTopic: 'Stacks (LIFO: Push & Pop)',
    color: '#ef4444',
    accentColor: '#f87171',
    description: 'Push and pop cooling basalt boulders to vent steam pressure before the caldera erupts!',
    totalLevels: 5,
    unlocked: false, // Unlocked upon completing Loop Forest
    unlockRequirement: 'Complete Loop Forest (Level 1-5)',
    badgeId: 'stack_climber',
    badgeTitle: 'Stack Climber',
    icon: 'Flame'
  },
  {
    id: 'queue_river',
    name: 'Queue River',
    dsaTopic: 'Queues (FIFO: Enqueue & Dequeue)',
    color: '#06b6d4',
    accentColor: '#38bdf8',
    description: 'Navigate algorithmic rapids by scheduling rafts in strictly first-in, first-out order.',
    totalLevels: 5,
    unlocked: false,
    unlockRequirement: 'Complete Stack Volcano',
    badgeId: 'queue_captain',
    badgeTitle: 'Queue Captain',
    icon: 'Waves'
  },
  {
    id: 'tree_valley',
    name: 'Tree Valley',
    dsaTopic: 'Binary Search Trees & Traversals',
    color: '#8b5cf6',
    accentColor: '#a78bfa',
    description: 'Branch left for smaller values, right for greater. Balance luminous crystal trees with BFS & DFS.',
    totalLevels: 5,
    unlocked: false,
    unlockRequirement: 'Complete Queue River',
    badgeId: 'tree_whisperer',
    badgeTitle: 'Tree Whisperer',
    icon: 'GitBranch'
  },
  {
    id: 'graph_city',
    name: 'Graph City',
    dsaTopic: 'Graphs & Dijkstra Shortest Path',
    color: '#ec4899',
    accentColor: '#f472b6',
    description: 'Route hyperloop pods across neon nodes using shortest path algorithms and minimum spanning trees.',
    totalLevels: 5,
    unlocked: false,
    unlockRequirement: 'Complete Tree Valley',
    badgeId: 'graph_navigator',
    badgeTitle: 'Graph Navigator',
    icon: 'Network'
  },
  {
    id: 'array_arena',
    name: 'Array Arena',
    dsaTopic: 'Arrays, Two-Pointers & Binary Search',
    color: '#f59e0b',
    accentColor: '#fbbf24',
    description: 'Zero-indexed colosseum battles! Shift, rotate, and binary search memory slots against rogue bots.',
    totalLevels: 5,
    unlocked: false,
    unlockRequirement: 'Complete Graph City',
    badgeId: 'array_gladiator',
    badgeTitle: 'Array Gladiator',
    icon: 'Boxes'
  }
];

export const OBJECT_KINGDOM_INFO = {
  id: 'object_kingdom',
  name: 'Object Kingdom (OOP)',
  description: 'Ancient citadel of Classes, Encapsulation, Polymorphism & Inheritance.',
  dialogMessage: 'We are still working on that! Continue with World Map.',
  backButtonText: 'Continue with World Map'
};
