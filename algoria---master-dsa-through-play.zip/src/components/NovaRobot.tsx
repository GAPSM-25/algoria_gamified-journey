import React from 'react';

interface NovaRobotProps {
  mood?: 'happy' | 'excited' | 'curious' | 'serious' | 'surprised' | 'proud';
  size?: number;
  isFloating?: boolean;
  className?: string;
  characterId?: string;
}

export const NovaRobot: React.FC<NovaRobotProps> = ({
  mood = 'happy',
  size = 72,
  isFloating = true,
  className = '',
  characterId = 'bit_byte'
}) => {
  // Determine eye color based on characterId
  const getEyeColor = () => {
    switch (characterId) {
      case 'algo_fox':
        return '#38bdf8'; // bright cyan on orange
      case 'cyber_nova':
        return '#f472b6'; // radiant pink on purple
      case 'pixel_knight':
        return '#6ee7b7'; // mint emerald
      case 'bit_byte':
      default:
        return '#22d3ee'; // cyber cyan
    }
  };

  const eyeColor = getEyeColor();

  // Render eyes based on mood
  const renderEyes = () => {
    switch (mood) {
      case 'happy':
        return (
          <>
            {/* Happy curved eyes ^^ */}
            <path d="M 18 22 Q 22 17 26 22" stroke={eyeColor} strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <path d="M 34 22 Q 38 17 42 22" stroke={eyeColor} strokeWidth="2.5" fill="none" strokeLinecap="round" />
          </>
        );
      case 'excited':
        return (
          <>
            {/* Starry glowing eyes */}
            <polygon points="22,17 23.5,21 28,21 24.5,23.5 26,28 22,25 18,28 19.5,23.5 16,21 20.5,21" fill={eyeColor} />
            <polygon points="38,17 39.5,21 44,21 40.5,23.5 42,28 38,25 34,28 35.5,23.5 32,21 36.5,21" fill={eyeColor} />
          </>
        );
      case 'surprised':
        return (
          <>
            {/* Big round wide eyes OO */}
            <circle cx="22" cy="22" r="4.5" fill={eyeColor} />
            <circle cx="38" cy="22" r="4.5" fill={eyeColor} />
            <circle cx="23.5" cy="20.5" r="1.5" fill="#ffffff" />
            <circle cx="39.5" cy="20.5" r="1.5" fill="#ffffff" />
          </>
        );
      case 'curious':
        return (
          <>
            {/* One tilted eye, one round */}
            <ellipse cx="21" cy="22" rx="3.5" ry="4" fill={eyeColor} />
            <line x1="33" y1="20" x2="41" y2="24" stroke={eyeColor} strokeWidth="3" strokeLinecap="round" />
          </>
        );
      case 'proud':
        return (
          <>
            {/* Sparkling confident eyes */}
            <path d="M 17 23 Q 22 18 27 23" stroke={eyeColor} strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <circle cx="38" cy="22" r="3.5" fill={eyeColor} />
            <circle cx="39.5" cy="20.5" r="1.2" fill="#ffffff" />
          </>
        );
      case 'serious':
      default:
        return (
          <>
            {/* Focused horizontal laser slits */}
            <rect x="18" y="20.5" width="9" height="3.5" rx="1.5" fill={eyeColor} />
            <rect x="33" y="20.5" width="9" height="3.5" rx="1.5" fill={eyeColor} />
          </>
        );
    }
  };

  // Render character-specific robotic chassis
  const renderChassis = () => {
    switch (characterId) {
      case 'algo_fox':
        return (
          <>
            {/* Robot Fox Ears with glowing inner grid */}
            <polygon points="12,18 4,1 22,9" fill="#ea580c" stroke="#f97316" strokeWidth="1.5" />
            <polygon points="13,15 8,4 20,10" fill="#fef08a" opacity="0.9" />
            <polygon points="48,18 56,1 38,9" fill="#ea580c" stroke="#f97316" strokeWidth="1.5" />
            <polygon points="47,15 52,4 40,10" fill="#fef08a" opacity="0.9" />

            {/* Fox Head Chassis */}
            <path
              d="M 12 14 L 48 14 Q 54 26 48 38 L 30 50 L 12 38 Q 6 26 12 14 Z"
              fill="url(#foxNovaHeadGrad)"
              stroke="#ea580c"
              strokeWidth="2"
            />

            {/* Neon Cyber Whiskers */}
            <line x1="6" y1="30" x2="16" y2="30" stroke="#38bdf8" strokeWidth="1.75" strokeLinecap="round" />
            <line x1="8" y1="35" x2="18" y2="34" stroke="#38bdf8" strokeWidth="1.75" strokeLinecap="round" />
            <line x1="54" y1="30" x2="44" y2="30" stroke="#38bdf8" strokeWidth="1.75" strokeLinecap="round" />
            <line x1="52" y1="35" x2="42" y2="34" stroke="#38bdf8" strokeWidth="1.75" strokeLinecap="round" />

            {/* Visor Area */}
            <rect x="14" y="15" width="32" height="17" rx="6" fill="#090514" stroke="#f59e0b" strokeWidth="1.2" />

            {/* Antenna between ears */}
            <line x1="30" y1="14" x2="30" y2="5" stroke="#f97316" strokeWidth="2" strokeLinecap="round" />
            <circle cx="30" cy="4" r="2.5" fill="#fef08a" filter="url(#novaGlow)" />

            {/* Core / Thruster */}
            <polygon points="25,50 35,50 30,58" fill="url(#foxThrusterGrad)" opacity="0.9" />
          </>
        );

      case 'cyber_nova':
        return (
          <>
            {/* Cosmic Orbital Ring (tilted ellipse) */}
            <ellipse
              cx="30"
              cy="28"
              rx="28"
              ry="10"
              fill="none"
              stroke="#e879f9"
              strokeWidth="2"
              strokeDasharray="4 2"
              transform="rotate(-18 30 28)"
            />

            {/* Floating Energy Crystal Horns */}
            <polygon points="18,14 22,2 25,14" fill="#c084fc" stroke="#f472b6" strokeWidth="1" />
            <polygon points="42,14 38,2 35,14" fill="#c084fc" stroke="#f472b6" strokeWidth="1" />
            <polygon points="30,10 28,1 32,1" fill="#f472b6" />

            {/* Cosmic Orb Head */}
            <circle cx="30" cy="27" r="19" fill="url(#cyberNovaHeadGrad)" stroke="#c084fc" strokeWidth="2" />

            {/* Stellar Visor */}
            <ellipse cx="30" cy="26" rx="14" ry="8.5" fill="#070214" stroke="#f472b6" strokeWidth="1.5" />

            {/* Orbiting stellar particles */}
            <circle cx="10" cy="22" r="1.5" fill="#f472b6" />
            <circle cx="50" cy="34" r="1.5" fill="#e879f9" />

            {/* Quantum Core / Thruster */}
            <polygon points="26,46 34,46 30,56" fill="url(#cosmicThrusterGrad)" opacity="0.9" />
          </>
        );

      case 'pixel_knight':
        return (
          <>
            {/* Golden Crest Plume */}
            <path d="M 28 12 C 28 3 32 3 32 12" stroke="#fbbf24" strokeWidth="3.5" strokeLinecap="round" />
            <polygon points="26,6 30,1 34,6" fill="#f59e0b" />

            {/* Armored Knight Helm Shell */}
            <path
              d="M 12 24 C 12 14 20 11 30 11 C 40 11 48 14 48 24 L 48 42 C 48 48 40 51 30 51 C 20 51 12 48 12 42 Z"
              fill="url(#knightNovaHeadGrad)"
              stroke="#34d399"
              strokeWidth="2"
            />

            {/* Knight T-Slit Visor Frame */}
            <rect x="14" y="16" width="32" height="15" rx="5" fill="#022c22" stroke="#10b981" strokeWidth="1.2" />
            <line x1="30" y1="16" x2="30" y2="35" stroke="#021f18" strokeWidth="4" />

            {/* Ear plates */}
            <rect x="9" y="24" width="4" height="12" rx="2" fill="#064e3b" stroke="#34d399" strokeWidth="1" />
            <rect x="47" y="24" width="4" height="12" rx="2" fill="#064e3b" stroke="#34d399" strokeWidth="1" />

            {/* Emerald Core & Thruster */}
            <polygon points="25,51 35,51 30,57" fill="url(#knightThrusterGrad)" opacity="0.9" />
          </>
        );

      case 'bit_byte':
      default:
        return (
          <>
            {/* Antenna */}
            <line x1="30" y1="12" x2="30" y2="4" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="30" cy="3" r="3" fill="#22d3ee" filter="url(#novaGlow)" />
            <circle cx="30" cy="3" r="1.5" fill="#ffffff" />

            {/* Head Shell */}
            <rect
              x="10"
              y="11"
              width="40"
              height="32"
              rx="12"
              fill="url(#novaHeadGrad)"
              stroke="#06b6d4"
              strokeWidth="1.75"
            />

            {/* Side Ear Antennas / Bolts */}
            <circle cx="8" cy="27" r="2.5" fill="#06b6d4" />
            <circle cx="52" cy="27" r="2.5" fill="#06b6d4" />

            {/* Visor Screen */}
            <rect
              x="14"
              y="15"
              width="32"
              height="17"
              rx="6"
              fill="url(#novaVisorGrad)"
              stroke="#0284c7"
              strokeWidth="1"
            />

            {/* Cheek data circuits */}
            <line x1="13" y1="35" x2="19" y2="35" stroke="#06b6d4" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="41" y1="35" x2="47" y2="35" stroke="#06b6d4" strokeWidth="1.5" strokeLinecap="round" />

            {/* Chest Plate / Core */}
            <path
              d="M 22 43 L 38 43 L 34 50 L 26 50 Z"
              fill="#082f49"
              stroke="#06b6d4"
              strokeWidth="1.2"
            />
            <circle cx="30" cy="46" r="2" fill="#22d3ee" filter="url(#novaGlow)" />

            {/* Thruster Flames */}
            <polygon
              points="27,51 33,51 30,57"
              fill="url(#novaThrusterGrad)"
              opacity="0.85"
            />
          </>
        );
    }
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center ${isFloating ? 'animate-bounce-gentle' : ''} ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 60 60"
        width={size}
        height={size}
        className="filter drop-shadow-[0_0_12px_rgba(6,182,212,0.45)] overflow-visible"
      >
        <defs>
          {/* Bit Byte Gradients */}
          <linearGradient id="novaHeadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0369a1" />
            <stop offset="50%" stopColor="#082f49" />
            <stop offset="100%" stopColor="#021324" />
          </linearGradient>
          <linearGradient id="novaVisorGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#030712" />
            <stop offset="100%" stopColor="#082f49" />
          </linearGradient>
          <linearGradient id="novaThrusterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>

          {/* Algo Fox Gradients */}
          <linearGradient id="foxNovaHeadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ea580c" />
            <stop offset="50%" stopColor="#9a3412" />
            <stop offset="100%" stopColor="#1c0b05" />
          </linearGradient>
          <linearGradient id="foxThrusterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#f97316" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>

          {/* Cyber Nova Gradients */}
          <linearGradient id="cyberNovaHeadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#7e22ce" />
            <stop offset="50%" stopColor="#3b0764" />
            <stop offset="100%" stopColor="#120421" />
          </linearGradient>
          <linearGradient id="cosmicThrusterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ec4899" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>

          {/* Pixel Knight Gradients */}
          <linearGradient id="knightNovaHeadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#047857" />
            <stop offset="50%" stopColor="#064e3b" />
            <stop offset="100%" stopColor="#021c15" />
          </linearGradient>
          <linearGradient id="knightThrusterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>

          <filter id="novaGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Chassis body */}
        {renderChassis()}

        {/* Expressive Eyes placed over visor */}
        <g filter="url(#novaGlow)">
          {renderEyes()}
        </g>
      </svg>
    </div>
  );
};
