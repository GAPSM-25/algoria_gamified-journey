import React from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Anchor, Crown, Ship, Sparkles } from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface QueueControlPanelProps {
  levelId: number;
  levelType: string;
  onSnakeDirection?: (dir: 'up' | 'down' | 'left' | 'right') => void;
  onDispatchBoat?: (boatId?: string) => void;
  queueItems?: any[];
  lastAction?: string;
  targetCount: number;
  currentCount: number;
}

export const QueueControlPanel: React.FC<QueueControlPanelProps> = ({
  levelId,
  levelType,
  onSnakeDirection,
  onDispatchBoat,
  queueItems = [],
  lastAction = 'IDLE',
  targetCount,
  currentCount
}) => {
  const isSnakeMode = levelType === 'snake_queue';
  const isPriorityMode = levelType === 'priority_queue';

  // ==========================================
  // LEVEL 1 & 2: SNAKE QUEUE CONTROLS
  // ==========================================
  if (isSnakeMode) {
    return (
      <div className="p-3 sm:p-4 bg-slate-900/95 border border-cyan-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        {/* Top Info Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-cyan-500/20 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-cyan-400 font-bold">QUEUE DATA STRUCTURE</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-300">FIFO Snake Buffer</span>
          </div>
          <div className="font-mono text-slate-300">
            Crystals Eaten: <span className="text-cyan-300 font-bold">{currentCount}/{targetCount}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Live Queue Ribbon */}
          <div className="md:col-span-7 bg-slate-950/80 p-3 rounded-xl border border-slate-800 flex flex-col justify-between gap-2">
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span className="text-pink-400 font-semibold">◀ FRONT [DEQUEUE]</span>
              <span className="text-cyan-400 font-semibold">REAR [ENQUEUE] ▶</span>
            </div>

            {/* Visual Queue Cells */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-0.5">
              {queueItems.length > 0 ? (
                queueItems.map((item, idx) => {
                  const isFront = idx === 0;
                  const isRear = idx === queueItems.length - 1;
                  return (
                    <div
                      key={item.id || idx}
                      className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono font-bold flex-shrink-0 transition-all ${
                        isFront
                          ? 'bg-pink-950/70 border-pink-500 text-pink-300 shadow-sm shadow-pink-500/30'
                          : isRear
                          ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/30'
                          : 'bg-slate-900/80 border-slate-700 text-purple-300'
                      }`}
                    >
                      {isFront ? 'FRONT' : isRear ? 'REAR' : `#${idx}`}
                    </div>
                  );
                })
              ) : (
                <div className="text-xs text-slate-500 font-mono italic">Waiting for queue stream...</div>
              )}
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Oldest tail leaves on move</span>
              <span className="text-cyan-400/80">Last: {lastAction}</span>
              <span>New head enters on step</span>
            </div>
          </div>

          {/* D-Pad Controls for Mobile / Touch */}
          <div className="md:col-span-5 flex flex-col items-center justify-center">
            <div className="text-[11px] text-slate-400 mb-1 text-center font-mono">
              Steer: <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-cyan-300">WASD</kbd> or <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-cyan-300">Arrows</kbd>
            </div>

            {/* Interactive D-Pad */}
            <div className="grid grid-cols-3 gap-1.5 w-36">
              <div />
              <button
                onClick={() => {
                  playButtonClick();
                  onSnakeDirection?.('up');
                }}
                className="w-11 h-11 bg-slate-800 hover:bg-cyan-950 border border-cyan-500/40 hover:border-cyan-400 active:scale-90 text-cyan-300 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md"
                title="Up"
              >
                <ArrowUp className="w-5 h-5 stroke-[2.5]" />
              </button>
              <div />

              <button
                onClick={() => {
                  playButtonClick();
                  onSnakeDirection?.('left');
                }}
                className="w-11 h-11 bg-slate-800 hover:bg-cyan-950 border border-cyan-500/40 hover:border-cyan-400 active:scale-90 text-cyan-300 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md"
                title="Left"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
              </button>
              <button
                onClick={() => {
                  playButtonClick();
                  onSnakeDirection?.('down');
                }}
                className="w-11 h-11 bg-slate-800 hover:bg-cyan-950 border border-cyan-500/40 hover:border-cyan-400 active:scale-90 text-cyan-300 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md"
                title="Down"
              >
                <ArrowDown className="w-5 h-5 stroke-[2.5]" />
              </button>
              <button
                onClick={() => {
                  playButtonClick();
                  onSnakeDirection?.('right');
                }}
                className="w-11 h-11 bg-slate-800 hover:bg-cyan-950 border border-cyan-500/40 hover:border-cyan-400 active:scale-90 text-cyan-300 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md"
                title="Right"
              >
                <ArrowRight className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // LEVEL 3 & 4: FIFO RIVER BOATS
  // ==========================================
  if (!isPriorityMode) {
    const frontBoat = queueItems[0];

    return (
      <div className="p-3 sm:p-4 bg-slate-900/95 border border-cyan-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-cyan-500/20 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-cyan-400 font-bold">MARINA HARBOR QUEUE</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-300">FIFO Line Dispatch</span>
          </div>
          <div className="font-mono text-slate-300">
            Dispatched: <span className="text-cyan-300 font-bold">{currentCount}/{targetCount} Boats</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Waiting Queue List */}
          <div className="md:col-span-8 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2">
              <span className="text-pink-400 font-semibold">◀ FRONT (Dock 1 · Dequeue)</span>
              <span className="text-cyan-400 font-semibold">REAR (Arrivals) ▶</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto py-1">
              {queueItems.map((boat, idx) => {
                const isFront = idx === 0;
                return (
                  <button
                    key={boat.id}
                    onClick={() => {
                      playButtonClick();
                      onDispatchBoat?.(boat.id);
                    }}
                    className={`p-2.5 rounded-xl border text-left flex flex-col gap-1 transition-all flex-shrink-0 cursor-pointer active:scale-95 ${
                      isFront
                        ? 'bg-pink-950/70 border-pink-500 hover:border-pink-400 text-white shadow-md shadow-pink-500/20'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-400 opacity-80'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold font-mono">
                      <Ship className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{boat.label}</span>
                    </div>
                    <div className="text-[10px] font-mono">
                      {isFront ? (
                        <span className="text-pink-300 font-semibold">● READY AT FRONT</span>
                      ) : (
                        <span className="text-slate-500">Waiting in line (#{idx + 1})</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Button */}
          <div className="md:col-span-4 flex flex-col gap-2">
            <button
              onClick={() => {
                playButtonClick();
                onDispatchBoat?.();
              }}
              disabled={queueItems.length === 0}
              className="w-full py-4 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-500 hover:from-pink-500 hover:to-cyan-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-pink-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 select-none"
            >
              <Anchor className="w-5 h-5 stroke-[2.5]" />
              <span>DISPATCH FRONT BOAT</span>
            </button>
            <p className="text-[10px] text-slate-400 text-center font-mono">
              Tap the FRONT vessel or click the button!
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // LEVEL 5: PRIORITY QUEUE (VIP FIRST)
  // ==========================================
  return (
    <div className="p-3 sm:p-4 bg-slate-900/95 border border-amber-500/40 rounded-2xl shadow-xl backdrop-blur-md">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-amber-500/20 text-xs">
        <div className="flex items-center gap-2">
          <Crown className="w-4 h-4 text-amber-400" />
          <span className="text-amber-400 font-bold">PRIORITY QUEUE SCHEDULER</span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-300">VIP Emergency Overrides</span>
        </div>
        <div className="font-mono text-slate-300">
          Dispatched: <span className="text-amber-300 font-bold">{currentCount}/{targetCount} Vessels</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        {/* Waiting Vessels by Priority */}
        <div className="md:col-span-8 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2">
            <span className="text-amber-400 font-semibold flex items-center gap-1">
              <Crown className="w-3 h-3 text-amber-400" />
              Highest Priority (Priority 1 [VIP] First)
            </span>
            <span className="text-slate-400">Tap vessel to dispatch</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto py-1">
            {queueItems.map((boat) => {
              const isP1 = boat.priority === 1;
              const isP2 = boat.priority === 2;

              return (
                <button
                  key={boat.id}
                  onClick={() => {
                    playButtonClick();
                    onDispatchBoat?.(boat.id);
                  }}
                  className={`p-2.5 rounded-xl border text-left flex flex-col gap-1 transition-all flex-shrink-0 cursor-pointer active:scale-95 ${
                    isP1
                      ? 'bg-amber-950/70 border-amber-400 hover:border-amber-300 text-white shadow-md shadow-amber-500/20'
                      : isP2
                      ? 'bg-purple-950/70 border-purple-500 hover:border-purple-400 text-slate-200'
                      : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold font-mono">
                    {isP1 ? (
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                    ) : (
                      <Ship className="w-3.5 h-3.5 text-slate-400" />
                    )}
                    <span>{boat.label}</span>
                  </div>

                  <div className="flex items-center justify-between gap-2 text-[10px] font-mono">
                    <span
                      className={`px-1.5 py-0.5 rounded font-bold ${
                        isP1
                          ? 'bg-amber-500 text-slate-950'
                          : isP2
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {isP1 ? 'P1 · VIP' : isP2 ? 'P2 · Express' : 'P3 · Standard'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Priority Dispatch Button */}
        <div className="md:col-span-4 flex flex-col gap-2">
          <button
            onClick={() => {
              playButtonClick();
              onDispatchBoat?.();
            }}
            disabled={queueItems.length === 0}
            className="w-full py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-pink-500 hover:from-amber-400 hover:to-pink-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 select-none"
          >
            <Sparkles className="w-5 h-5 fill-current" />
            <span>DISPATCH TOP PRIORITY</span>
          </button>
          <p className="text-[10px] text-amber-300/80 text-center font-mono">
            P1 (VIP) vessels take precedence over P2 and P3!
          </p>
        </div>
      </div>
    </div>
  );
};
