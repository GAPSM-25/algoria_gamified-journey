import React, { useState } from 'react';
import { ArrowDown, ArrowUp, Eye, Undo2, Flame, Layers } from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface StackControlPanelProps {
  levelId: number;
  levelType: string;
  currentStack: any[];
  onPush: (rockData: any) => void;
  onPop: () => void;
  onPeek: () => void;
  peekedItem: any | null;
}

export const StackControlPanel: React.FC<StackControlPanelProps> = ({
  levelId,
  levelType,
  currentStack,
  onPush,
  onPop,
  onPeek,
  peekedItem
}) => {
  // Level 1 Next Available Rock
  const level1Rocks = [
    { id: 'r1', label: 'Basalt 1', color: '#f97316' },
    { id: 'r2', label: 'Basalt 2', color: '#ea580c' },
    { id: 'r3', label: 'Basalt 3', color: '#c2410c' }
  ];

  // Level 5 Word Reversal state
  const wordLetters = ['N', 'O', 'V', 'A'];
  const [lettersPushedCount, setLettersPushedCount] = useState<number>(0);
  const [poppedLetters, setPoppedLetters] = useState<string[]>([]);

  // Handle Level 1 Push
  const handleLevel1Push = () => {
    playButtonClick();
    if (currentStack.length < level1Rocks.length) {
      const nextRock = level1Rocks[currentStack.length];
      onPush(nextRock);
    }
  };

  // Handle Level 5 Push
  const handleLevel5Push = () => {
    playButtonClick();
    if (lettersPushedCount < wordLetters.length) {
      const char = wordLetters[lettersPushedCount];
      setLettersPushedCount((prev) => prev + 1);
      onPush({ id: `letter_${char}`, label: char, color: '#f59e0b' });
    }
  };

  // Handle Level 5 Pop
  const handleLevel5Pop = () => {
    playButtonClick();
    if (currentStack.length > 0) {
      const top = currentStack[currentStack.length - 1];
      setPoppedLetters((prev) => [...prev, top.label]);
      onPop();
    }
  };

  return (
    <div className="p-4 bg-slate-900/95 border border-orange-500/40 rounded-2xl shadow-xl backdrop-blur-md">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-orange-500/20 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-orange-400 font-bold flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            LIFO STACK CONTROLLER
          </span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-300">Last-In, First-Out Memory Pointer</span>
        </div>

        <div className="text-slate-400 font-mono">
          Stack Size: <span className="text-cyan-300 font-bold">{currentStack.length}</span> items
        </div>
      </div>

      {/* LEVEL 1: Push 3 Basalt Rocks */}
      {levelId === 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-300">
              Goal: Push 3 basalt rocks onto the stack tower
            </div>
            <div className="text-xs text-orange-400 font-mono mt-0.5">
              Next to push:{' '}
              <strong>
                {currentStack.length < 3 ? level1Rocks[currentStack.length].label : 'Tower Complete!'}
              </strong>
            </div>
          </div>

          <button
            onClick={handleLevel1Push}
            disabled={currentStack.length >= 3}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <ArrowDown className="w-5 h-5 stroke-[2.5]" />
            <span>PUSH ROCK ({currentStack.length}/3)</span>
          </button>
        </div>
      )}

      {/* LEVEL 2: Pop Unstable Top Rock */}
      {levelId === 2 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs text-red-400 font-bold flex items-center gap-1.5">
              <Flame className="w-4 h-4 animate-pulse" />
              <span>Magma Alert: Top Rock is Superheated!</span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              In a stack, only the TOP rock can be removed. Tap POP to vent the unstable rock!
            </p>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onPop();
            }}
            disabled={currentStack.length <= 2}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-red-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <ArrowUp className="w-5 h-5 stroke-[2.5]" />
            <span>POP TOP ROCK</span>
          </button>
        </div>
      )}

      {/* LEVEL 3: Peek Thermal Inspection */}
      {levelId === 3 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs text-cyan-300 font-bold flex items-center gap-1.5">
              <Eye className="w-4 h-4" />
              <span>Peek Operation · Inspect Without Removing</span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Read top rock value without reducing stack size.
            </p>
            {peekedItem && (
              <div className="text-xs text-yellow-300 font-mono mt-1">
                Reading: {peekedItem.label} · 1200°C (Safe)
              </div>
            )}
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onPeek();
            }}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Eye className="w-5 h-5" />
            <span>PEEK TOP ROCK</span>
          </button>
        </div>
      )}

      {/* LEVEL 4: Undo Action History */}
      {levelId === 4 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs text-lime-400 font-bold flex items-center gap-1.5">
              <Undo2 className="w-4 h-4" />
              <span>Undo Mechanism (Ctrl+Z)</span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              "Toxic Slag" is at top of the stack. Tap UNDO (POP) to revert to the safe state!
            </p>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onPop();
            }}
            disabled={currentStack.length <= 3}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-lime-600 to-emerald-600 hover:from-lime-500 hover:to-emerald-500 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-lime-500/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Undo2 className="w-5 h-5" />
            <span>UNDO (POP)</span>
          </button>
        </div>
      )}

      {/* LEVEL 5: Word Reversal with Stack */}
      {levelId === 5 && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-300">
              Input Word: <strong className="text-amber-400 font-mono">N - O - V - A</strong>
            </span>
            <div className="text-cyan-300 font-mono">
              Reversed Output:{' '}
              <strong>
                {poppedLetters.length > 0 ? poppedLetters.join(' - ') : '(Awaiting pops...)'}
              </strong>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Step 1: Push next letter */}
            <button
              onClick={handleLevel5Push}
              disabled={lettersPushedCount >= wordLetters.length}
              className="flex-1 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
            >
              <ArrowDown className="w-4 h-4" />
              <span>
                {lettersPushedCount < wordLetters.length
                  ? `PUSH '${wordLetters[lettersPushedCount]}'`
                  : 'All Pushed!'}
              </span>
            </button>

            {/* Step 2: Pop letter to reverse */}
            <button
              onClick={handleLevel5Pop}
              disabled={currentStack.length === 0}
              className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
            >
              <ArrowUp className="w-4 h-4" />
              <span>POP LETTER</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
