import React from 'react';
import {
  Network,
  ArrowRight,
  ShieldAlert,
  Zap,
  Layers,
  GitCommit,
  Flame,
  CheckCircle2,
  Compass
} from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface GraphControlPanelProps {
  levelId: number;
  levelType: string;
  currentNodeId: string;
  availableNeighbors: string[];
  visitedNodes: string[];
  accumulatedCost?: number;
  optimalCost?: number;
  safeZoneRadius?: number;
  isOutsideZone?: boolean;
  targetCount: number;
  currentCount: number;
  nodes: Array<{ id: string; label: string; hasEnergy?: boolean; isExit?: boolean; layer?: number; depth?: number; branch?: string }>;
  edges: Array<{ from: string; to: string; weight?: number }>;
  bfsQueue?: string[];
  dfsStack?: string[];
  onMoveToNode: (targetNodeId: string) => void;
}

export const GraphControlPanel: React.FC<GraphControlPanelProps> = ({
  levelId,
  levelType,
  currentNodeId,
  availableNeighbors = [],
  visitedNodes = [],
  accumulatedCost = 0,
  optimalCost = 9,
  safeZoneRadius = 260,
  isOutsideZone = false,
  targetCount,
  currentCount,
  nodes = [],
  edges = [],
  bfsQueue = [],
  dfsStack = [],
  onMoveToNode
}) => {
  const currentNode = nodes.find((n) => n.id === currentNodeId);
  const isExplore = levelType === 'graph_explore';
  const isBfs = levelType === 'bfs_traversal';
  const isDfs = levelType === 'dfs_traversal';
  const isDijkstra = levelType === 'dijkstra_shortest_path';
  const isAvoidVisited = levelType === 'avoid_visited_nodes';

  const getNodeLabel = (id: string) => {
    const n = nodes.find((node) => node.id === id);
    return n ? n.label : id;
  };

  const getEdgeWeight = (fromId: string, toId: string) => {
    const e = edges.find(
      (edge) => (edge.from === fromId && edge.to === toId) || (edge.from === toId && edge.to === fromId)
    );
    return e?.weight;
  };

  return (
    <div className="bg-slate-900/95 border border-pink-500/30 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-md flex flex-col gap-4">
      {/* Top Status Bar: Current Node & Safe Zone Indicator */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-pink-500/20 text-xs sm:text-sm">
        {/* Current Node Telemetry */}
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-pink-500/10 border border-pink-500/30 text-pink-400">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
              Current Location
            </div>
            <div className="font-mono font-bold text-white flex items-center gap-2">
              <span className="text-pink-300">{currentNode ? currentNode.label : currentNodeId}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                {availableNeighbors.length} Roads Connected
              </span>
            </div>
          </div>
        </div>

        {/* Safe Zone Alert & Objective Progress */}
        <div className="flex items-center gap-3">
          {/* Safe Zone Perimeter Meter */}
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border font-mono transition-colors ${
              isOutsideZone
                ? 'bg-red-950/80 border-red-500 text-red-300 animate-pulse'
                : 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
            }`}
          >
            <ShieldAlert className={`w-4 h-4 ${isOutsideZone ? 'text-red-400' : 'text-cyan-400'}`} />
            <div>
              <div className="text-[9px] uppercase tracking-wider">
                {isOutsideZone ? 'STORM HAZARD!' : 'Safe Zone'}
              </div>
              <div className="text-xs font-bold">R = {safeZoneRadius}px</div>
            </div>
          </div>

          {/* Target Progress */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 font-mono">
            <Zap className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Energy Cells</div>
              <div className="text-xs font-bold text-amber-300">
                {currentCount} / {targetCount}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic Algorithmic HUD: BFS Queue / DFS Stack / Dijkstra Weight / Visited Sets */}
      {isBfs && (
        <div className="bg-slate-950/70 border border-cyan-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
              BFS Queue (FIFO):
            </span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1">
            <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
              FRONT
            </span>
            {bfsQueue.length > 0 ? (
              bfsQueue.map((id, idx) => (
                <div
                  key={id}
                  className={`text-xs font-mono px-2 py-1 rounded border flex items-center gap-1 ${
                    idx === 0
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span>{getNodeLabel(id)}</span>
                </div>
              ))
            ) : (
              <span className="text-xs text-slate-500 italic">Queue Empty (All Rings Processed)</span>
            )}
            <span className="text-[10px] text-purple-400 font-mono font-bold bg-purple-950/80 px-2 py-0.5 rounded border border-purple-500/30">
              REAR
            </span>
          </div>
        </div>
      )}

      {isDfs && (
        <div className="bg-slate-950/70 border border-purple-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <GitCommit className="w-4 h-4 text-purple-400" />
            <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
              DFS Call Stack (LIFO):
            </span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1">
            <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/30">
              TOP (Deepest)
            </span>
            {dfsStack.slice(-4).map((id, idx) => (
              <div
                key={`${id}_${idx}`}
                className="text-xs font-mono px-2 py-1 rounded border bg-purple-950/60 border-purple-500/40 text-purple-200"
              >
                {getNodeLabel(id)}
              </div>
            ))}
            <span className="text-[10px] text-slate-500 font-mono font-bold">BOTTOM</span>
          </div>
        </div>
      )}

      {isDijkstra && (
        <div className="bg-slate-950/70 border border-rose-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-rose-400" />
            <span className="text-xs font-bold text-rose-300 uppercase tracking-wider">
              Dijkstra Cost Accumulator:
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div>
              Current Path Cost:{' '}
              <span className="font-bold text-rose-300">{accumulatedCost}</span>
            </div>
            <div>
              Target Optimal:{' '}
              <span className="font-bold text-emerald-400">≤ {optimalCost}</span>
            </div>
          </div>
        </div>
      )}

      {isAvoidVisited && (
        <div className="bg-slate-950/70 border border-red-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-red-400" />
            <span className="text-xs font-bold text-red-300 uppercase tracking-wider">
              Active Visited Set (Nodes Collapse on Exit):
            </span>
          </div>
          <div className="text-xs font-mono text-slate-300 flex items-center gap-1 flex-wrap">
            {`{ `}
            {visitedNodes.map((id) => getNodeLabel(id)).join(', ')}
            {` }`}
          </div>
        </div>
      )}

      {/* Action Area: Connected Roads / Jump Selection Buttons */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Network className="w-4 h-4 text-pink-400" />
            <span>Select Connected Road to Travel:</span>
          </span>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            (Or tap directly on glowing node in the map)
          </span>
        </div>

        {availableNeighbors.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {availableNeighbors.map((neighborId) => {
              const neighborNode = nodes.find((n) => n.id === neighborId);
              const weight = getEdgeWeight(currentNodeId, neighborId);
              const isVisited = visitedNodes.includes(neighborId);

              return (
                <button
                  key={neighborId}
                  onClick={() => {
                    playButtonClick();
                    onMoveToNode(neighborId);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all active:scale-95 cursor-pointer flex flex-col justify-between gap-1 shadow-md ${
                    neighborNode?.isExit
                      ? 'bg-amber-950/60 border-amber-500/60 hover:bg-amber-900/80 text-amber-200'
                      : isVisited
                      ? 'bg-slate-950 border-slate-800 hover:border-pink-500/40 text-slate-400'
                      : 'bg-gradient-to-r from-pink-950/40 to-purple-950/40 border-pink-500/40 hover:border-pink-400 hover:from-pink-900/60 hover:to-purple-900/60 text-pink-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-xs truncate">
                      {neighborNode ? neighborNode.label : neighborId}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 opacity-70 shrink-0" />
                  </div>

                  <div className="flex items-center gap-1 text-[10px] font-mono">
                    {weight !== undefined && (
                      <span className="px-1.5 py-0.2 bg-rose-950/90 border border-rose-500/50 rounded text-rose-300 font-bold">
                        Cost: {weight}
                      </span>
                    )}
                    {neighborNode?.hasEnergy && (
                      <span className="text-amber-300">★ Cell</span>
                    )}
                    {neighborNode?.isExit && (
                      <span className="text-amber-400 font-bold">Safe Exit</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-950 border border-red-500/30 text-center text-xs text-red-300 font-mono">
            No valid uncollapsed roads available from this location!
          </div>
        )}
      </div>
    </div>
  );
};
