import React from 'react';
import confetti from 'canvas-confetti';
import {
  Flame,
  X,
  Sparkles,
  CheckCircle2,
  Calendar,
  Gift,
  Zap,
  Info
} from 'lucide-react';
import { playButtonClick, playDustRewardSound } from '../utils/audio.ts';
import { getDustRewardForStreak, STREAK_DUST_REWARDS } from '../api/gameApi.js';

interface StreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  streakCount?: number;
  streakDays?: number;
  algoriaDust?: number;
  hasClaimedToday?: boolean;
  onClaimDustReward?: () => void;
  onClaimBonus?: (bonusXp: number) => void; // backwards compatibility
}

export const StreakModal: React.FC<StreakModalProps> = ({
  isOpen,
  onClose,
  streakCount,
  streakDays,
  algoriaDust = 0,
  hasClaimedToday = false,
  onClaimDustReward,
  onClaimBonus
}) => {
  if (!isOpen) return null;

  const currentStreak = Math.max(1, streakCount || streakDays || 1);
  const todaysDustReward = getDustRewardForStreak(currentStreak);

  // 7-Day reward track definitions
  const days = [
    { day: 1, reward: '+50 Dust', amount: 50 },
    { day: 2, reward: '+75 Dust', amount: 75 },
    { day: 3, reward: '+100 Dust', amount: 100 },
    { day: 4, reward: '+140 Dust', amount: 140 },
    { day: 5, reward: '+180 Dust', amount: 180 },
    { day: 6, reward: '+240 Dust', amount: 240 },
    { day: 7, reward: '+350 Dust', amount: 350, isJackpot: true }
  ];

  const handleClaim = () => {
    playDustRewardSound();
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#38bdf8', '#fbbf24', '#f97316']
      });
    } catch {}

    if (onClaimDustReward) {
      onClaimDustReward();
    } else if (onClaimBonus) {
      onClaimBonus(todaysDustReward);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl bg-slate-950/95 border border-cyan-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-2xl flex flex-col text-center overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-24 bg-gradient-to-b from-orange-500/20 via-cyan-500/10 to-transparent blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            playButtonClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Icon & Total Dust Balance */}
        <div className="flex flex-col items-center mb-4">
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-600/30 to-amber-500/20 border border-orange-500/50 flex items-center justify-center text-orange-400 shadow-lg shadow-orange-500/20 mb-3">
            <Flame className="w-9 h-9 fill-orange-400 text-orange-400 animate-pulse" />
            <div className="absolute -top-1 -right-1 p-1 bg-cyan-500 rounded-full text-slate-950 shadow-sm">
              <Sparkles className="w-3 h-3 text-slate-950" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-cyan-950/70 border border-cyan-500/40 rounded-full text-cyan-300 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
            <span>Balance: <strong className="font-mono text-cyan-200">{algoriaDust}</strong> Algoria Dust</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {currentStreak}-Day Streak Active!
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-md">
            Log in daily to earn precious <strong className="text-cyan-300">Algoria Dust</strong>. Consecutive streaks multiply your daily rewards!
          </p>
        </div>

        {/* 7-Day Rewards Track */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2 my-5">
          {days.map((d) => {
            const isPastDay = d.day < currentStreak;
            const isToday = d.day === currentStreak;
            const isFuture = d.day > currentStreak;

            return (
              <div
                key={d.day}
                className={`p-2 rounded-xl border flex flex-col items-center justify-between text-center transition-all ${
                  isToday
                    ? hasClaimedToday
                      ? 'bg-emerald-950/70 border-emerald-500/50 shadow-md ring-1 ring-emerald-500/40'
                      : 'bg-orange-950/80 border-orange-400 shadow-lg ring-2 ring-orange-400/80 scale-105'
                    : isPastDay
                    ? 'bg-slate-900/90 border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-950/60 border-slate-800 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-0.5 text-[10px] font-mono font-bold">
                  <span>D{d.day}</span>
                  {d.isJackpot && <span className="text-[8px] text-amber-400">★</span>}
                </div>

                <div className="my-1.5 flex items-center justify-center">
                  {isToday ? (
                    hasClaimedToday ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Sparkles className="w-5 h-5 text-cyan-300 animate-spin-slow" />
                    )
                  ) : isPastDay ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-slate-600" />
                  )}
                </div>

                <span className={`text-[9px] font-mono font-bold leading-tight ${
                  isToday ? (hasClaimedToday ? 'text-emerald-300' : 'text-cyan-300') : isPastDay ? 'text-slate-400' : 'text-slate-600'
                }`}>
                  {d.reward}
                </span>

                {isToday && !hasClaimedToday && (
                  <span className="mt-1 text-[8px] bg-orange-500 text-slate-950 font-extrabold px-1 rounded uppercase tracking-wider">
                    Today
                  </span>
                )}
                {isPastDay && (
                  <span className="mt-1 text-[8px] text-emerald-400 font-medium">
                    Done
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Claim or Claimed Action Button */}
        <div className="space-y-3">
          {!hasClaimedToday ? (
            <button
              onClick={handleClaim}
              className="w-full py-3.5 bg-gradient-to-r from-orange-500 via-amber-500 to-cyan-500 hover:from-orange-400 hover:to-cyan-400 text-slate-950 font-black text-sm sm:text-base rounded-xl shadow-xl shadow-orange-500/25 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 group"
            >
              <Sparkles className="w-5 h-5 text-slate-950 group-hover:rotate-12 transition-transform" />
              <span>CLAIM +{todaysDustReward} ALGORIA DUST</span>
            </button>
          ) : (
            <div className="w-full py-3.5 bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-inner">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>Today's Dust Claimed! Come back tomorrow for Day {currentStreak + 1}</span>
            </div>
          )}

          {/* Educational Note */}
          <div className="flex items-start gap-2 bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-left">
            <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-slate-400 leading-relaxed">
              <strong className="text-slate-200">How streaks work:</strong> Visit Algoria each consecutive calendar day to advance your streak track and unlock peak dust rewards up to 350+ dust!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
