import React, { useState } from 'react';
import { Play, Plus, Minus, ArrowUp, Sparkles, RefreshCw, Layers } from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface LoopControlPanelProps {
  levelId: number;
  levelType: string;
  onExecuteScript: (commands: any[]) => void;
  onManualJump: () => void;
  isExecuting: boolean;
  targetCount: number;
}

export const LoopControlPanel: React.FC<LoopControlPanelProps> = ({
  levelId,
  levelType,
  onExecuteScript,
  onManualJump,
  isExecuting,
  targetCount
}) => {
  // Level 2 repeat count
  const [repeatCount, setRepeatCount] = useState<number>(20);

  // Level 3 actions
  const [level3Count, setLevel3Count] = useState<number>(10);
  const [actionsList, setActionsList] = useState<string[]>(['jump', 'collect_coin']);

  // Level 4 nested loops
  const [outerCount, setOuterCount] = useState<number>(3);
  const [innerCount, setInnerCount] = useState<number>(4);

  // Level 5 while loop
  const [whileCondition, setWhileCondition] = useState<string>('tree_ahead');
  const [exitAction, setExitAction] = useState<string>('deploy_bridge');

  // Handle RUN for Level 2 (Simple for loop)
  const handleRunLevel2 = () => {
    playButtonClick();
    const commands: any[] = [];
    for (let i = 0; i < repeatCount; i++) {
      commands.push({ action: 'jump', targetIndex: i });
    }
    onExecuteScript(commands);
  };

  // Handle RUN for Level 3 (Compound actions in loop)
  const handleRunLevel3 = () => {
    playButtonClick();
    const commands: any[] = [];
    for (let i = 0; i < level3Count; i++) {
      actionsList.forEach((act) => {
        commands.push({ action: act, targetIndex: i });
      });
    }
    onExecuteScript(commands);
  };

  // Handle RUN for Level 4 (Nested loops)
  const handleRunLevel4 = () => {
    playButtonClick();
    const commands: any[] = [];
    for (let out = 0; out < outerCount; out++) {
      for (let inn = 0; inn < innerCount; inn++) {
        commands.push({
          action: 'jump',
          loopInfo: { outer: out + 1, inner: inn + 1 }
        });
      }
    }
    onExecuteScript(commands);
  };

  // Handle RUN for Level 5 (While loop)
  const handleRunLevel5 = () => {
    playButtonClick();
    const commands: any[] = [];
    if (whileCondition === 'tree_ahead') {
      // 14 trees ahead
      for (let i = 0; i < 14; i++) {
        commands.push({ action: 'jump', targetIndex: i });
      }
      if (exitAction === 'deploy_bridge') {
        commands.push({ action: 'deploy_bridge' });
      }
    } else if (whileCondition === 'always_true') {
      // Infinite loop: jumps through all trees straight into river without deploying bridge
      for (let i = 0; i < 16; i++) {
        commands.push({ action: 'jump', targetIndex: i });
      }
    } else if (whileCondition === 'river_ahead') {
      // Condition river_ahead() is False at the start (a tree is ahead, not river)
      // So while loop evaluates False immediately; 0 jumps execute!
    }
    onExecuteScript(commands);
  };

  // LEVEL 1: Interactive Manual Jump Button with mobile touch target
  if (levelId === 1) {
    return (
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-slate-900/90 border border-cyan-500/30 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="text-left">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-cyan-400">COMMAND BAR</span>
            <span className="text-xs text-slate-400">· Sequential Leap Mode</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Tap <kbd className="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-cyan-300 text-xs font-mono">SPACE</kbd> or press the button when entering the glowing tree beacons!
          </p>
        </div>

        <button
          onClick={() => {
            onManualJump();
          }}
          disabled={isExecuting}
          className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-white font-bold text-lg rounded-xl shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-3 transition-all cursor-pointer select-none"
        >
          <ArrowUp className="w-6 h-6 stroke-[3]" />
          <span>JUMP!</span>
        </button>
      </div>
    );
  }

  // LEVEL 2: For Loop repeat builder
  if (levelId === 2) {
    return (
      <div className="p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-purple-500/20">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-purple-400 font-bold">ALGORITHM BLOCK</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300">Repeat Loop Programmer</span>
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Target: <span className="text-cyan-300 font-bold">{targetCount} Trees</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Visual Loop Block */}
          <div className="md:col-span-8 bg-slate-950/80 p-3 sm:p-4 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm">
            <div className="flex items-center gap-2 flex-wrap text-purple-300">
              <span className="text-pink-400 font-bold">repeat</span>
              <div className="inline-flex items-center gap-1 bg-purple-950/70 border border-purple-500/60 px-2 py-1 rounded-lg">
                <button
                  onClick={() => {
                    playButtonClick();
                    setRepeatCount(Math.max(1, repeatCount - 1));
                  }}
                  disabled={isExecuting}
                  className="w-6 h-6 flex items-center justify-center bg-purple-900/80 hover:bg-purple-800 rounded text-white text-xs cursor-pointer active:scale-90"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-9 text-center font-bold text-base text-cyan-300 font-mono tabular-nums">
                  {repeatCount}
                </span>
                <button
                  onClick={() => {
                    playButtonClick();
                    setRepeatCount(Math.min(30, repeatCount + 1));
                  }}
                  disabled={isExecuting}
                  className="w-6 h-6 flex items-center justify-center bg-purple-900/80 hover:bg-purple-800 rounded text-white text-xs cursor-pointer active:scale-90"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <span className="text-pink-400 font-bold">times:</span>
            </div>

            {/* Loop Indented Body */}
            <div className="pl-6 mt-2 flex items-center gap-2 text-cyan-300 border-l-2 border-purple-500/30">
              <span className="bg-cyan-950/70 border border-cyan-500/40 px-2.5 py-1 rounded text-xs">
                jump()
              </span>
              <span className="text-slate-500 text-xs"># vault over tree canopy</span>
            </div>
          </div>

          {/* Run button & Quick Preset */}
          <div className="md:col-span-4 flex flex-col gap-2">
            <div className="flex gap-2">
              {[5, 10, 20].map((preset) => (
                <button
                  key={preset}
                  onClick={() => {
                    playButtonClick();
                    setRepeatCount(preset);
                  }}
                  disabled={isExecuting}
                  className={`flex-1 py-1 text-xs rounded border transition-colors cursor-pointer ${
                    repeatCount === preset
                      ? 'bg-purple-600/40 border-purple-400 text-white font-bold'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {preset}x
                </button>
              ))}
            </div>

            <button
              onClick={handleRunLevel2}
              disabled={isExecuting}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>EXECUTING...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>RUN CODE</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // LEVEL 3: Multi-Action Compound Loop
  if (levelId === 3) {
    return (
      <div className="p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-purple-500/20">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-purple-400 font-bold">ALGORITHM BLOCK</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300">Compound Instruction Body</span>
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Trees: <span className="text-cyan-300 font-bold">{targetCount}</span> · Coins:{' '}
            <span className="text-amber-300 font-bold">{targetCount}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-8 bg-slate-950/80 p-3 sm:p-4 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm">
            <div className="flex items-center gap-2 text-purple-300 mb-2">
              <span className="text-pink-400 font-bold">for</span>
              <span className="text-cyan-300">tree</span>
              <span className="text-pink-400 font-bold">in range(</span>
              <div className="inline-flex items-center gap-1 bg-purple-950/70 border border-purple-500/60 px-2 py-0.5 rounded-lg">
                <button
                  onClick={() => {
                    playButtonClick();
                    setLevel3Count(Math.max(1, level3Count - 1));
                  }}
                  disabled={isExecuting}
                  className="w-5 h-5 flex items-center justify-center bg-purple-900 rounded text-white text-xs cursor-pointer"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-7 text-center font-bold text-cyan-300 font-mono tabular-nums">
                  {level3Count}
                </span>
                <button
                  onClick={() => {
                    playButtonClick();
                    setLevel3Count(Math.min(20, level3Count + 1));
                  }}
                  disabled={isExecuting}
                  className="w-5 h-5 flex items-center justify-center bg-purple-900 rounded text-white text-xs cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <span className="text-pink-400 font-bold">):</span>
            </div>

            {/* Loop Indented Sequence */}
            <div className="pl-6 space-y-1.5 border-l-2 border-purple-500/30">
              <div className="flex items-center gap-2">
                <span className="text-slate-500 text-[11px]">1.</span>
                <span className="bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 px-2.5 py-0.5 rounded text-xs">
                  jump()
                </span>
                <span className="text-slate-400 text-[11px]"># Leap over tree</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 text-[11px]">2.</span>
                <span className="bg-amber-950/80 border border-amber-500/40 text-amber-300 px-2.5 py-0.5 rounded text-xs flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  collect_coin()
                </span>
                <span className="text-slate-400 text-[11px]"># Grab crystal</span>
              </div>
            </div>
          </div>

          <div className="md:col-span-4 flex flex-col gap-2">
            <button
              onClick={handleRunLevel3}
              disabled={isExecuting}
              className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>EXECUTING...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>RUN SEQUENCE</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // LEVEL 4: Nested Loops (Outer grove × Inner tree)
  if (levelId === 4) {
    return (
      <div className="p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-purple-500/20">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-purple-400 font-bold">ALGORITHM BLOCK</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300">Nested Loop Programmer</span>
          </div>
          <div className="text-xs text-slate-400 font-mono">
            Calculated Jumps:{' '}
            <span className="text-emerald-300 font-bold font-mono">
              {outerCount} × {innerCount} = {outerCount * innerCount} Trees
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-8 bg-slate-950/80 p-3 sm:p-4 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm">
            {/* Outer Loop */}
            <div className="flex items-center gap-2 text-purple-300 flex-wrap">
              <span className="text-pink-400 font-bold">for</span>
              <span className="text-purple-300">grove</span>
              <span className="text-pink-400 font-bold">in range(</span>
              <div className="inline-flex items-center gap-1 bg-purple-950/70 border border-purple-500/60 px-2 py-0.5 rounded-lg">
                <button
                  onClick={() => {
                    playButtonClick();
                    setOuterCount(Math.max(1, outerCount - 1));
                  }}
                  disabled={isExecuting}
                  className="w-5 h-5 flex items-center justify-center bg-purple-900 rounded text-white text-xs cursor-pointer"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-6 text-center font-bold text-cyan-300 font-mono">{outerCount}</span>
                <button
                  onClick={() => {
                    playButtonClick();
                    setOuterCount(Math.min(6, outerCount + 1));
                  }}
                  disabled={isExecuting}
                  className="w-5 h-5 flex items-center justify-center bg-purple-900 rounded text-white text-xs cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <span className="text-pink-400 font-bold">):</span>
              <span className="text-slate-500 text-xs"># Outer: 3 groves</span>
            </div>

            {/* Inner Loop */}
            <div className="pl-6 mt-2 border-l-2 border-purple-500/40">
              <div className="flex items-center gap-2 text-cyan-300 flex-wrap">
                <span className="text-pink-400 font-bold">for</span>
                <span className="text-cyan-300">tree</span>
                <span className="text-pink-400 font-bold">in range(</span>
                <div className="inline-flex items-center gap-1 bg-cyan-950/70 border border-cyan-500/60 px-2 py-0.5 rounded-lg">
                  <button
                    onClick={() => {
                      playButtonClick();
                      setInnerCount(Math.max(1, innerCount - 1));
                    }}
                    disabled={isExecuting}
                    className="w-5 h-5 flex items-center justify-center bg-cyan-900 rounded text-white text-xs cursor-pointer"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-6 text-center font-bold text-amber-300 font-mono">{innerCount}</span>
                  <button
                    onClick={() => {
                      playButtonClick();
                      setInnerCount(Math.min(8, innerCount + 1));
                    }}
                    disabled={isExecuting}
                    className="w-5 h-5 flex items-center justify-center bg-cyan-900 rounded text-white text-xs cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
                <span className="text-pink-400 font-bold">):</span>
                <span className="text-slate-500 text-xs"># Inner: 4 trees</span>
              </div>

              {/* Innermost action */}
              <div className="pl-6 mt-1.5 border-l-2 border-cyan-500/40">
                <span className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 px-2.5 py-0.5 rounded text-xs">
                  jump()
                </span>
              </div>
            </div>
          </div>

          <div className="md:col-span-4 flex flex-col gap-2">
            <div className="flex gap-2">
              <button
                onClick={() => {
                  playButtonClick();
                  setOuterCount(3);
                  setInnerCount(4);
                }}
                disabled={isExecuting}
                className={`flex-1 py-1 text-[11px] font-mono rounded border transition-colors cursor-pointer ${
                  outerCount === 3 && innerCount === 4
                    ? 'bg-emerald-600/40 border-emerald-400 text-white font-bold'
                    : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                3 × 4 = 12 (Target)
              </button>
              <button
                onClick={() => {
                  playButtonClick();
                  setOuterCount(2);
                  setInnerCount(6);
                }}
                disabled={isExecuting}
                className={`py-1 px-2 text-[11px] font-mono rounded border transition-colors cursor-pointer ${
                  outerCount === 2 && innerCount === 6
                    ? 'bg-purple-600/40 border-purple-400 text-white font-bold'
                    : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                2 × 6
              </button>
            </div>

            <button
              onClick={handleRunLevel4}
              disabled={isExecuting}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>NESTED RUNNING...</span>
                </>
              ) : (
                <>
                  <Layers className="w-4 h-4" />
                  <span>RUN NESTED LOOP</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // LEVEL 5: While loop with conditional break
  if (levelId === 5) {
    return (
      <div className="p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-3 border-b border-purple-500/20">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-purple-400 font-bold">ALGORITHM BLOCK</span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300">While Loop &amp; Condition Exit</span>
          </div>
          <div className="text-xs text-cyan-300 font-mono">Dynamic Unknown Terrain</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-8 bg-slate-950/80 p-3 sm:p-4 rounded-xl border border-slate-800 font-mono text-xs sm:text-sm">
            {/* While Condition */}
            <div className="flex items-center gap-2 text-purple-300 flex-wrap">
              <span className="text-pink-400 font-bold">while</span>
              <select
                value={whileCondition}
                onChange={(e) => {
                  playButtonClick();
                  setWhileCondition(e.target.value);
                }}
                disabled={isExecuting}
                className="bg-purple-950/80 border border-purple-500/60 text-cyan-300 px-2 py-1 rounded text-xs cursor-pointer font-mono"
              >
                <option value="tree_ahead">tree_ahead() == True</option>
                <option value="always_true">True (Infinite Loop)</option>
                <option value="river_ahead">river_ahead() == True</option>
              </select>
              <span className="text-pink-400 font-bold">:</span>
            </div>

            {/* Loop Body */}
            <div className="pl-6 mt-1.5 border-l-2 border-purple-500/40">
              <span className="bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 px-2.5 py-0.5 rounded text-xs">
                jump()
              </span>
            </div>

            {/* Loop Terminate / Bridge action */}
            <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center gap-2 text-purple-300 flex-wrap">
              <span className="text-slate-400 text-xs">on loop finish:</span>
              <select
                value={exitAction}
                onChange={(e) => {
                  playButtonClick();
                  setExitAction(e.target.value);
                }}
                disabled={isExecuting}
                className="bg-purple-950/80 border border-purple-500/60 text-amber-300 px-2 py-1 rounded text-xs cursor-pointer font-mono"
              >
                <option value="deploy_bridge">deploy_neon_bridge()</option>
                <option value="keep_jumping">jump() into river</option>
                <option value="do_nothing">pass (idle)</option>
              </select>
            </div>
          </div>

          <div className="md:col-span-4 flex flex-col gap-2">
            <button
              onClick={handleRunLevel5}
              disabled={isExecuting}
              className="w-full py-3.5 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 active:scale-95 text-white font-bold text-sm sm:text-base rounded-xl shadow-lg shadow-pink-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isExecuting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>EVALUATING WHILE...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>RUN WHILE LOOP</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
