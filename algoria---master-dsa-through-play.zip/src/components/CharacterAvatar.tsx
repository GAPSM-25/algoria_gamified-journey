import React, { useState } from 'react';

interface CharacterAvatarProps {
  characterId: string;
  size?: number;
  className?: string;
  isSelected?: boolean;
}

const AVATAR_METADATA: Record<
  string,
  {
    image: string;
    name: string;
    primaryColor: string;
    glowColor: string;
    borderColor: string;
    ringGradient: string;
  }
> = {
  bit_byte: {
    image: '/assets/heroes/hero_logic.jpg',
    name: 'Logic',
    primaryColor: '#00e5ff',
    glowColor: 'rgba(0, 229, 255, 0.45)',
    borderColor: '#06b6d4',
    ringGradient: 'from-cyan-400 via-sky-500 to-blue-600'
  },
  algo_fox: {
    image: '/assets/heroes/hero_speed.jpg',
    name: 'Speed',
    primaryColor: '#ff6b00',
    glowColor: 'rgba(255, 107, 0, 0.45)',
    borderColor: '#f97316',
    ringGradient: 'from-amber-400 via-orange-500 to-red-600'
  },
  pixel_knight: {
    image: '/assets/heroes/hero_strategy.jpg',
    name: 'Strategy',
    primaryColor: '#10b981',
    glowColor: 'rgba(16, 185, 129, 0.45)',
    borderColor: '#10b981',
    ringGradient: 'from-emerald-400 via-teal-500 to-green-700'
  },
  cyber_nova: {
    image: '/assets/heroes/hero_nova.jpg',
    name: 'Nova',
    primaryColor: '#c084fc',
    glowColor: 'rgba(192, 132, 252, 0.5)',
    borderColor: '#a855f7',
    ringGradient: 'from-purple-400 via-pink-500 to-cyan-400'
  }
};

export const CharacterAvatar: React.FC<CharacterAvatarProps> = ({
  characterId,
  size = 64,
  className = '',
  isSelected = false
}) => {
  const [imageError, setImageError] = useState(false);
  const meta = AVATAR_METADATA[characterId] || AVATAR_METADATA.bit_byte;

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 rounded-full transition-transform duration-300 ${
        isSelected ? 'scale-105' : 'hover:scale-105'
      } ${className}`}
      style={{
        width: size,
        height: size
      }}
    >
      {/* Outer ambient glow */}
      <div
        className="absolute inset-0 rounded-full pointer-events-none transition-opacity duration-300"
        style={{
          boxShadow: isSelected
            ? `0 0 ${Math.max(12, size * 0.3)}px ${meta.glowColor}`
            : `0 0 ${Math.max(6, size * 0.15)}px ${meta.glowColor}`,
          opacity: isSelected ? 0.95 : 0.6
        }}
      />

      {/* Futuristic metallic gradient ring */}
      <div
        className={`relative w-full h-full rounded-full p-[2px] bg-gradient-to-tr ${meta.ringGradient} flex items-center justify-center overflow-hidden shadow-md`}
      >
        {/* Inner dark bezel */}
        <div className="w-full h-full rounded-full bg-[#050814] flex items-center justify-center overflow-hidden relative">
          {!imageError ? (
            <img
              src={meta.image}
              alt={meta.name}
              onError={() => setImageError(true)}
              className="w-full h-full object-cover rounded-full"
            />
          ) : (
            <div
              className="w-full h-full flex items-center justify-center font-black text-xs"
              style={{ color: meta.primaryColor }}
            >
              {meta.name.slice(0, 2).toUpperCase()}
            </div>
          )}

          {/* Holographic light sheen reflection */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-b from-white/15 via-transparent to-black/30 pointer-events-none" />

          {/* Active selection inner ring */}
          {isSelected && (
            <div
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{ boxShadow: `inset 0 0 0 2px ${meta.primaryColor}` }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
