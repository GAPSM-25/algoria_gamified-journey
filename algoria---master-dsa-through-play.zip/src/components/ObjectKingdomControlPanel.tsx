import React, { useState } from 'react';
import {
  Castle,
  Shield,
  Layers,
  Sparkles,
  Cpu,
  CheckCircle2,
  Terminal,
  Code2,
  ChevronDown,
  ChevronUp,
  Boxes,
  KeyRound,
  Zap,
  Play
} from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface ObjectKingdomControlPanelProps {
  levelId: number;
  levelType: string;
  targetCount: number;
  currentCount: number;
  consoleLogs?: string[];
  onInstantiateRobot?: (idx: number) => void;
  onTestEncapsulation?: (idx: number) => void;
  onDeriveInheritance?: (idx: number) => void;
  onPolymorphicDispatch?: (idx: number) => void;
  onImplementContract?: (idx: number) => void;
}

export const ObjectKingdomControlPanel: React.FC<ObjectKingdomControlPanelProps> = ({
  levelId,
  levelType,
  targetCount,
  currentCount,
  consoleLogs = [],
  onInstantiateRobot,
  onTestEncapsulation,
  onDeriveInheritance,
  onPolymorphicDispatch,
  onImplementContract
}) => {
  const [showCodeSpec, setShowCodeSpec] = useState<boolean>(false);
  const [activeCodeLang, setActiveCodeLang] = useState<'python' | 'ts'>('python');

  // Level 1 data
  const level1Robots = [
    { name: 'Aegis-One', core: 'Plasma', ep: 100, role: 'Vanguard Tank' },
    { name: 'Volt-Spark', core: 'Lightning', ep: 85, role: 'Speed Scout' },
    { name: 'Cryo-Shield', core: 'Glacier', ep: 95, role: 'Frost Defender' }
  ];

  // Level 2 data
  const level2Rules = [
    { field: '#health', attack: 'health = -50', fix: 'Setter validates: value >= 0' },
    { field: '#accessPin', attack: 'pin = "0000"', fix: 'Setter enforces: 6-char length' },
    { field: '#shield', attack: 'shield = 99999', fix: 'Setter clamps: max 200 rating' },
    { field: '#mode', attack: 'mode = OVERRIDE', fix: 'Setter verifies: whitelist enum' }
  ];

  // Level 3 data
  const level3Subs = [
    { name: 'PaladinGuardian', spec: 'Heavy Armor & Shield Bash', super: 'super(name, 150)' },
    { name: 'SorcererGuardian', spec: 'Arcane Energy & Teleport', super: 'super(name, 90)' },
    { name: 'StealthInfiltrator', spec: 'Optical Cloak & Thermal Vision', super: 'super(name, 110)' }
  ];

  // Level 4 data
  const level4Team = [
    { name: 'WarriorBot', ability: 'Blade Vortex (Physical Cleave 120)' },
    { name: 'ChronoMageBot', ability: 'Time Warp (Freeze Enemies 3s)' },
    { name: 'SupportNanoBot', ability: 'Healing Wave (+80 Team HP)' }
  ];

  // Level 5 data
  const level5Contracts = [
    { name: 'authenticateCoreKey()', desc: 'Validates cryptographic signature' },
    { name: 'stabilizePlasmaFlux()', desc: 'Regulates harmonic reactor frequencies' },
    { name: 'igniteCitadelBarrier()', desc: 'Raises impenetrable defense shield' }
  ];

  return (
    <div className="p-3 sm:p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-2xl backdrop-blur-md">
      {/* Top Academic Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-3 border-b border-purple-500/20 text-xs">
        <div className="flex items-center gap-2">
          <Castle className="w-4 h-4 text-purple-400 animate-pulse" />
          <span className="text-purple-300 font-black tracking-wide">
            OBJECT KINGDOM · OOP PARADIGM
          </span>
          <span className="text-slate-500 hidden sm:inline">|</span>
          <span className="text-slate-300 font-mono text-[11px] hidden sm:inline">
            {levelId === 1 && 'Classes & Objects (Blueprints vs Instances)'}
            {levelId === 2 && 'Encapsulation & Data Hiding (Private #Fields)'}
            {levelId === 3 && 'Inheritance (extends & super Constructor)'}
            {levelId === 4 && 'Polymorphism (Dynamic Method Dispatch)'}
            {levelId === 5 && 'Abstraction (Interface Contracts)'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/30 text-[10px] font-mono text-purple-300">
            Paradigm: OOP
          </span>
          <div className="font-mono text-slate-300 text-xs pl-1">
            Progress:{' '}
            <span className="text-yellow-400 font-bold">
              {currentCount}/{targetCount}
            </span>
          </div>
        </div>
      </div>

      {/* Main Interactive Work Area */}
      <div className="mb-3">
        {/* LEVEL 1: CLASSES & OBJECTS */}
        {levelId === 1 && (
          <div>
            <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>FORGE OBJECT INSTANCES FROM THE GUARDIANROBOT CLASS BLUEPRINT:</span>
              <span className="text-purple-300">new GuardianRobot(name, core, energy)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {level1Robots.map((bot, idx) => {
                const isForged = idx < currentCount;
                return (
                  <button
                    key={idx}
                    disabled={isForged}
                    onClick={() => {
                      playButtonClick();
                      if (onInstantiateRobot) onInstantiateRobot(idx);
                    }}
                    className={`p-3 rounded-xl border text-left font-mono transition-all flex flex-col justify-between cursor-pointer ${
                      isForged
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 opacity-80 cursor-default'
                        : 'bg-slate-950 hover:bg-slate-800 border-purple-500/40 hover:border-cyan-400 active:scale-95 text-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>Instance #{idx + 1}</span>
                        {isForged && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <div className="text-sm font-bold text-white mt-0.5">{bot.name}</div>
                      <div className="text-[11px] text-cyan-300 mt-1">Core: {bot.core}</div>
                      <div className="text-[10px] text-slate-400">Energy: {bot.ep} EP</div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-purple-300 font-bold flex items-center justify-between">
                      <span>{isForged ? 'INSTANTIATED ✓' : 'FORGE INSTANCE'}</span>
                      <Play className="w-3 h-3 fill-current" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* LEVEL 2: ENCAPSULATION */}
        {levelId === 2 && (
          <div>
            <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>SHIELD PRIVATE FIELDS (#) WITH DEFENSIVE SETTERS &amp; GETTERS:</span>
              <span className="text-emerald-400">Data Integrity Defense</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {level2Rules.map((rule, idx) => {
                const isShielded = idx < currentCount;
                return (
                  <button
                    key={idx}
                    disabled={isShielded}
                    onClick={() => {
                      playButtonClick();
                      if (onTestEncapsulation) onTestEncapsulation(idx);
                    }}
                    className={`p-3 rounded-xl border text-left font-mono transition-all flex flex-col justify-between cursor-pointer ${
                      isShielded
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 opacity-80 cursor-default'
                        : 'bg-slate-950 hover:bg-slate-800 border-emerald-500/40 hover:border-emerald-300 active:scale-95 text-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>Field: {rule.field}</span>
                        {isShielded && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <div className="text-xs font-bold text-red-400 mt-0.5">Exploit: {rule.attack}</div>
                      <div className="text-[11px] text-emerald-300 mt-1">{rule.fix}</div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-emerald-400 font-bold flex items-center justify-between">
                      <span>{isShielded ? 'PROTECTED ✓' : 'APPLY DEFENSIVE SETTER'}</span>
                      <Shield className="w-3 h-3 fill-current" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* LEVEL 3: INHERITANCE */}
        {levelId === 3 && (
          <div>
            <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>DERIVE SPECIALIZED SUBCLASSES WITH &quot;EXTENDS&quot; &amp; &quot;SUPER()&quot;:</span>
              <span className="text-purple-300">BaseGuardian Inheritance</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {level3Subs.map((sub, idx) => {
                const isDerived = idx < currentCount;
                return (
                  <button
                    key={idx}
                    disabled={isDerived}
                    onClick={() => {
                      playButtonClick();
                      if (onDeriveInheritance) onDeriveInheritance(idx);
                    }}
                    className={`p-3 rounded-xl border text-left font-mono transition-all flex flex-col justify-between cursor-pointer ${
                      isDerived
                        ? 'bg-purple-950/60 border-purple-500/50 text-purple-300 opacity-80 cursor-default'
                        : 'bg-slate-950 hover:bg-slate-800 border-purple-500/40 hover:border-yellow-400 active:scale-95 text-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>Derived Subclass</span>
                        {isDerived && <CheckCircle2 className="w-3.5 h-3.5 text-yellow-400" />}
                      </div>
                      <div className="text-sm font-bold text-white mt-0.5">{sub.name}</div>
                      <div className="text-[10px] text-yellow-300 mt-1">{sub.spec}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{sub.super}</div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-yellow-400 font-bold flex items-center justify-between">
                      <span>{isDerived ? 'DERIVED ✓' : 'CHAIN SUPER() & DERIVE'}</span>
                      <Zap className="w-3 h-3 fill-current" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* LEVEL 4: POLYMORPHISM */}
        {levelId === 4 && (
          <div>
            <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>INVOKE UNIFORM .ACTIVATEABILITY() ACROSS HETEROGENEOUS ARRAY:</span>
              <span className="text-cyan-300">robots.forEach(r =&gt; r.activateAbility())</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {level4Team.map((bot, idx) => {
                const isDispatched = idx < currentCount;
                return (
                  <button
                    key={idx}
                    disabled={isDispatched}
                    onClick={() => {
                      playButtonClick();
                      if (onPolymorphicDispatch) onPolymorphicDispatch(idx);
                    }}
                    className={`p-3 rounded-xl border text-left font-mono transition-all flex flex-col justify-between cursor-pointer ${
                      isDispatched
                        ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-300 opacity-80 cursor-default'
                        : 'bg-slate-950 hover:bg-slate-800 border-cyan-500/40 hover:border-cyan-300 active:scale-95 text-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>Target #{idx + 1}</span>
                        {isDispatched && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                      </div>
                      <div className="text-sm font-bold text-white mt-0.5">{bot.name}</div>
                      <div className="text-[11px] text-cyan-300 mt-1">{bot.ability}</div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-cyan-400 font-bold flex items-center justify-between">
                      <span>{isDispatched ? 'DISPATCHED ✓' : 'DYNAMIC DISPATCH'}</span>
                      <Play className="w-3 h-3 fill-current" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* LEVEL 5: ABSTRACTION */}
        {levelId === 5 && (
          <div>
            <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
              <span>FULFILL ABSTRACT INTERFACE CONTRACT METHODS TO ACTIVATE CITADEL:</span>
              <span className="text-yellow-300">implements IPowerCitadelCore</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {level5Contracts.map((c, idx) => {
                const isDone = idx < currentCount;
                return (
                  <button
                    key={idx}
                    disabled={isDone}
                    onClick={() => {
                      playButtonClick();
                      if (onImplementContract) onImplementContract(idx);
                    }}
                    className={`p-3 rounded-xl border text-left font-mono transition-all flex flex-col justify-between cursor-pointer ${
                      isDone
                        ? 'bg-yellow-950/60 border-yellow-500/50 text-yellow-300 opacity-80 cursor-default'
                        : 'bg-slate-950 hover:bg-slate-800 border-yellow-500/40 hover:border-yellow-300 active:scale-95 text-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>Contract Method #{idx + 1}</span>
                        {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-yellow-400" />}
                      </div>
                      <div className="text-xs font-bold text-yellow-300 mt-0.5">{c.name}</div>
                      <div className="text-[10px] text-slate-300 mt-1">{c.desc}</div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-yellow-400 font-bold flex items-center justify-between">
                      <span>{isDone ? 'CONTRACT FULFILLED ✓' : 'IMPLEMENT CONTRACT'}</span>
                      <KeyRound className="w-3 h-3 fill-current" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Real-time Execution Console */}
      <div className="bg-slate-950/90 rounded-xl border border-slate-800 p-2.5 font-mono text-xs">
        <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-slate-800 text-[10px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-purple-400" />
            <span>OOP Runtime Execution Stream</span>
          </span>
          <span className="text-emerald-400">● LIVE RUNTIME</span>
        </div>
        <div className="space-y-1 max-h-20 overflow-y-auto text-[11px] text-purple-200">
          {consoleLogs.slice(-4).map((log, i) => (
            <div key={i} className="truncate">
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
