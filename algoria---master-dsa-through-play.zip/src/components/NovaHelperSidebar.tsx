import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Volume2,
  VolumeX,
  X,
  Play,
  Square,
  ChevronRight,
  ChevronDown,
  BookOpen,
  Zap,
  Code2,
  HelpCircle,
  Clock,
  Boxes,
  Flame,
  Waves,
  GitBranch,
  Network,
  RotateCcw,
  CheckCircle2,
  Lightbulb,
  Radio
} from 'lucide-react';
import { CharacterAvatar } from './CharacterAvatar.tsx';
import { CHARACTERS } from '../api/gameApi.js';
import { speakNova, stopNovaSpeech, isNovaSpeaking, isSpeechSupported } from '../utils/speech.ts';
import { playButtonClick } from '../utils/audio.ts';

interface NovaHelperSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  worldId: string;
  levelId: number;
  levelData: any;
  characterId?: string;
  isMuted: boolean;
}

interface AlgorithmInsight {
  title: string;
  category: string;
  summary: string;
  explanation: string;
  spokenExplanation: string;
  timeComplexity: string;
  spaceComplexity: string;
  invariant: string;
  proTips: string[];
  faq: { question: string; answer: string }[];
  pythonCode: string[];
  jsCode: string[];
}

export const NovaHelperSidebar: React.FC<NovaHelperSidebarProps> = ({
  isOpen,
  onToggle,
  worldId,
  levelId,
  levelData,
  characterId = 'bit_byte',
  isMuted
}) => {
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [activeSpeechKey, setActiveSpeechKey] = useState<string | null>(null);
  const [selectedLang, setSelectedLang] = useState<'python' | 'js'>('python');
  const [expandedFaqIndex, setExpandedFaqIndex] = useState<number | null>(0);

  const charConfig = CHARACTERS.find((c) => c.id === characterId) || CHARACTERS[0];

  // Stop speech when sidebar closes or unmounts
  useEffect(() => {
    if (!isOpen) {
      stopNovaSpeech();
      setIsSpeaking(false);
      setActiveSpeechKey(null);
    }
  }, [isOpen]);

  useEffect(() => {
    return () => {
      stopNovaSpeech();
    };
  }, []);

  // Stop speech if muted
  useEffect(() => {
    if (isMuted) {
      stopNovaSpeech();
      setIsSpeaking(false);
      setActiveSpeechKey(null);
    }
  }, [isMuted]);

  // Extract or generate tailored algorithm insights
  const insight: AlgorithmInsight = getAlgorithmInsight(worldId, levelId, levelData);

  const handleSpeak = (key: string, textToSpeak: string) => {
    playButtonClick();

    if (isSpeaking && activeSpeechKey === key) {
      // Toggle off
      stopNovaSpeech();
      setIsSpeaking(false);
      setActiveSpeechKey(null);
      return;
    }

    stopNovaSpeech();
    setIsSpeaking(true);
    setActiveSpeechKey(key);

    speakNova(textToSpeak, {
      onStart: () => {
        setIsSpeaking(true);
        setActiveSpeechKey(key);
      },
      onEnd: () => {
        setIsSpeaking(false);
        setActiveSpeechKey(null);
      },
      onError: () => {
        setIsSpeaking(false);
        setActiveSpeechKey(null);
      }
    });
  };

  const handleStopAllSpeech = () => {
    playButtonClick();
    stopNovaSpeech();
    setIsSpeaking(false);
    setActiveSpeechKey(null);
  };

  return (
    <>
      {/* Floating Collapsible Trigger Tab (When Closed) */}
      {!isOpen && (
        <button
          onClick={() => {
            playButtonClick();
            onToggle();
          }}
          className="fixed right-0 top-1/2 -translate-y-1/2 z-40 flex items-center gap-2 pl-3 pr-2.5 py-2.5 bg-gradient-to-l from-purple-900/90 via-slate-900/90 to-slate-950/90 hover:from-purple-800 hover:to-slate-900 border-l border-y border-purple-500/50 hover:border-cyan-400 text-white rounded-l-2xl shadow-2xl backdrop-blur-md cursor-pointer transition-all transform hover:-translate-x-1 group"
          title="Open Nova Helper Sidebar"
        >
          <div className="relative">
            <CharacterAvatar characterId={characterId} size={26} />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400" />
          </div>
          <div className="flex flex-col text-left">
            <span className="text-[11px] font-black text-cyan-300 group-hover:text-white tracking-wide uppercase font-mono">
              Nova Helper
            </span>
            <span className="text-[9px] text-purple-300 font-medium">Tips &amp; Voice Guide</span>
          </div>
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse ml-0.5" />
        </button>
      )}

      {/* Backdrop overlay on mobile */}
      {isOpen && (
        <div
          onClick={onToggle}
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Main Slide-in Sidebar */}
      <aside
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] bg-slate-950/95 border-l border-purple-500/40 shadow-2xl z-50 flex flex-col justify-between backdrop-blur-xl transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <header className="p-4 border-b border-purple-500/20 bg-slate-900/80 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative p-1 bg-slate-950 rounded-xl border border-cyan-500/40 shadow-md">
              <CharacterAvatar characterId={characterId} size={34} />
              {isSpeaking && (
                <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500" />
                </span>
              )}
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-black text-white tracking-wide">Nova Helper</h3>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono font-bold">
                  AI Guide
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                {charConfig.name} · Algorithm Telemetry
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {isSpeaking && (
              <button
                onClick={handleStopAllSpeech}
                className="flex items-center gap-1 px-2.5 py-1 bg-red-950/80 hover:bg-red-900/80 border border-red-500/40 rounded-lg text-red-300 text-[11px] font-bold cursor-pointer transition-colors"
                title="Stop Speaking"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Stop</span>
              </button>
            )}

            <button
              onClick={() => {
                playButtonClick();
                onToggle();
              }}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 transition-colors cursor-pointer"
              title="Close Helper Sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs text-slate-200 custom-scrollbar">
          {/* Voice of Nova Master Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-cyan-950/80 border border-purple-500/40 shadow-lg relative overflow-hidden">
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span>Voice Guidance: {isSpeaking ? 'Speaking Now...' : 'Ready'}</span>
              </div>

              {/* Animated Audio Equalizer Bars when speaking */}
              {isSpeaking && (
                <div className="flex items-end gap-0.5 h-4">
                  <div className="w-1 bg-cyan-400 rounded-full animate-bounce" style={{ height: '70%', animationDuration: '400ms' }} />
                  <div className="w-1 bg-cyan-300 rounded-full animate-bounce" style={{ height: '100%', animationDuration: '300ms' }} />
                  <div className="w-1 bg-pink-400 rounded-full animate-bounce" style={{ height: '40%', animationDuration: '500ms' }} />
                  <div className="w-1 bg-purple-400 rounded-full animate-bounce" style={{ height: '90%', animationDuration: '350ms' }} />
                  <div className="w-1 bg-cyan-400 rounded-full animate-bounce" style={{ height: '60%', animationDuration: '450ms' }} />
                </div>
              )}
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed mb-3">
              Tap the button below and Nova will talk out loud to explain the algorithm and walk you through the level strategy!
            </p>

            <button
              onClick={() => handleSpeak('master_explanation', `${insight.title}. ${insight.spokenExplanation}`)}
              className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer ${
                isSpeaking && activeSpeechKey === 'master_explanation'
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : 'bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white shadow-cyan-500/20'
              }`}
            >
              {isSpeaking && activeSpeechKey === 'master_explanation' ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop Nova's Voice</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen to Nova Explain This Level</span>
                </>
              )}
            </button>
          </div>

          {/* Section 1: Active Algorithm Card */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-amber-500/30 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/40 text-[10px] font-mono font-bold text-amber-300 uppercase">
                {insight.category}
              </span>

              <button
                onClick={() => handleSpeak('algorithm_summary', insight.summary)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Listen to summary"
              >
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
              </button>
            </div>

            <h4 className="text-sm font-bold text-white mb-1.5">{insight.title}</h4>
            <p className="text-[11px] text-slate-300 leading-relaxed">{insight.summary}</p>
          </div>

          {/* Section 2: Complexity & Invariant Telemetry */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Computational Complexity</span>
              </span>

              <button
                onClick={() =>
                  handleSpeak(
                    'complexity',
                    `Time complexity is ${insight.timeComplexity}. Space complexity is ${insight.spaceComplexity}. The invariant is: ${insight.invariant}`
                  )
                }
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Listen to complexity breakdown"
              >
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                <div className="text-[9px] text-slate-400">Time Complexity:</div>
                <div className="font-bold text-amber-300">{insight.timeComplexity}</div>
              </div>
              <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                <div className="text-[9px] text-slate-400">Space Complexity:</div>
                <div className="font-bold text-cyan-300">{insight.spaceComplexity}</div>
              </div>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-purple-500/20 text-[11px]">
              <div className="text-[10px] text-purple-400 font-bold mb-0.5">Algorithm Invariant:</div>
              <p className="text-slate-300 leading-relaxed">{insight.invariant}</p>
            </div>
          </div>

          {/* Section 3: Pro Strategies for 3 Stars */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Nova's Pro Tips (3-Star Victory)</span>
              </div>

              <button
                onClick={() => handleSpeak('pro_tips', insight.proTips.join('. '))}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 transition-colors cursor-pointer"
                title="Listen to pro tips"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              </button>
            </div>

            <ul className="space-y-1.5 text-[11px] text-slate-300">
              {insight.proTips.map((tip, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section 4: Interactive Q&A Accordion */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[11px] font-bold text-purple-300 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
                <span>Ask Nova (Key Concepts)</span>
              </span>
            </div>

            <div className="space-y-2">
              {insight.faq.map((item, idx) => {
                const isExpanded = expandedFaqIndex === idx;
                return (
                  <div
                    key={idx}
                    className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950"
                  >
                    <button
                      onClick={() => {
                        playButtonClick();
                        setExpandedFaqIndex(isExpanded ? null : idx);
                      }}
                      className="w-full p-2.5 flex items-center justify-between text-left text-[11px] font-bold text-white hover:text-cyan-300 cursor-pointer"
                    >
                      <span>{item.question}</span>
                      {isExpanded ? (
                        <ChevronDown className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      )}
                    </button>

                    {isExpanded && (
                      <div className="p-2.5 pt-0 border-t border-slate-800/60 text-[11px] text-slate-300">
                        <p className="leading-relaxed mb-2">{item.answer}</p>
                        <button
                          onClick={() => handleSpeak(`faq_${idx}`, item.answer)}
                          className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-purple-500/30 rounded-lg text-purple-300 text-[10px] font-bold cursor-pointer"
                        >
                          <Volume2 className="w-3 h-3 text-purple-400" />
                          <span>Nova: Read This Answer</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 5: Code Reference Blueprint */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Code Blueprint</span>
              </span>

              <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10px]">
                <button
                  onClick={() => setSelectedLang('python')}
                  className={`px-2 py-0.5 rounded font-mono font-bold cursor-pointer ${
                    selectedLang === 'python' ? 'bg-purple-600 text-white' : 'text-slate-400'
                  }`}
                >
                  Python
                </button>
                <button
                  onClick={() => setSelectedLang('js')}
                  className={`px-2 py-0.5 rounded font-mono font-bold cursor-pointer ${
                    selectedLang === 'js' ? 'bg-cyan-600 text-white' : 'text-slate-400'
                  }`}
                >
                  JS
                </button>
              </div>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[10px] text-slate-300 overflow-x-auto leading-relaxed">
              {(selectedLang === 'python' ? insight.pythonCode : insight.jsCode).map((line, i) => (
                <div key={i} className="whitespace-pre">
                  {line}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="p-3 border-t border-purple-500/20 bg-slate-900/80 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
          <div className="flex items-center gap-1 text-[10px]">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Interactive Algoria Voice AI</span>
          </div>
          <button
            onClick={() => {
              playButtonClick();
              onToggle();
            }}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Hide Sidebar
          </button>
        </footer>
      </aside>
    </>
  );
};

/**
 * Generate rich, context-sensitive algorithm data for every level in Algoria
 */
function getAlgorithmInsight(worldId: string, levelId: number, levelData: any): AlgorithmInsight {
  const recap = levelData?.recap;

  // Custom tailoring for Array Arena levels
  if (worldId === 'array_arena') {
    if (levelId === 1) {
      return {
        title: 'Level 1: 0-Indexed Memory Addressing',
        category: 'Contiguous Memory Arrays',
        summary:
          'Arrays allocate contiguous memory blocks. Every cell is accessed by a 0-based offset in O(1) instantaneous time.',
        explanation:
          'Because arrays are stored consecutively in RAM, computing the memory address of arr[i] only requires: base_address + (i * element_size).',
        spokenExplanation:
          'Welcome to the Array Arena! In computer science, arrays are stored side by side in memory. The first element is always at index zero because zero represents the starting byte offset. Tapping an index gives you instant constant time access!',
        timeComplexity: 'O(1) Constant Random Access',
        spaceComplexity: 'O(N) Contiguous Linear Space',
        invariant: 'For an array of size N, valid indices range strictly from 0 to N - 1.',
        proTips: [
          'Remember: 1st item is at index 0, 2nd is at index 1.',
          'Negative index arr[-1] in Python accesses the very last item.',
          'Always avoid off-by-one errors by checking bounds [0 .. length - 1].'
        ],
        faq: [
          {
            question: 'Why do arrays start at index 0 instead of 1?',
            answer:
              'The index represents the byte offset distance from the start address. The very first item is 0 offsets away from the start address!'
          },
          {
            question: 'Why is array index access O(1) constant time?',
            answer:
              'The hardware CPU calculates the address with a single arithmetic operation: base address plus index times byte size, needing no loops.'
          }
        ],
        pythonCode: [
          '# O(1) Index Lookup',
          'arr = [42, 17, 89, 5, 63, 99]',
          'first = arr[0]   # 42',
          'fourth = arr[3]  # 5',
          'last = arr[-1]   # 99'
        ],
        jsCode: [
          '// O(1) Index Lookup',
          'const arr = [42, 17, 89, 5, 63, 99];',
          'const first = arr[0];          // 42',
          'const last = arr[arr.length - 1]; // 99'
        ]
      };
    }

    if (levelId === 2) {
      return {
        title: 'Level 2: Bubble Sort & Pairwise Comparisons',
        category: 'Comparison-Based Sorting',
        summary:
          'Bubble sort repeatedly compares adjacent pairs arr[j] and arr[j+1], swapping them if out of order so largest values bubble to the end.',
        explanation:
          'After pass i, the i-th largest element is guaranteed to be in its correct final spot at the right end of the array.',
        spokenExplanation:
          'In Bubble Sort, we compare adjacent pairs from left to right. If the left orb is bigger than the right orb, we swap them! Watch the biggest numbers bubble up to the right side like air bubbles in water. You can step through each comparison or tap Auto-Run to watch the full sort!',
        timeComplexity: 'Best: O(N) · Worst: O(N²)',
        spaceComplexity: 'O(1) Auxiliary Memory (In-Place)',
        invariant: 'After pass i, the sub-array from index n - i to n - 1 is sorted and locked.',
        proTips: [
          'Use Auto-Run Bubble Sort to see all pairwise inversions resolved automatically.',
          'Notice how 64 reaches the far right end after Pass 1.',
          'Bubble sort is stable: duplicate values never switch relative positions.'
        ],
        faq: [
          {
            question: 'Why is it called Bubble Sort?',
            answer:
              'Because the largest elements bubble up to the right end of the array pass by pass, resembling air bubbles floating to the surface of water.'
          },
          {
            question: 'Can Bubble Sort stop early if the array is already sorted?',
            answer:
              'Yes! In the optimized version, if a complete pass occurs with zero swaps, we can break early, achieving O(N) best-case linear time.'
          }
        ],
        pythonCode: [
          'def bubble_sort(arr):',
          '    n = len(arr)',
          '    for i in range(n):',
          '        swapped = False',
          '        for j in range(0, n - i - 1):',
          '            if arr[j] > arr[j + 1]:',
          '                arr[j], arr[j + 1] = arr[j + 1], arr[j]',
          '                swapped = True',
          '        if not swapped: break',
          '    return arr'
        ],
        jsCode: [
          'function bubbleSort(arr) {',
          '  const n = arr.length;',
          '  for (let i = 0; i < n; i++) {',
          '    let swapped = false;',
          '    for (let j = 0; j < n - i - 1; j++) {',
          '      if (arr[j] > arr[j + 1]) {',
          '        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];',
          '        swapped = true;',
          '      }',
          '    }',
          '    if (!swapped) break;',
          '  }',
          '  return arr;',
          '}'
        ]
      };
    }

    if (levelId === 3) {
      return {
        title: 'Level 3: Corridor Race: O(N) vs. O(log N)',
        category: 'Search Complexity Showdown',
        summary:
          'Linear search inspects every element sequentially in O(N). Binary search operates on sorted arrays, halving remaining candidates in O(log N).',
        explanation:
          'While the Rogue Bot checks slot by slot, halving the search interval allows you to find target 81 in only 4 steps instead of 16!',
        spokenExplanation:
          'This is the Colosseum Race! In the top lane, the rogue bot checks one slot at a time in Big O of N. In the bottom lane, you use Binary Search to inspect the midpoint and discard half the corridor with every single step. Tap the midpoint to outpace the bot!',
        timeComplexity: 'Linear: O(N) · Binary: O(log N)',
        spaceComplexity: 'O(1) Constant Auxiliary Space',
        invariant: 'The target element is guaranteed to lie between low and high at all times.',
        proTips: [
          'Each midpoint check eliminates 50% of the remaining elements.',
          'For 16 elements, log2(16) = 4 steps maximum.',
          'Binary search strictly requires the underlying data to be sorted!'
        ],
        faq: [
          {
            question: 'Why is Binary Search faster than Linear Search?',
            answer:
              'Linear search checks up to N items. Binary search halves the options every time, taking only log2(N) steps. For 1 million items, binary search takes only 20 checks!'
          }
        ],
        pythonCode: [
          'def binary_search(arr, target):',
          '    low, high = 0, len(arr) - 1',
          '    while low <= high:',
          '        mid = (low + high) // 2',
          '        if arr[mid] == target: return mid',
          '        elif arr[mid] < target: low = mid + 1',
          '        else: high = mid - 1',
          '    return -1'
        ],
        jsCode: [
          'function binarySearch(arr, target) {',
          '  let low = 0, high = arr.length - 1;',
          '  while (low <= high) {',
          '    const mid = Math.floor((low + high) / 2);',
          '    if (arr[mid] === target) return mid;',
          '    else if (arr[mid] < target) low = mid + 1;',
          '    else high = mid - 1;',
          '  }',
          '  return -1;',
          '}'
        ]
      };
    }

    if (levelId === 4) {
      return {
        title: 'Level 4: Binary Search Interval Halving',
        category: 'Divide & Conquer',
        summary:
          'Track low, mid, and high pointers. Compare arr[mid] with target 55 to discard entire halves.',
        explanation:
          'Calculate mid = floor((low + high) / 2). If arr[mid] < target, discard left by setting low = mid + 1.',
        spokenExplanation:
          'In this level, we pinpoint target 55 by explicitly choosing whether to discard the left or right half. Observe the low, mid, and high pointers. When arr at mid equals 55, confirm target found!',
        timeComplexity: 'O(log N) Logarithmic Time',
        spaceComplexity: 'O(1) Auxiliary Space',
        invariant: 'low <= target_index <= high until the range collapses.',
        proTips: [
          'If arr[mid] < target, your target must be to the right.',
          'If arr[mid] > target, your target must be to the left.',
          'Notice how 55 is right at mid = 4 on the initial step!'
        ],
        faq: [
          {
            question: 'How do you calculate mid without integer overflow?',
            answer:
              'Use mid = low + (high - low) // 2 in C++ and Java to avoid adding two huge numbers.'
          }
        ],
        pythonCode: [
          'mid = low + (high - low) // 2',
          'if arr[mid] == target: return mid',
          'elif arr[mid] < target: low = mid + 1',
          'else: high = mid - 1'
        ],
        jsCode: [
          'const mid = low + Math.floor((high - low) / 2);',
          'if (arr[mid] === target) return mid;',
          'else if (arr[mid] < target) low = mid + 1;',
          'else high = mid - 1;'
        ]
      };
    }

    if (levelId === 5) {
      return {
        title: 'Level 5: Two-Pointers In-Place Reversal',
        category: 'Two-Pointers Technique',
        summary:
          'Position Left at 0 and Right at n - 1. Swap elements in-place and converge inward until left >= right.',
        explanation:
          'In-place manipulation achieves O(N/2) = O(N) linear time while using O(1) zero auxiliary memory.',
        spokenExplanation:
          'The Two-Pointers pattern is a superpower for competitive programming! Instead of allocating a brand new array, we place one pointer on the left and one on the right. Swap them, move them inward, and repeat until they cross!',
        timeComplexity: 'O(N) Linear Time (N / 2 swaps)',
        spaceComplexity: 'O(1) In-Place Space',
        invariant: 'All elements outside [left, right] are in their final reversed order.',
        proTips: [
          'Converge left++ and right-- after each pair swap.',
          'When left >= right, the array is completely reversed.',
          'Zero new arrays are allocated, saving precious memory.'
        ],
        faq: [
          {
            question: 'What are other common uses of the Two-Pointers technique?',
            answer:
              'Checking if a string is a palindrome, solving the Two-Sum problem on sorted arrays, and sliding window string matching.'
          }
        ],
        pythonCode: [
          'left, right = 0, len(arr) - 1',
          'while left < right:',
          '    arr[left], arr[right] = arr[right], arr[left]',
          '    left += 1',
          '    right -= 1'
        ],
        jsCode: [
          'let left = 0, right = arr.length - 1;',
          'while (left < right) {',
          '  [arr[left], arr[right]] = [arr[right], arr[left]];',
          '  left++; right--;',
          '}'
        ]
      };
    }
  }

  // Fallback / standard dynamic generation based on levelData recap
  return {
    title: levelData?.title || 'Algorithm Challenge',
    category: levelData?.concept || 'Data Structures & Algorithms',
    summary:
      recap?.simpleSummary ||
      levelData?.subtitle ||
      'Master this algorithmic challenge by understanding the core sequence and operations.',
    explanation:
      recap?.explanationLines?.[0] ||
      levelData?.novaIntro?.message ||
      'Apply proper data structure invariants to achieve optimal time and space efficiency.',
    spokenExplanation:
      levelData?.novaIntro?.message ||
      recap?.simpleSummary ||
      'Let us review the algorithmic steps together. Follow the instructions to clear the level.',
    timeComplexity: 'O(N) Operations',
    spaceComplexity: 'O(1) Auxiliary Memory',
    invariant: 'Follow the core data structure contract for FIFO, LIFO, or traversal order.',
    proTips: [
      levelData?.hint || 'Pay attention to sequence and direction.',
      'Maintain maximum hearts by taking your time on difficult steps.',
      'Check the code preview below to understand the programmatic logic.'
    ],
    faq: [
      {
        question: `How does ${levelData?.concept || 'this algorithm'} work?`,
        answer:
          recap?.simpleSummary ||
          'It follows deterministic state transitions to process items according to the rules of the data structure.'
      }
    ],
    pythonCode: recap?.pythonCode || ['# Algorithmic step logic', 'pass'],
    jsCode: recap?.jsCode || ['// Algorithmic step logic', 'return true;']
  };
}
