import React, { useState } from 'react';
import {
  Trophy,
  X,
  Medal,
  Star,
  Zap,
  Award,
  Crown,
  Flame,
  User
} from 'lucide-react';
import { CharacterAvatar } from './CharacterAvatar.tsx';
import { getLeaderboard } from '../api/gameApi.js';
import { playButtonClick } from '../utils/audio.ts';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  currentUser
}) => {
  const [tab, setTab] = useState<'all_time' | 'weekly'>('all_time');

  if (!isOpen) return null;

  const leaderboard = (getLeaderboard(currentUser) || []) as any[];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-950/95 border border-cyan-500/30 rounded-3xl p-6 sm:p-7 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            playButtonClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Trophy className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
              <span>Algoria Realm Leaderboard</span>
              <Crown className="w-5 h-5 text-yellow-400 fill-yellow-400" />
            </h2>
            <p className="text-xs text-slate-400">
              Live MongoDB Atlas Rankings · Real-Time Explorer Data Only
            </p>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 mb-4">
          <button
            onClick={() => {
              playButtonClick();
              setTab('all_time');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              tab === 'all_time'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            All-Time Legends
          </button>
          <button
            onClick={() => {
              playButtonClick();
              setTab('weekly');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              tab === 'weekly'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Weekly Sprint
          </button>
        </div>

        {/* Table of Explorers */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {leaderboard.length === 0 && (
            <div className="p-8 text-center text-slate-400 font-mono text-xs bg-slate-950/40 rounded-xl border border-slate-800">
              No other explorers currently registered. Only real-time data is saved.
            </div>
          )}
          {leaderboard.map((entry) => {
            const isTop3 = entry.rank <= 3;
            const rankBadgeColor =
              entry.rank === 1
                ? 'bg-yellow-500 text-slate-950'
                : entry.rank === 2
                ? 'bg-slate-300 text-slate-950'
                : entry.rank === 3
                ? 'bg-amber-700 text-amber-100'
                : 'bg-slate-800 text-slate-400';

            return (
              <div
                key={entry.username}
                className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                  entry.isPlayer
                    ? 'bg-purple-950/70 border-cyan-400 shadow-md ring-1 ring-cyan-400/50'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Left: Rank & Avatar */}
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${rankBadgeColor}`}
                  >
                    {entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : entry.rank}
                  </div>

                  <div className="relative">
                    <CharacterAvatar characterId={entry.characterId} size={36} />
                  </div>

                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{entry.username}</span>
                      {entry.isPlayer && (
                        <span className="text-[10px] font-bold text-cyan-400 bg-cyan-950 border border-cyan-500/40 px-1.5 py-0.2 rounded-full">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Division: <span className="text-amber-300 font-semibold">{entry.division}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Badges, Stars & XP */}
                <div className="flex items-center gap-3 sm:gap-5 text-xs font-mono">
                  <div className="flex items-center gap-1 text-slate-400">
                    <Award className="w-3.5 h-3.5 text-purple-400" />
                    <span>{entry.badges}</span>
                  </div>

                  <div className="flex items-center gap-1 text-yellow-400">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span className="font-bold">{entry.stars}</span>
                  </div>

                  <div className="flex items-center gap-1 text-cyan-300 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 font-bold">
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{entry.xp} XP</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
