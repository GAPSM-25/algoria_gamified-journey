import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Star,
  Zap,
  Coins,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Award,
  CheckCircle2,
  Clock,
  Heart,
  Layers,
  GitCommit,
  Play,
  Pause,
  SkipForward,
  Home
} from 'lucide-react';
import { NovaDialogue } from './NovaDialogue.tsx';
import { playStarSound, playButtonClick } from '../utils/audio.ts';

interface CodeRecapModalProps {
  isOpen: boolean;
  levelData: any;
  stars: number;
  xpGained: number;
  coinsGained: number;
  completionTime?: number;
  targetTime?: number;
  heartsLeft?: number;
  maxHearts?: number;
  isWorldComplete?: boolean;
  worldId?: string;
  characterId?: string;
  onNextLevel: () => void;
  onReplay: () => void;
  onExitToMap?: () => void;
  onGoHome?: () => void;
}

export const CodeRecapModal: React.FC<CodeRecapModalProps> = ({
  isOpen,
  levelData,
  stars,
  xpGained,
  coinsGained,
  completionTime,
  targetTime,
  heartsLeft,
  maxHearts = 3,
  isWorldComplete = false,
  worldId,
  characterId = 'bit_byte',
  onNextLevel,
  onReplay,
  onExitToMap,
  onGoHome
}) => {
  const [langTab, setLangTab] = useState<'python' | 'js'>('python');
  const [activeCodeLine, setActiveCodeLine] = useState<number>(0);
  const [revealedStars, setRevealedStars] = useState<number>(0);
  const [animStep, setAnimStep] = useState<number>(0);
  const [isAnimPlaying, setIsAnimPlaying] = useState<boolean>(true);

  useEffect(() => {
    if (!isOpen) return;

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#22d3ee', '#a855f7', '#fbbf24', '#10b981']
      });
    } catch {}

    // Animate star reveal one by one with sound
    setRevealedStars(0);
    const starTimers: number[] = [];

    for (let i = 1; i <= stars; i++) {
      const timer = window.setTimeout(() => {
        setRevealedStars(i);
        playStarSound(i);
      }, i * 350);
      starTimers.push(timer);
    }

    // Loop through code lines to demonstrate active execution sync
    const codeLines = (langTab === 'python' ? levelData?.recap?.pythonCode : levelData?.recap?.jsCode) || [];
    let interval: number | undefined;
    if (codeLines.length > 0) {
      interval = window.setInterval(() => {
        setActiveCodeLine((prev) => (prev + 1) % codeLines.length);
      }, 1200);
    }

    return () => {
      starTimers.forEach(clearTimeout);
      if (interval) clearInterval(interval);
    };
  }, [isOpen, stars, langTab, levelData]);

  // Animation loop for BFS / DFS visualizer
  useEffect(() => {
    if (!isOpen || !isAnimPlaying) return;
    const isBfs = levelData.recap?.graphType === 'bfs_queue';
    const isDfs = levelData.recap?.graphType === 'dfs_stack';
    const maxSteps = isBfs ? 5 : isDfs ? 6 : 0;
    if (maxSteps === 0) return;

    const animTimer = window.setInterval(() => {
      setAnimStep((prev) => (prev + 1) % maxSteps);
    }, 2500);

    return () => clearInterval(animTimer);
  }, [isOpen, isAnimPlaying, levelData]);

  if (!isOpen) return null;

  const recap = levelData.recap;
  const currentCodeLines = langTab === 'python' ? recap.pythonCode : recap.jsCode;

  const speedMet = targetTime && completionTime ? completionTime <= targetTime : true;
  const healthMet = heartsLeft !== undefined ? heartsLeft >= maxHearts - 1 : true;

  const isBfsRecap = recap.graphType === 'bfs_queue';
  const isDfsRecap = recap.graphType === 'dfs_stack';

  const BFS_STEPS = [
    {
      title: 'Step 1: Enqueue Start Node [Core L0]',
      action: 'enqueue("Core")',
      queue: ['Core [L0]'],
      visited: ['Core'],
      ring: 'Ring 0',
      desc: 'The traversal begins at the root. Core enters the queue as the only element.'
    },
    {
      title: 'Step 2: Dequeue Core & Enqueue Ring 1 Neighbors',
      action: 'dequeue() -> "Core" | enqueue("North"), enqueue("East"), enqueue("West")',
      queue: ['North [L1]', 'East [L1]', 'West [L1]'],
      visited: ['Core', 'North', 'East', 'West'],
      ring: 'Ring 1 Discovered',
      desc: 'Core leaves the front. All immediate 1-hop neighbors are enqueued at the rear.'
    },
    {
      title: 'Step 3: Dequeue North & Enqueue Ring 2 Neighbors',
      action: 'dequeue() -> "North" | enqueue("NE"), enqueue("NW")',
      queue: ['East [L1]', 'West [L1]', 'NE [L2]', 'NW [L2]'],
      visited: ['Core', 'North', 'East', 'West', 'NE', 'NW'],
      ring: 'Ring 1 Processing',
      desc: 'North is processed. Its unvisited neighbors (NE, NW) enter the rear of the queue.'
    },
    {
      title: 'Step 4: Dequeue East & West',
      action: 'dequeue() -> "East", "West" | enqueue("South [L2]")',
      queue: ['NE [L2]', 'NW [L2]', 'South [L2]'],
      visited: ['Core', 'North', 'East', 'West', 'NE', 'NW', 'South'],
      ring: 'Ring 1 Exhausted',
      desc: 'All Ring 1 nodes have been processed. Now the front holds Ring 2 nodes!'
    },
    {
      title: 'Step 5: Process Ring 2 Concentric Wave',
      action: 'dequeue() Ring 2 nodes -> queue empties',
      queue: [],
      visited: ['Core', 'North', 'East', 'West', 'NE', 'NW', 'South'],
      ring: 'Ring 2 Complete',
      desc: 'Queue ensures strict FIFO concentric expansion: Ring 0 → Ring 1 → Ring 2!'
    }
  ];

  const DFS_STEPS = [
    {
      title: 'Step 1: Push Origin onto Call Stack',
      action: 'stack.push("Origin")',
      stack: ['Origin [Start]'],
      visited: ['Origin'],
      status: 'Initial Call',
      desc: 'DFS initiates at Origin and dives into the first available branch.'
    },
    {
      title: 'Step 2: Dive into Branch Alpha (Depth 1)',
      action: 'stack.push("Alpha-1")',
      stack: ['Origin [Start]', 'Alpha-1 [D1]'],
      visited: ['Origin', 'Alpha-1'],
      status: 'Diving Deep',
      desc: 'Visits Alpha-1. Rather than checking other neighbors, DFS continues deeper.'
    },
    {
      title: 'Step 3: Plunge to Depth 2 & 3',
      action: 'stack.push("Alpha-2"), stack.push("Alpha-Terminus")',
      stack: ['Origin', 'Alpha-1', 'Alpha-2', 'Alpha-Terminus [Leaf]'],
      visited: ['Origin', 'Alpha-1', 'Alpha-2', 'Alpha-Terminus'],
      status: 'Leaf Reached',
      desc: 'Reaches the dead-end leaf terminus. The stack has 4 frames deep!'
    },
    {
      title: 'Step 4: Backtrack from Leaf (LIFO Pop)',
      action: 'stack.pop() -> leaves Alpha-Terminus',
      stack: ['Origin', 'Alpha-1', 'Alpha-2'],
      visited: ['Origin', 'Alpha-1', 'Alpha-2', 'Alpha-Terminus'],
      status: 'Backtracking',
      desc: 'No unvisited neighbors! DFS retreats by popping the top frame from the stack.'
    },
    {
      title: 'Step 5: Backtrack to Origin Fork',
      action: 'stack.pop(), stack.pop() -> back at Origin',
      stack: ['Origin'],
      visited: ['Origin', 'Alpha-1', 'Alpha-2', 'Alpha-Terminus'],
      status: 'Fork Located',
      desc: 'Returns to Origin, finding unvisited Branch Beta ready to explore.'
    },
    {
      title: 'Step 6: Dive into Branch Beta',
      action: 'stack.push("Beta-1") ...',
      stack: ['Origin', 'Beta-1 [D1]'],
      visited: ['Origin', 'Alpha-1', 'Alpha-2', 'Alpha-Terminus', 'Beta-1'],
      status: 'Next Branch',
      desc: 'DFS dives into Beta. Stack perfectly maintains the breadcrumb trail!'
    }
  ];

  const currentBfsStep = BFS_STEPS[animStep % BFS_STEPS.length];
  const currentDfsStep = DFS_STEPS[animStep % DFS_STEPS.length];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-purple-500/50 rounded-2xl shadow-2xl p-4 sm:p-6 my-auto glow-purple">
        {/* Header: Victory Banner & Badge if World Completed */}
        <div className="text-center pb-3 border-b border-purple-500/20">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Level Cleared Successfully</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-300 to-pink-400">
            {recap.conceptName}
          </h2>

          {/* Star Rating Display */}
          <div className="flex items-center justify-center gap-2 mt-3">
            {[1, 2, 3].map((starIdx) => (
              <div
                key={starIdx}
                className={`transition-all duration-300 transform ${
                  starIdx <= revealedStars
                    ? 'scale-110 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.9)]'
                    : 'scale-90 text-slate-700'
                }`}
              >
                <Star
                  className={`w-8 h-8 ${starIdx <= revealedStars ? 'fill-yellow-400' : ''}`}
                />
              </div>
            ))}
          </div>

          {/* Performance Mastery Breakdown */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-3 text-xs">
            {/* Speed criterion */}
            {completionTime !== undefined && (
              <div
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-mono ${
                  speedMet
                    ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>
                  {completionTime.toFixed(1)}s {targetTime ? `(Target: ≤${targetTime}s)` : ''}
                </span>
                {speedMet && <span className="text-[10px] text-emerald-400">★ Speed</span>}
              </div>
            )}

            {/* Health criterion */}
            {heartsLeft !== undefined && (
              <div
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-mono ${
                  healthMet
                    ? 'bg-red-950/40 border-red-500/40 text-red-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Heart className="w-3.5 h-3.5 fill-current" />
                <span>
                  {heartsLeft}/{maxHearts} Hearts
                </span>
                {healthMet && <span className="text-[10px] text-red-400">★ Health</span>}
              </div>
            )}

            {/* Rewards */}
            <div className="flex items-center gap-1.5 text-purple-300 font-mono px-2 py-1 bg-slate-950 rounded-lg border border-slate-800">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>+{xpGained} XP</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-300 font-mono px-2 py-1 bg-slate-950 rounded-lg border border-slate-800">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>+{coinsGained} Crystals</span>
            </div>
          </div>
        </div>

        {/* Special Milestone Badge Banner if Level 5 cleared */}
        {isWorldComplete && (
          <div
            className={`mt-3 p-3 bg-gradient-to-r ${
              worldId === 'array_arena'
                ? 'from-amber-900/60 to-yellow-900/60 border-amber-500/50'
                : worldId === 'graph_city'
                ? 'from-pink-900/60 to-purple-900/60 border-pink-500/50'
                : worldId === 'tree_valley'
                ? 'from-purple-900/60 to-emerald-900/60 border-purple-500/50'
                : worldId === 'queue_river'
                ? 'from-cyan-900/60 to-blue-900/60 border-cyan-500/50'
                : worldId === 'stack_volcano'
                ? 'from-red-900/60 to-amber-900/60 border-amber-500/50'
                : 'from-purple-900/60 to-pink-900/60 border-pink-500/50'
            } border rounded-xl flex items-center gap-3`}
          >
            <div
              className={`p-2.5 rounded-lg ${
                worldId === 'array_arena'
                  ? 'bg-amber-500/20 text-amber-300'
                  : worldId === 'graph_city'
                  ? 'bg-pink-500/20 text-pink-300'
                  : worldId === 'tree_valley'
                  ? 'bg-purple-500/20 text-purple-300'
                  : worldId === 'queue_river'
                  ? 'bg-cyan-500/20 text-cyan-300'
                  : worldId === 'stack_volcano'
                  ? 'bg-amber-500/20 text-amber-300'
                  : 'bg-pink-500/20 text-pink-300'
              }`}
            >
              <Award className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div
                className={`text-xs font-bold uppercase tracking-wider ${
                  worldId === 'array_arena'
                    ? 'text-amber-300'
                    : worldId === 'graph_city'
                    ? 'text-pink-300'
                    : worldId === 'tree_valley'
                    ? 'text-purple-300'
                    : worldId === 'queue_river'
                    ? 'text-cyan-300'
                    : worldId === 'stack_volcano'
                    ? 'text-amber-300'
                    : 'text-pink-300'
                }`}
              >
                WORLD MILESTONE UNLOCKED!
              </div>
              <div className="text-sm font-semibold text-white">
                {worldId === 'array_arena'
                  ? 'Array Gladiator Badge & Algoria Realm Grandmaster'
                  : worldId === 'graph_city'
                  ? 'Graph Navigator Badge & Array Arena Access'
                  : worldId === 'tree_valley'
                  ? 'Tree Whisperer Badge & Graph City Access'
                  : worldId === 'queue_river'
                  ? 'Queue Captain Badge & Tree Valley Access'
                  : worldId === 'stack_volcano'
                  ? 'Stack Climber Badge & Queue River Access'
                  : 'Loop Master Badge & Stack Volcano Access'}
              </div>
            </div>
          </div>
        )}

        {/* Nova Guide Concept Explanation */}
        <div className="mt-4">
          <NovaDialogue
            speakerTitle="Nova · Concept Decompiler"
            mood="proud"
            characterId={characterId}
            message={`${recap.simpleSummary} ${recap.explanationLines[0]}`}
            typingSpeed={16}
          />
        </div>

        {/* Animated BFS Queue Visualizer */}
        {isBfsRecap && (
          <div className="mt-4 bg-slate-950/90 rounded-xl border border-cyan-500/40 p-4 shadow-xl">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-cyan-500/20 text-xs">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white uppercase tracking-wider">
                    BFS Animated Simulation: {currentBfsStep.title}
                  </span>
                  <span className="ml-2 px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30 text-[10px] font-mono">
                    {currentBfsStep.ring}
                  </span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAnimPlaying(!isAnimPlaying)}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title={isAnimPlaying ? 'Pause' : 'Play'}
                >
                  {isAnimPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => setAnimStep((prev) => (prev + 1) % BFS_STEPS.length)}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Next Step"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Queue Visualization Belt */}
            <div className="bg-slate-900 rounded-lg p-3 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                FIFO Queue:
              </div>
              <div className="flex items-center gap-2 overflow-x-auto max-w-full py-1">
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold">
                  FRONT ◀ Dequeue
                </span>
                {currentBfsStep.queue.length > 0 ? (
                  currentBfsStep.queue.map((item, i) => (
                    <div
                      key={i}
                      className="px-2.5 py-1 rounded bg-cyan-500/20 border border-cyan-400 text-cyan-200 text-xs font-bold"
                    >
                      {item}
                    </div>
                  ))
                ) : (
                  <span className="text-xs text-slate-500 italic">Queue Empty</span>
                )}
                <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-500/40 text-[10px] font-bold">
                  REAR ◀ Enqueue
                </span>
              </div>
            </div>

            {/* Step description and code action */}
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-slate-300">{currentBfsStep.desc}</span>
              <span className="font-mono text-[11px] text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30">
                Action: {currentBfsStep.action}
              </span>
            </div>
          </div>
        )}

        {/* Animated DFS Stack Visualizer */}
        {isDfsRecap && (
          <div className="mt-4 bg-slate-950/90 rounded-xl border border-purple-500/40 p-4 shadow-xl">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-purple-500/20 text-xs">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300">
                  <GitCommit className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-white uppercase tracking-wider">
                    DFS Animated Simulation: {currentDfsStep.title}
                  </span>
                  <span className="ml-2 px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-500/30 text-[10px] font-mono">
                    {currentDfsStep.status}
                  </span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAnimPlaying(!isAnimPlaying)}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title={isAnimPlaying ? 'Pause' : 'Play'}
                >
                  {isAnimPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => setAnimStep((prev) => (prev + 1) % DFS_STEPS.length)}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Next Step"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Stack Visualizer */}
            <div className="bg-slate-900 rounded-lg p-3 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                LIFO Call Stack:
              </div>
              <div className="flex items-center gap-2 overflow-x-auto max-w-full py-1">
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                  TOP ◀ Push / Pop
                </span>
                {currentDfsStep.stack.map((item, i) => (
                  <div
                    key={i}
                    className={`px-2.5 py-1 rounded border text-xs font-bold ${
                      i === currentDfsStep.stack.length - 1
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                        : 'bg-purple-950/60 border-purple-500/40 text-purple-200'
                    }`}
                  >
                    {item}
                  </div>
                ))}
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-bold">
                  BOTTOM
                </span>
              </div>
            </div>

            {/* Step description and code action */}
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-slate-300">{currentDfsStep.desc}</span>
              <span className="font-mono text-[11px] text-purple-300 bg-purple-950/80 px-2 py-0.5 rounded border border-purple-500/30">
                Action: {currentDfsStep.action}
              </span>
            </div>
          </div>
        )}

        {/* Animated Synchronized Code Viewer */}
        <div className="mt-4 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
          {/* Language Switcher Bar */}
          <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800 text-xs">
            <span className="text-slate-400 font-mono">Algorithm Source</span>
            <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800">
              <button
                onClick={() => {
                  playButtonClick();
                  setLangTab('python');
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-colors cursor-pointer ${
                  langTab === 'python'
                    ? 'bg-purple-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Python
              </button>
              <button
                onClick={() => {
                  playButtonClick();
                  setLangTab('js');
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-colors cursor-pointer ${
                  langTab === 'js'
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                JavaScript
              </button>
            </div>
          </div>

          {/* Code lines with active step highlighting */}
          <div className="p-3 font-mono text-xs sm:text-sm leading-relaxed overflow-x-auto">
            {currentCodeLines.map((line: string, index: number) => {
              const isActive = index === activeCodeLine;
              return (
                <div
                  key={index}
                  className={`flex items-center gap-3 px-2 py-1 rounded transition-colors duration-200 ${
                    isActive
                      ? 'bg-cyan-950/80 text-cyan-200 border-l-2 border-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="w-5 text-right text-slate-600 select-none text-[11px]">
                    {index + 1}
                  </span>
                  <span className="whitespace-pre">{line}</span>
                  {isActive && (
                    <span className="ml-auto text-[10px] text-cyan-400 tracking-wider uppercase font-sans animate-pulse">
                      ◀ Executing
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="mt-5 pt-3 border-t border-purple-500/20 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {onGoHome && (
              <button
                onClick={() => {
                  playButtonClick();
                  onGoHome();
                }}
                className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-cyan-300 hover:text-white rounded-xl text-xs sm:text-sm font-semibold border border-cyan-500/40 hover:border-cyan-400 transition-colors cursor-pointer active:scale-95"
                title="Return to Home Screen"
              >
                <Home className="w-4 h-4 text-cyan-400" />
                <span>Home</span>
              </button>
            )}

            {onExitToMap && (
              <button
                onClick={() => {
                  playButtonClick();
                  onExitToMap();
                }}
                className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs sm:text-sm font-semibold border border-slate-700 hover:border-slate-500 transition-colors cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4 text-slate-400" />
                <span>Back to Map</span>
              </button>
            )}

            <button
              onClick={() => {
                playButtonClick();
                onReplay();
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs sm:text-sm font-medium transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Replay Level</span>
            </button>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              onNextLevel();
            }}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-purple-500/30 transition-all cursor-pointer active:scale-95"
          >
            <span>{levelData.id < 5 ? 'Next Level' : 'Return to World Map'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
