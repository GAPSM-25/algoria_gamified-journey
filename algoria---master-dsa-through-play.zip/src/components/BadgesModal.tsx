import React from 'react';
import {
  Award,
  X,
  Trees,
  Flame,
  Waves,
  GitBranch,
  Network,
  Boxes,
  Zap,
  Sparkles,
  Lock,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface BadgesModalProps {
  isOpen: boolean;
  onClose: () => void;
  earnedBadges?: string[];
  userBadges?: string[];
  completedLevels?: any;
}

interface BadgeInfo {
  id: string;
  title: string;
  sector: string;
  description: string;
  rewardXp: number;
  icon: any;
  color: string;
  borderColor: string;
  bgGlow: string;
}

const ALL_BADGES: BadgeInfo[] = [
  {
    id: 'loop_master',
    title: 'Loop Master',
    sector: 'Sector 01: Loop Forest',
    description: 'Mastered iteration! Automated 5 sequential challenges using for-loops and nested iterations.',
    rewardXp: 250,
    icon: Trees,
    color: 'text-emerald-400',
    borderColor: 'border-emerald-500/40',
    bgGlow: 'bg-emerald-950/40'
  },
  {
    id: 'stack_climber',
    title: 'Stack Climber',
    sector: 'Sector 02: Stack Volcano',
    description: 'Conquered LIFO principles! Mastered Push, Pop, Peek, Word Inversion, and Syntax Balancing.',
    rewardXp: 300,
    icon: Flame,
    color: 'text-red-400',
    borderColor: 'border-red-500/40',
    bgGlow: 'bg-red-950/40'
  },
  {
    id: 'queue_captain',
    title: 'Queue Captain',
    sector: 'Sector 03: Queue River',
    description: 'Guaranteed strictly first-in, first-out order across river docks and priority VIP scheduling.',
    rewardXp: 350,
    icon: Waves,
    color: 'text-cyan-400',
    borderColor: 'border-cyan-500/40',
    bgGlow: 'bg-cyan-950/40'
  },
  {
    id: 'tree_whisperer',
    title: 'Tree Whisperer',
    sector: 'Sector 04: Tree Valley',
    description: 'Climbed the ancient binary trees with Preorder, Inorder, Postorder traversals and BST search.',
    rewardXp: 400,
    icon: GitBranch,
    color: 'text-purple-400',
    borderColor: 'border-purple-500/40',
    bgGlow: 'bg-purple-950/40'
  },
  {
    id: 'graph_navigator',
    title: 'Graph Navigator',
    sector: 'Sector 05: Graph City',
    description: 'Navigated the cyber grid survival storm using BFS radial waves, DFS deep dives, and Dijkstra.',
    rewardXp: 450,
    icon: Network,
    color: 'text-pink-400',
    borderColor: 'border-pink-500/40',
    bgGlow: 'bg-pink-950/40'
  },
  {
    id: 'array_gladiator',
    title: 'Array Gladiator',
    sector: 'Sector 06: Array Arena',
    description: 'Achieved mastery over 0-indexing, animated Bubble Sort, Binary Search halving, and Two-Pointers.',
    rewardXp: 500,
    icon: Boxes,
    color: 'text-amber-400',
    borderColor: 'border-amber-500/40',
    bgGlow: 'bg-amber-950/40'
  },
  {
    id: 'speed_demon',
    title: 'Speed Demon',
    sector: 'Honorary Distinction',
    description: 'Beat any sector benchmark time with at least 3 seconds to spare. Optimal algorithmic velocity.',
    rewardXp: 150,
    icon: Zap,
    color: 'text-yellow-400',
    borderColor: 'border-yellow-500/40',
    bgGlow: 'bg-yellow-950/40'
  },
  {
    id: 'streak_champion',
    title: 'Streak Champion',
    sector: 'Consistency Distinction',
    description: 'Logged into Algoria for 3 consecutive days to sharpen algorithmic mental reflexes.',
    rewardXp: 200,
    icon: Calendar,
    color: 'text-orange-400',
    borderColor: 'border-orange-500/40',
    bgGlow: 'bg-orange-950/40'
  }
];

export const BadgesModal: React.FC<BadgesModalProps> = ({
  isOpen,
  onClose,
  earnedBadges,
  userBadges = []
}) => {
  if (!isOpen) return null;

  const activeBadges = earnedBadges || userBadges || [];
  const earnedCount = ALL_BADGES.filter((b) => activeBadges.includes(b.id)).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl bg-slate-950/95 border border-cyan-500/30 rounded-3xl p-6 sm:p-7 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            playButtonClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <Award className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
              <span>Hall of Algorithmic Badges</span>
              <Sparkles className="w-5 h-5 text-purple-400" />
            </h2>
            <p className="text-xs text-slate-400">
              Honors earned across Algoria sectors. {earnedCount} of {ALL_BADGES.length} Badges Unlocked!
            </p>
          </div>
        </div>

        {/* Badges Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 overflow-y-auto pr-1">
          {ALL_BADGES.map((badge) => {
            const isEarned = activeBadges.includes(badge.id);
            const IconComponent = badge.icon;

            return (
              <div
                key={badge.id}
                className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                  isEarned
                    ? `${badge.bgGlow} ${badge.borderColor} shadow-lg`
                    : 'bg-slate-950/50 border-slate-800 opacity-60'
                }`}
              >
                <div
                  className={`p-3 rounded-xl shrink-0 ${
                    isEarned
                      ? `bg-slate-900 border ${badge.borderColor} ${badge.color}`
                      : 'bg-slate-900 text-slate-600 border border-slate-800'
                  }`}
                >
                  {isEarned ? <IconComponent className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className={`text-sm font-bold truncate ${isEarned ? 'text-white' : 'text-slate-400'}`}>
                      {badge.title}
                    </h3>
                    {isEarned ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950 border border-emerald-500/30 px-2 py-0.5 rounded-full shrink-0">
                        <CheckCircle2 className="w-3 h-3" />
                        EARNED
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-500 font-mono shrink-0">LOCKED</span>
                    )}
                  </div>

                  <div className="text-[10px] font-mono text-slate-400 mt-0.5">{badge.sector}</div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{badge.description}</p>

                  <div className="mt-2 text-[11px] font-mono font-bold text-purple-300">
                    +{badge.rewardXp} XP Honor
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
