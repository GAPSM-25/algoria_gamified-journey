import React from 'react';
import {
  Boxes,
  Play,
  RotateCcw,
  Zap,
  ArrowRight,
  Sparkles,
  HelpCircle,
  Divide,
  FastForward,
  CheckCircle2,
  GitCompare
} from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface ArrayControlPanelProps {
  levelId: number;
  levelType: string;
  targetCount: number;
  currentCount: number;
  arrayData?: any[];
  currentQuery?: any;
  currentQueryIdx?: number;
  totalQueries?: number;
  low?: number;
  high?: number;
  mid?: number;
  botIndex?: number;
  playerSteps?: number;
  leftPtr?: number;
  rightPtr?: number;
  isSorting?: boolean;
  isReplaying?: boolean;
  onSlotPick?: (index: number) => void;
  onBubbleStep?: () => void;
  onBubbleAutoRun?: () => void;
  onRaceStep?: () => void;
  onHalveChoice?: (choice: 'left' | 'right' | 'found') => void;
  onTwoPointersSwap?: () => void;
  onNovaReplay?: () => void;
}

export const ArrayControlPanel: React.FC<ArrayControlPanelProps> = ({
  levelId,
  levelType,
  targetCount,
  currentCount,
  arrayData = [],
  currentQuery,
  currentQueryIdx = 0,
  totalQueries = 4,
  low = 0,
  high = 8,
  mid = 4,
  botIndex = 0,
  playerSteps = 0,
  leftPtr = 0,
  rightPtr = 5,
  isSorting = false,
  isReplaying = false,
  onSlotPick,
  onBubbleStep,
  onBubbleAutoRun,
  onRaceStep,
  onHalveChoice,
  onTwoPointersSwap,
  onNovaReplay
}) => {
  const isIndexLookup = levelType === 'array_index_lookup';
  const isBubbleSort = levelType === 'bubble_sort';
  const isRace = levelType === 'search_race';
  const isHalving = levelType === 'binary_search_halving';
  const isTwoPointers = levelType === 'two_pointers';

  return (
    <div className="bg-slate-900/95 border border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-md flex flex-col gap-4">
      {/* Top Telemetry Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-amber-500/20 text-xs sm:text-sm">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
              Array Arena Control
            </div>
            <div className="font-mono font-bold text-white flex items-center gap-2">
              <span className="text-amber-300">
                {isIndexLookup
                  ? 'Memory Addressing Mode'
                  : isBubbleSort
                  ? 'Bubble Sort Engine'
                  : isRace
                  ? 'O(N) vs O(log N) Race'
                  : isHalving
                  ? 'Binary Interval Halving'
                  : 'Two-Pointers Convergence'}
              </span>
            </div>
          </div>
        </div>

        {/* Action Controls & AI Companion Replay */}
        <div className="flex items-center gap-2">
          {onNovaReplay && (
            <button
              onClick={() => {
                playButtonClick();
                onNovaReplay();
              }}
              disabled={isReplaying || isSorting}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-900/70 to-pink-900/70 border border-purple-500/40 hover:border-pink-400 text-purple-200 text-xs font-bold transition-all active:scale-95 disabled:opacity-50 cursor-pointer shadow-md"
              title="Watch Nova demonstrate the algorithmic solution step-by-step"
            >
              <Sparkles className="w-3.5 h-3.5 text-pink-300 animate-spin" />
              <span>Watch Nova do it</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Progress:</span>
            <span className="font-bold text-amber-300">
              {currentCount} / {targetCount}
            </span>
          </div>
        </div>
      </div>

      {/* LEVEL 1: ZERO-INDEXED LOOKUP */}
      {isIndexLookup && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Active Query:</div>
                <div className="font-mono font-bold text-amber-200 text-sm">
                  {currentQuery?.prompt || 'Click a memory slot [0..5]'}
                </div>
              </div>
            </div>
            <div className="text-right font-mono text-[11px] text-slate-400">
              Query {currentQueryIdx + 1} of {totalQueries}
            </div>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {[0, 1, 2, 3, 4, 5].map((idx) => (
              <button
                key={idx}
                onClick={() => {
                  playButtonClick();
                  if (onSlotPick) onSlotPick(idx);
                }}
                className="py-3 px-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-400 hover:bg-amber-950/30 text-center font-mono transition-all active:scale-95 cursor-pointer"
              >
                <div className="text-[10px] text-slate-400">Index</div>
                <div className="text-base font-bold text-amber-300">[ {idx} ]</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* LEVEL 2: BUBBLE SORT */}
      {isBubbleSort && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <GitCompare className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-300">
                Rule: Compare adjacent pairs <span className="font-mono text-cyan-300">arr[j]</span> and{' '}
                <span className="font-mono text-cyan-300">arr[j+1]</span>. Swap if left is greater!
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                playButtonClick();
                if (onBubbleStep) onBubbleStep();
              }}
              disabled={isSorting}
              className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <FastForward className="w-4 h-4 text-cyan-400" />
              <span>Step Compare &amp; Swap</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                if (onBubbleAutoRun) onBubbleAutoRun();
              }}
              disabled={isSorting}
              className={`flex-1 py-3 px-4 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer ${
                isSorting
                  ? 'bg-amber-950/80 border border-amber-500/60 text-amber-300 animate-pulse'
                  : 'bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 hover:shadow-amber-500/25'
              }`}
            >
              <Play className={`w-4 h-4 fill-current ${isSorting ? 'animate-spin' : ''}`} />
              <span>{isSorting ? 'Auto-Sorting in Progress...' : 'Auto-Run Bubble Sort'}</span>
            </button>
          </div>
        </div>
      )}

      {/* LEVEL 3: CORRIDOR RACE */}
      {isRace && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-950/80 border border-cyan-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4">
              <div className="font-mono">
                <span className="text-red-400 font-bold">Rogue Bot (O(N)):</span> Slot {botIndex} / 15
              </div>
              <div className="font-mono">
                <span className="text-cyan-400 font-bold">Player (O(log N)):</span> Step {playerSteps} / 4
              </div>
            </div>
            <div className="font-mono text-amber-300 font-bold">
              Target Value: 81
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              if (onRaceStep) onRaceStep();
            }}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            <Divide className="w-4 h-4" />
            <span>Halve Interval (Inspect Midpoint arr[{mid}])</span>
          </button>
        </div>
      )}

      {/* LEVEL 4: BINARY SEARCH WITH HALVING */}
      {isHalving && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div>
              [LOW: <span className="text-emerald-400 font-bold">{low}</span>]
              {' · '}
              [MID: <span className="text-cyan-400 font-bold">{mid}</span>]
              {' · '}
              [HIGH: <span className="text-red-400 font-bold">{high}</span>]
            </div>
            <div className="text-amber-300 font-bold">
              Target: 55
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              onClick={() => {
                playButtonClick();
                if (onHalveChoice) onHalveChoice('left');
              }}
              className="py-3 px-3 rounded-xl bg-slate-950 border border-slate-700 hover:border-cyan-400 hover:bg-cyan-950/30 text-cyan-200 text-xs font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Discard Left (low = mid + 1)</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                if (onHalveChoice) onHalveChoice('found');
              }}
              className="py-3 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Target Found at arr[{mid}]!</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                if (onHalveChoice) onHalveChoice('right');
              }}
              className="py-3 px-3 rounded-xl bg-slate-950 border border-slate-700 hover:border-pink-400 hover:bg-pink-950/30 text-pink-200 text-xs font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Discard Right (high = mid - 1)</span>
            </button>
          </div>
        </div>
      )}

      {/* LEVEL 5: TWO POINTERS */}
      {isTwoPointers && (
        <div className="flex flex-col gap-3">
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div>
              <span className="text-cyan-400 font-bold">LEFT: index {leftPtr}</span>
              {' ⟷ '}
              <span className="text-pink-400 font-bold">RIGHT: index {rightPtr}</span>
            </div>
            <div className="text-slate-400">
              In-Place Reversal: O(N) time, O(1) space
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              if (onTwoPointersSwap) onTwoPointersSwap();
            }}
            disabled={leftPtr >= rightPtr}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-purple-600 hover:from-amber-500 hover:to-purple-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer disabled:opacity-50"
          >
            <GitCompare className="w-4 h-4" />
            <span>
              {leftPtr >= rightPtr
                ? 'Array Reversal Complete!'
                : `Swap arr[${leftPtr}] ⟷ arr[${rightPtr}] & Converge Pointers`}
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
