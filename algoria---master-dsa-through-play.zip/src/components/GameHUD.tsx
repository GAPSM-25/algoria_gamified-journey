import React from 'react';
import { Heart, Coins, Zap, Star, HelpCircle, RotateCcw, Volume2, VolumeX, ArrowLeft, Clock, Sparkles, Home } from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

import { CharacterAvatar } from './CharacterAvatar.tsx';
import { CHARACTERS } from '../api/gameApi.js';

interface GameHUDProps {
  hearts: number;
  maxHearts: number;
  xp: number;
  coins: number;
  stars: number;
  currentProgress: number;
  totalTarget: number;
  levelTitle: string;
  isMuted: boolean;
  onToggleMute: () => void;
  onHint: () => void;
  hintCooldown: number;
  maxHintCooldown: number;
  elapsedTime?: number;
  targetTime?: number;
  onRetry: () => void;
  onExitToMap: () => void;
  onGoHome?: () => void;
  outerLoop?: number;
  innerLoop?: number;
  onNovaReplay?: () => void;
  characterId?: string;
  onOpenNovaHelper?: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hearts,
  maxHearts,
  xp,
  coins,
  stars,
  currentProgress,
  totalTarget,
  levelTitle,
  isMuted,
  onToggleMute,
  onHint,
  hintCooldown,
  maxHintCooldown,
  elapsedTime,
  targetTime,
  onRetry,
  onExitToMap,
  onGoHome,
  outerLoop,
  innerLoop,
  onNovaReplay,
  characterId = 'bit_byte',
  onOpenNovaHelper
}) => {
  const charConfig = CHARACTERS.find((c) => c.id === characterId) || CHARACTERS[0];

  return (
    <header className="w-full bg-slate-950/95 border-b border-purple-500/25 px-3 sm:px-6 py-2.5 backdrop-blur-md sticky top-0 z-40 shadow-lg shadow-black/40">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Prominent Back to Map & Home buttons, Player Avatar & Level title */}
        <div className="flex items-center gap-2">
          {onGoHome && (
            <button
              onClick={() => {
                playButtonClick();
                onGoHome();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-cyan-300 hover:text-white text-xs font-bold rounded-xl border border-cyan-500/40 hover:border-cyan-400 shadow-sm transition-all cursor-pointer group active:scale-95"
              title="Return to Home Screen"
            >
              <Home className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span>Home</span>
            </button>
          )}

          <button
            onClick={() => {
              playButtonClick();
              onExitToMap();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold rounded-xl border border-slate-700 hover:border-slate-500 shadow-sm transition-all cursor-pointer group active:scale-95"
            title="Go Back to Map Selection (or press Esc)"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-slate-400 group-hover:-translate-x-0.5 transition-transform" />
            <span className="tracking-wide">Map</span>
          </button>

          {/* Active Player Character Avatar Badge */}
          <div
            className="flex items-center gap-2 px-2 py-1 bg-slate-900/90 border border-purple-500/30 rounded-xl"
            title={`${charConfig.name}: ${charConfig.perk}`}
          >
            <CharacterAvatar characterId={characterId} size={28} />
            <span className="text-[11px] font-bold text-slate-200 hidden md:inline">
              {charConfig.name}
            </span>
          </div>

          <div className="h-4 w-px bg-slate-800 hidden sm:block" />

          <div>
            <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide truncate max-w-[180px] sm:max-w-xs">
              {levelTitle}
            </h2>
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2">
              <span>
                Progress: <strong className="text-cyan-300">{currentProgress}</strong> / {totalTarget}
              </span>
              {outerLoop !== undefined && innerLoop !== undefined && (
                <span className="text-purple-300 font-bold">
                  [Grove {outerLoop} · Tree {innerLoop}]
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Center: Vital Player Stats (Hearts, XP, Coins, Stars, Timer) */}
        <div className="flex items-center gap-2.5 sm:gap-4 text-xs sm:text-sm">
          {/* Hearts */}
          <div className="flex items-center gap-1 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-red-500/30">
            {Array.from({ length: maxHearts }).map((_, i) => (
              <Heart
                key={i}
                className={`w-4 h-4 transition-all duration-300 ${
                  i < hearts
                    ? 'text-red-500 fill-red-500 filter drop-shadow-[0_0_6px_rgba(239,68,68,0.7)]'
                    : 'text-slate-700 fill-slate-800'
                }`}
              />
            ))}
          </div>

          {/* XP */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-purple-500/30">
            <Zap className="w-4 h-4 text-purple-400 fill-purple-400/30" />
            <span className="font-mono font-bold text-purple-300 tabular-nums">{xp}</span>
            <span className="text-[10px] text-slate-400 hidden sm:inline">XP</span>
          </div>

          {/* Coins */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-amber-500/30">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono font-bold text-amber-300 tabular-nums">{coins}</span>
          </div>

          {/* Stars */}
          <div className="flex items-center gap-0.5 bg-slate-900/90 px-2 py-1 rounded-lg border border-yellow-500/30">
            {[1, 2, 3].map((starIdx) => (
              <Star
                key={starIdx}
                className={`w-3.5 h-3.5 ${
                  starIdx <= stars
                    ? 'text-yellow-400 fill-yellow-400 filter drop-shadow-[0_0_4px_rgba(250,204,21,0.8)]'
                    : 'text-slate-700'
                }`}
              />
            ))}
          </div>

          {/* Timer */}
          {elapsedTime !== undefined && (
            <div className="hidden sm:flex items-center gap-1.5 bg-slate-900/90 px-2 py-1 rounded-lg border border-slate-800 text-xs font-mono text-slate-400">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span className="tabular-nums text-slate-200">{elapsedTime.toFixed(1)}s</span>
            </div>
          )}
        </div>

        {/* Right: Functional Action buttons (Watch Nova Replay, Hint with Cooldown, Retry, Mute) */}
        <div className="flex items-center gap-2">
          {/* Watch Nova Replay Button */}
          {onNovaReplay && (
            <button
              onClick={() => {
                playButtonClick();
                onNovaReplay();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-amber-500/50 bg-amber-950/60 hover:bg-amber-900/70 text-amber-300 text-xs font-semibold shadow-sm hover:shadow-amber-500/20 transition-all cursor-pointer active:scale-95"
              title="Watch Nova demonstrate optimal algorithmic steps"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Watch Nova</span>
            </button>
          )}

          {/* Nova Helper Voice Guide Button */}
          {onOpenNovaHelper && (
            <button
              onClick={() => {
                playButtonClick();
                onOpenNovaHelper();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/50 bg-gradient-to-r from-purple-950/90 to-cyan-950/90 hover:from-purple-900 hover:to-cyan-900 text-cyan-300 hover:text-white text-xs font-bold shadow-md hover:shadow-cyan-500/20 transition-all cursor-pointer active:scale-95 group"
              title="Open Nova Helper with Voice Guidance"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-12 transition-transform" />
              <span>Nova Helper</span>
            </button>
          )}

          {/* Hint Button with Cooldown Display */}
          <button
            onClick={() => {
              if (hintCooldown <= 0) {
                playButtonClick();
                onHint();
              }
            }}
            disabled={hintCooldown > 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              hintCooldown > 0
                ? 'bg-slate-900/90 border-slate-800 text-slate-500 cursor-not-allowed opacity-80'
                : 'bg-purple-950/70 hover:bg-purple-900 text-cyan-300 border-purple-500/50 hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-500/20 cursor-pointer active:scale-95'
            }`}
            title={
              hintCooldown > 0
                ? `Hint recharging: ${hintCooldown}s remaining`
                : 'Get an algorithmic contextual hint from Nova'
            }
          >
            <HelpCircle
              className={`w-3.5 h-3.5 ${hintCooldown > 0 ? 'text-slate-600' : 'text-cyan-400'}`}
            />
            {hintCooldown > 0 ? (
              <span className="font-mono text-[11px] tabular-nums text-purple-400">
                Hint ({hintCooldown}s)
              </span>
            ) : (
              <span>Hint</span>
            )}
          </button>

          <button
            onClick={() => {
              playButtonClick();
              onRetry();
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs rounded-lg border border-slate-800 transition-colors cursor-pointer"
            title="Restart Level"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Retry</span>
          </button>

          <button
            onClick={() => {
              playButtonClick();
              onToggleMute();
            }}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              isMuted
                ? 'bg-red-950/40 border-red-500/30 text-red-400'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-300'
            }`}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
