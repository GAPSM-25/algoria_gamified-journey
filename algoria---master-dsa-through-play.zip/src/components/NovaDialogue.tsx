import React, { useState, useEffect, useRef } from 'react';
import { NovaRobot } from './NovaRobot.tsx';
import { playTypewriterSound, playButtonClick } from '../utils/audio.ts';
import { FastForward } from 'lucide-react';

interface NovaDialogueProps {
  message: string;
  mood?: 'happy' | 'excited' | 'curious' | 'serious' | 'surprised' | 'proud';
  speakerTitle?: string;
  characterId?: string;
  onComplete?: () => void;
  actionButtonText?: string;
  onAction?: () => void;
  typingSpeed?: number;
  className?: string;
}

export const NovaDialogue: React.FC<NovaDialogueProps> = ({
  message,
  mood = 'happy',
  speakerTitle = 'Nova · Guide AI',
  characterId = 'bit_byte',
  onComplete,
  actionButtonText,
  onAction,
  typingSpeed = 22,
  className = ''
}) => {
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  const indexRef = useRef(0);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    // Reset typing on message change
    setDisplayedText('');
    setIsTyping(true);
    indexRef.current = 0;

    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = window.setInterval(() => {
      if (indexRef.current < message.length) {
        indexRef.current += 1;
        setDisplayedText(message.slice(0, indexRef.current));
        // Periodic gentle chirp sound every 3 characters
        if (indexRef.current % 3 === 0) {
          playTypewriterSound();
        }
      } else {
        if (timerRef.current) clearInterval(timerRef.current);
        setIsTyping(false);
        if (onComplete) onComplete();
      }
    }, typingSpeed);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [message, typingSpeed]);

  const handleSkip = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setDisplayedText(message);
    setIsTyping(false);
    playButtonClick();
    if (onComplete) onComplete();
  };

  return (
    <div className={`flex items-start gap-3 sm:gap-4 ${className}`}>
      {/* Nova Robot Sprite */}
      <div className="shrink-0 pt-1">
        <NovaRobot mood={mood} size={64} isFloating={true} characterId={characterId} />
      </div>

      {/* Dialogue Speech Bubble */}
      <div className="relative flex-1 bg-slate-900/90 border border-purple-500/40 rounded-2xl rounded-tl-sm p-4 sm:p-5 shadow-xl backdrop-blur-md">
        {/* Header row with speaker title and skip */}
        <div className="flex items-center justify-between pb-2 mb-1 border-b border-purple-500/20 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-cyan-300 tracking-wide">{speakerTitle}</span>
            <span className="text-purple-400/60">·</span>
            <span className="text-purple-300/70 text-[11px] capitalize">{mood} status</span>
          </div>

          {isTyping && (
            <button
              onClick={handleSkip}
              className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-cyan-300 transition-colors cursor-pointer px-2 py-0.5 rounded hover:bg-purple-950/40"
              title="Skip typing animation"
            >
              <span>Skip</span>
              <FastForward className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Message Content */}
        <p className="text-slate-100 text-sm sm:text-base leading-relaxed min-h-[44px]">
          {displayedText}
          {isTyping && (
            <span className="inline-block w-2 h-4 ml-1 bg-cyan-400 animate-pulse align-middle" />
          )}
        </p>

        {/* Action Button if provided */}
        {actionButtonText && onAction && !isTyping && (
          <div className="mt-3 pt-2 flex justify-end">
            <button
              onClick={() => {
                playButtonClick();
                onAction();
              }}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-medium text-xs sm:text-sm rounded-lg shadow-lg hover:shadow-cyan-500/25 transition-all cursor-pointer whitespace-nowrap active:scale-95"
            >
              {actionButtonText}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
