import React, { useState } from 'react';
import {
  Sparkles,
  GitBranch,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Search,
  Ruler,
  Layers,
  Code2,
  ChevronDown,
  ChevronUp,
  Cpu,
  Compass
} from 'lucide-react';
import { playButtonClick } from '../utils/audio.ts';

interface TreeControlPanelProps {
  levelId: number;
  levelType: string;
  traversalMode?: 'preorder' | 'inorder' | 'postorder';
  expectedSequence?: number[];
  harvestedValues?: number[];
  currentNodeVal?: number;
  incomingFruit?: number;
  searchTarget?: number;
  searchPhase?: 'search' | 'height';
  targetCount: number;
  currentCount: number;
  onTriggerGhostPath?: () => void;
  onNodeClick?: (val: number) => void;
  onNavigateChoice?: (dir: 'left' | 'right') => void;
  onConfirmTargetFound?: () => void;
  onSubmitTreeHeight?: (height: number) => void;
}

export const TreeControlPanel: React.FC<TreeControlPanelProps> = ({
  levelId,
  levelType,
  traversalMode = 'preorder',
  expectedSequence = [],
  harvestedValues = [],
  currentNodeVal = 50,
  incomingFruit,
  searchTarget = 65,
  searchPhase = 'search',
  targetCount,
  currentCount,
  onTriggerGhostPath,
  onNodeClick,
  onNavigateChoice,
  onConfirmTargetFound,
  onSubmitTreeHeight
}) => {
  const [showCodeDrawer, setShowCodeDrawer] = useState<boolean>(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'python' | 'ts'>('python');

  const isTraversal = levelType === 'tree_traversal';
  const isInsertion = levelType === 'bst_insertion';
  const isSearchAndHeight = levelType === 'bst_search_and_height';

  const nextTargetVal = expectedSequence[harvestedValues.length];

  // ==========================================
  // LEVELS 1, 2, 3: TRAVERSALS (PRE, IN, POST)
  // ==========================================
  if (isTraversal) {
    const traversalConfigs: Record<
      string,
      {
        title: string;
        orderFormula: string;
        academicName: string;
        color: string;
        accentBorder: string;
        complexity: string;
        spaceComplexity: string;
        pyCode: string[];
        tsCode: string[];
      }
    > = {
      preorder: {
        title: 'PREORDER TRAVERSAL',
        orderFormula: 'Visit(Node) → Recurse(Left) → Recurse(Right)',
        academicName: 'Depth-First Search (Prefix Tree Serialization)',
        color: 'text-amber-400',
        accentBorder: 'border-amber-500/40',
        complexity: 'O(N)',
        spaceComplexity: 'O(H) Call Stack',
        pyCode: [
          'def preorder(node):',
          '    if not node: return []',
          '    # Root -> Left -> Right',
          '    return [node.val] + preorder(node.left) + preorder(node.right)'
        ],
        tsCode: [
          'function preorder(node: TreeNode | null): number[] {',
          '    if (!node) return [];',
          '    // Root -> Left -> Right',
          '    return [node.val, ...preorder(node.left), ...preorder(node.right)];',
          '}'
        ]
      },
      inorder: {
        title: 'INORDER TRAVERSAL',
        orderFormula: 'Recurse(Left) → Visit(Node) → Recurse(Right)',
        academicName: 'Ascending Key Extraction (Sorted BST)',
        color: 'text-cyan-400',
        accentBorder: 'border-cyan-500/40',
        complexity: 'O(N)',
        spaceComplexity: 'O(H) Call Stack',
        pyCode: [
          'def inorder(node):',
          '    if not node: return []',
          '    # Left -> Root -> Right (Produces Sorted Array on BST!)',
          '    return inorder(node.left) + [node.val] + inorder(node.right)'
        ],
        tsCode: [
          'function inorder(node: TreeNode | null): number[] {',
          '    if (!node) return [];',
          '    // Left -> Root -> Right',
          '    return [...inorder(node.left), node.val, ...inorder(node.right)];',
          '}'
        ]
      },
      postorder: {
        title: 'POSTORDER TRAVERSAL',
        orderFormula: 'Recurse(Left) → Recurse(Right) → Visit(Node)',
        academicName: 'Bottom-Up Evaluation (Tree Freeing & Syntax Trees)',
        color: 'text-purple-400',
        accentBorder: 'border-purple-500/40',
        complexity: 'O(N)',
        spaceComplexity: 'O(H) Call Stack',
        pyCode: [
          'def postorder(node):',
          '    if not node: return []',
          '    # Left -> Right -> Root (Bottom-up guarantee)',
          '    return postorder(node.left) + postorder(node.right) + [node.val]'
        ],
        tsCode: [
          'function postorder(node: TreeNode | null): number[] {',
          '    if (!node) return [];',
          '    // Left -> Right -> Root',
          '    return [...postorder(node.left), ...postorder(node.right), node.val];',
          '}'
        ]
      }
    };

    const cfg = traversalConfigs[traversalMode] || traversalConfigs.preorder;

    return (
      <div className="p-3 sm:p-4 bg-slate-900/95 border border-purple-500/40 rounded-2xl shadow-2xl backdrop-blur-md">
        {/* Academic Header Banner */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-3 border-b border-purple-500/20 text-xs">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-purple-400 animate-pulse" />
            <span className={`font-black tracking-wide ${cfg.color}`}>{cfg.title}</span>
            <span className="text-slate-500 hidden sm:inline">|</span>
            <span className="text-slate-300 font-mono text-[11px] hidden sm:inline">
              {cfg.academicName}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/30 text-[10px] font-mono text-purple-300">
              Time: {cfg.complexity}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-500/30 text-[10px] font-mono text-indigo-300">
              Space: {cfg.spaceComplexity}
            </span>
            <div className="font-mono text-slate-300 text-xs pl-1">
              Harvested:{' '}
              <span className="text-yellow-400 font-bold">
                {currentCount}/{targetCount}
              </span>
            </div>
          </div>
        </div>

        {/* Mathematical Invariant Formula Card */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 mb-3">
          <div className="md:col-span-8 bg-slate-950/85 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                Active Traversal Invariant
              </div>
              <div className="text-xs sm:text-sm font-mono font-bold text-slate-100 mt-0.5">
                {cfg.orderFormula}
              </div>
            </div>
            <div className="text-right pl-2 shrink-0">
              <span className="text-[10px] font-mono text-slate-500 block">EXPECTED NEXT</span>
              <span className="text-sm font-mono font-black text-yellow-300 bg-yellow-950/50 px-2.5 py-0.5 rounded border border-yellow-500/40">
                {nextTargetVal !== undefined ? `[ ${nextTargetVal} ]` : 'ALL HARVESTED ✓'}
              </span>
            </div>
          </div>

          <div className="md:col-span-4 bg-slate-950/85 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <div>
                <div className="text-[10px] font-mono text-slate-400 uppercase">Call Stack Depth</div>
                <div className="text-xs font-mono font-bold text-purple-300">
                  {harvestedValues.length < expectedSequence.length
                    ? `Level ${Math.min(3, Math.floor(harvestedValues.length / 2))}`
                    : 'Stack Unwound (Complete)'}
                </div>
              </div>
            </div>
            <button
              onClick={() => {
                playButtonClick();
                setShowCodeDrawer(!showCodeDrawer);
              }}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-mono text-slate-300 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Spec</span>
              {showCodeDrawer ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          </div>
        </div>

        {/* Collapsible Formal Code Drawer for MCA Viva */}
        {showCodeDrawer && (
          <div className="mb-3 p-3 bg-slate-950 border border-purple-500/30 rounded-xl transition-all">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <span className="text-[11px] font-mono font-bold text-slate-300 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-purple-400" />
                Algorithm Implementation (MCA Theoretical Reference)
              </span>
              <div className="flex gap-1">
                <button
                  onClick={() => setActiveCodeTab('python')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                    activeCodeTab === 'python'
                      ? 'bg-purple-600 text-white font-bold'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  Python
                </button>
                <button
                  onClick={() => setActiveCodeTab('ts')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer ${
                    activeCodeTab === 'ts'
                      ? 'bg-purple-600 text-white font-bold'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  TypeScript
                </button>
              </div>
            </div>
            <pre className="text-[11px] font-mono text-purple-200 leading-relaxed overflow-x-auto p-2 bg-slate-900/90 rounded border border-slate-800">
              {(activeCodeTab === 'python' ? cfg.pyCode : cfg.tsCode).join('\n')}
            </pre>
          </div>
        )}

        {/* Traversal Output Pipeline / Sequence Ribbon */}
        <div className="bg-slate-950/85 p-3 rounded-xl border border-slate-800 mb-3">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2">
            <span>TRAVERSAL OUTPUT ARRAY [0..{expectedSequence.length - 1}]:</span>
            <span className="text-[10px] text-slate-500">
              Tap any node below or on the tree canvas to harvest
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {expectedSequence.map((val, idx) => {
              const isCleared = harvestedValues.includes(val);
              const isCurrent = val === nextTargetVal;

              return (
                <div key={idx} className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      playButtonClick();
                      if (onNodeClick) onNodeClick(val);
                    }}
                    className={`px-3 py-1.5 rounded-lg border font-mono text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      isCleared
                        ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300 shadow-sm'
                        : isCurrent
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-yellow-400 shadow-lg scale-105 ring-2 ring-yellow-400/60 animate-pulse'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-purple-500/50 hover:text-white'
                    }`}
                  >
                    {isCleared && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    <span className="text-[10px] text-slate-400">#{idx}:</span>
                    <span>{val}</span>
                  </button>
                  {idx < expectedSequence.length - 1 && (
                    <span className="text-slate-600 font-mono text-xs font-bold">→</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-purple-400" />
            <span>Climber advances along tree branches automatically as you collect.</span>
          </div>

          <button
            onClick={() => {
              playButtonClick();
              if (onTriggerGhostPath) onTriggerGhostPath();
            }}
            className="px-4 py-2 bg-gradient-to-r from-yellow-500/20 to-purple-500/20 hover:from-yellow-500/30 hover:to-purple-500/30 border border-yellow-500/50 hover:border-yellow-400 text-yellow-300 font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span>Replay Ghost Path Hint</span>
          </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // LEVEL 4: BST INSERTION ENGINE
  // ==========================================
  if (isInsertion) {
    const fruitVal = incomingFruit !== undefined ? incomingFruit : 25;
    const isSmaller = fruitVal < currentNodeVal;
    const correctDir = isSmaller ? 'LEFT' : 'RIGHT';

    return (
      <div className="p-3 sm:p-4 bg-slate-900/95 border border-emerald-500/40 rounded-2xl shadow-2xl backdrop-blur-md">
        {/* Top Info Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-3 border-b border-emerald-500/20 text-xs">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-emerald-400 font-black tracking-wide">BST INSERTION ENGINE</span>
            <span className="text-slate-500 hidden sm:inline">|</span>
            <span className="text-slate-300 font-mono text-[11px] hidden sm:inline">
              Left Subtree &lt; Node &lt; Right Subtree
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-[10px] font-mono text-emerald-300">
              Avg Time: O(log N)
            </span>
            <span className="px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-300">
              Aux Space: O(1)
            </span>
            <div className="font-mono text-slate-300 text-xs pl-1">
              Planted Fruits:{' '}
              <span className="text-emerald-400 font-bold">
                {currentCount}/{targetCount}
              </span>
            </div>
          </div>
        </div>

        {/* BST Comparison Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-3">
          {/* Incoming Fruit Card */}
          <div className="md:col-span-4 bg-slate-950/90 p-3 rounded-xl border border-emerald-500/30 text-center flex flex-col justify-center shadow-inner">
            <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider font-bold mb-1">
              Incoming Key To Plant
            </div>
            <div className="text-3xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
              {fruitVal}
            </div>
            <div className="text-[10px] font-mono text-slate-400 mt-1">
              Search Slot: Root (50) → ...
            </div>
          </div>

          {/* Decision Comparator Card */}
          <div className="md:col-span-8 bg-slate-950/90 p-3 rounded-xl border border-slate-800 flex flex-col justify-center">
            <div className="flex items-center justify-between text-xs font-mono text-slate-300 mb-1.5">
              <span>
                Current Branch Node: <strong className="text-purple-300 text-sm">[{currentNodeVal}]</strong>
              </span>
              <span className="text-[10px] text-slate-400">
                Rule: {fruitVal} {isSmaller ? '<' : '>'} {currentNodeVal}
              </span>
            </div>

            <div className="p-2 bg-slate-900/90 rounded-lg border border-slate-800 text-xs font-mono">
              <span className="text-slate-400">Invariant Evaluation: </span>
              <span className="text-yellow-300 font-bold">
                {fruitVal} is {isSmaller ? 'SMALLER (<)' : 'LARGER (>)'} than {currentNodeVal}
              </span>
              <div className="mt-1 text-[11px] text-slate-300">
                Correct Decision:{' '}
                <span className="text-emerald-400 font-bold underline">
                  Branch {correctDir}
                </span>{' '}
                {isSmaller ? '(recurse left subtree)' : '(recurse right subtree)'}
              </div>
            </div>
          </div>
        </div>

        {/* Big Interactive Decision Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => {
              playButtonClick();
              if (onNavigateChoice) onNavigateChoice('left');
            }}
            className={`py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer active:scale-95 border ${
              isSmaller
                ? 'bg-gradient-to-r from-cyan-900/80 to-blue-900/80 hover:from-cyan-800 hover:to-blue-800 border-cyan-400 text-cyan-200 ring-2 ring-cyan-400/40 animate-pulse'
                : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            <ArrowLeft className="w-5 h-5 text-cyan-400" />
            <div className="text-left font-mono">
              <div>&lt; GO LEFT</div>
              <div className="text-[10px] font-normal text-cyan-300">Key is Smaller (&lt;)</div>
            </div>
          </button>

          <button
            onClick={() => {
              playButtonClick();
              if (onNavigateChoice) onNavigateChoice('right');
            }}
            className={`py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer active:scale-95 border ${
              !isSmaller
                ? 'bg-gradient-to-r from-purple-900/80 to-pink-900/80 hover:from-purple-800 hover:to-pink-800 border-purple-400 text-purple-200 ring-2 ring-purple-400/40 animate-pulse'
                : 'bg-slate-800/90 hover:bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            <div className="text-right font-mono">
              <div>GO RIGHT &gt;</div>
              <div className="text-[10px] font-normal text-purple-300">Key is Larger (&gt;)</div>
            </div>
            <ArrowRight className="w-5 h-5 text-purple-400" />
          </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // LEVEL 5: BST SEARCH & TREE HEIGHT
  // ==========================================
  if (isSearchAndHeight) {
    if (searchPhase === 'search') {
      const isMatch = currentNodeVal === searchTarget;

      return (
        <div className="p-3 sm:p-4 bg-slate-900/95 border border-cyan-500/40 rounded-2xl shadow-2xl backdrop-blur-md">
          {/* Top Info Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-3 border-b border-cyan-500/20 text-xs">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="text-cyan-400 font-black tracking-wide">
                PHASE 1: LOGARITHMIC SEARCH O(log N)
              </span>
              <span className="text-slate-500 hidden sm:inline">|</span>
              <span className="text-slate-300 font-mono text-[11px] hidden sm:inline">
                Binary Elimination at Each Node
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-[10px] font-mono text-cyan-300">
                Efficiency: Halves search space
              </span>
              <div className="font-mono text-slate-300 text-xs pl-1">
                Progress:{' '}
                <span className="text-cyan-300 font-bold">
                  {currentCount}/{targetCount}
                </span>
              </div>
            </div>
          </div>

          {/* Search Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 mb-3">
            <div className="md:col-span-4 bg-slate-950/90 p-3 rounded-xl border border-cyan-500/30 text-center flex flex-col justify-center shadow-inner">
              <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold mb-1">
                Target Key To Find
              </div>
              <div className="text-3xl font-mono font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-300">
                {searchTarget}
              </div>
            </div>

            <div className="md:col-span-8 bg-slate-950/90 p-3 rounded-xl border border-slate-800 flex flex-col justify-center">
              <div className="text-xs font-mono text-slate-300">
                Current Climber Location: <span className="text-purple-300 font-bold text-sm">[{currentNodeVal}]</span>
              </div>
              <div className="mt-1.5 p-2 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
                {isMatch ? (
                  <span className="text-emerald-400 font-bold font-mono flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ★ TARGET MATCHED! Tap &quot;CONFIRM FOUND&quot; below to record search!
                  </span>
                ) : searchTarget < currentNodeVal ? (
                  <span className="font-mono text-slate-300">
                    Target <strong className="text-cyan-300">{searchTarget}</strong> &lt; Current{' '}
                    <strong className="text-purple-300">{currentNodeVal}</strong> →{' '}
                    <strong className="text-cyan-400 underline">Recurse Left Subtree</strong>
                  </span>
                ) : (
                  <span className="font-mono text-slate-300">
                    Target <strong className="text-purple-300">{searchTarget}</strong> &gt; Current{' '}
                    <strong className="text-purple-300">{currentNodeVal}</strong> →{' '}
                    <strong className="text-purple-400 underline">Recurse Right Subtree</strong>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-2.5">
            <button
              onClick={() => {
                playButtonClick();
                if (onNavigateChoice) onNavigateChoice('left');
              }}
              className="py-3 px-3 bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 hover:border-cyan-400 rounded-xl font-bold text-xs text-cyan-300 flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer font-mono"
            >
              <ArrowLeft className="w-4 h-4 text-cyan-400" />
              <span>&lt; Go Left</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                if (onConfirmTargetFound) onConfirmTargetFound();
              }}
              className={`py-3 px-3 rounded-xl font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer font-mono ${
                isMatch
                  ? 'bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white ring-2 ring-emerald-400/70 animate-pulse'
                  : 'bg-slate-800/80 text-slate-400 border border-slate-700 hover:border-slate-600'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>★ Confirm Found!</span>
            </button>

            <button
              onClick={() => {
                playButtonClick();
                if (onNavigateChoice) onNavigateChoice('right');
              }}
              className="py-3 px-3 bg-slate-800 hover:bg-slate-700 active:scale-95 border border-slate-700 hover:border-purple-400 rounded-xl font-bold text-xs text-purple-300 flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer font-mono"
            >
              <span>Go Right &gt;</span>
              <ArrowRight className="w-4 h-4 text-purple-400" />
            </button>
          </div>
        </div>
      );
    }

    // Height Phase
    return (
      <div className="p-3 sm:p-4 bg-slate-900/95 border border-yellow-500/40 rounded-2xl shadow-2xl backdrop-blur-md">
        {/* Top Info Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-3 border-b border-yellow-500/20 text-xs">
          <div className="flex items-center gap-2">
            <Ruler className="w-4 h-4 text-yellow-400 animate-pulse" />
            <span className="text-yellow-400 font-black tracking-wide">
              PHASE 2: TREE HEIGHT / MAX DEPTH CHALLENGE
            </span>
            <span className="text-slate-500 hidden sm:inline">|</span>
            <span className="text-slate-300 font-mono text-[11px] hidden sm:inline">
              Longest Path from Root to Deepest Leaf
            </span>
          </div>
          <div className="font-mono text-slate-300">
            Step: <span className="text-yellow-300 font-bold">3/3 (Final Summit)</span>
          </div>
        </div>

        <div className="bg-slate-950/90 p-3 rounded-xl border border-slate-800 mb-3">
          <div className="text-xs text-slate-200 mb-1 font-semibold">
            Mathematical Definition:{' '}
            <span className="text-yellow-300 font-mono font-normal">
              Height = Maximum number of edge transitions from Root (depth 0) to any Leaf.
            </span>
          </div>
          <div className="p-2 bg-slate-900/90 rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            Critical Path to Deepest Leaf:
            <span className="text-cyan-300 font-bold"> 50 (Root, depth 0)</span> →{' '}
            <span className="text-purple-300">75 (depth 1)</span> →{' '}
            <span className="text-purple-300">85 (depth 2)</span> →{' '}
            <span className="text-emerald-400 font-bold">95 (Deepest Leaf, depth 3)</span>
          </div>
        </div>

        {/* Option Buttons */}
        <div className="grid grid-cols-4 gap-2.5">
          {[1, 2, 3, 4].map((h) => (
            <button
              key={h}
              onClick={() => {
                playButtonClick();
                if (onSubmitTreeHeight) onSubmitTreeHeight(h);
              }}
              className="py-3 bg-slate-800 hover:bg-yellow-500/20 active:scale-95 border border-slate-700 hover:border-yellow-400 rounded-xl font-mono font-bold text-sm text-yellow-300 flex flex-col items-center justify-center shadow-lg transition-all cursor-pointer"
            >
              <span>Height = {h}</span>
              <span className="text-[10px] text-slate-400 font-normal">
                {h === 3 ? '(3 edges)' : `${h} edges`}
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return null;
};
