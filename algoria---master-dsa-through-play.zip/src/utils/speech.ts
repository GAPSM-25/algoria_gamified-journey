/**
 * Nova Voice Engine
 * Uses the Web Speech API (speechSynthesis) to give Nova an authentic voice.
 * Selects the best English voice with customized robotic pitch and friendly pace.
 */

import { getMuted } from './audio.ts';

let currentUtterance: SpeechSynthesisUtterance | null = null;
let activeEndCallback: (() => void) | null = null;

export function isSpeechSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
}

/**
 * Find the optimal voice for Nova (female / assistant / friendly English voice)
 */
function getNovaVoice(): SpeechSynthesisVoice | null {
  if (!isSpeechSupported()) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return null;

  // Preferred friendly female / assistant voices
  const preferredNames = [
    'Google US English',
    'Samantha',
    'Victoria',
    'Karen',
    'Zira',
    'Moira',
    'Tessa',
    'Fiona',
    'Microsoft Zira',
    'en-US-Neural2-F'
  ];

  for (const name of preferredNames) {
    const match = voices.find((v) => v.name.toLowerCase().includes(name.toLowerCase()));
    if (match) return match;
  }

  // Fallback to any English female voice or en-US voice
  const enUsVoice = voices.find((v) => v.lang.startsWith('en-US') || v.lang.startsWith('en_US'));
  if (enUsVoice) return enUsVoice;

  const anyEnVoice = voices.find((v) => v.lang.startsWith('en'));
  if (anyEnVoice) return anyEnVoice;

  return voices[0] || null;
}

/**
 * Speak text with Nova's customized voice.
 * Cleans up markdown or code symbols for natural speech pronunciation.
 */
export function speakNova(
  text: string,
  options?: {
    rate?: number;
    pitch?: number;
    onStart?: () => void;
    onEnd?: () => void;
    onError?: () => void;
  }
): () => void {
  if (!isSpeechSupported() || getMuted()) {
    options?.onEnd?.();
    return () => {};
  }

  // Cancel any ongoing speech
  stopNovaSpeech();

  // Sanitize text for clean spoken pronunciation
  const cleanText = text
    .replace(/arr\[([a-zA-Z0-9_+\- ]+)\]/g, 'array element at index $1')
    .replace(/O\(([^)]+)\)/g, 'Big O of $1')
    .replace(/O\(N\^2\)/gi, 'Big O of N squared')
    .replace(/O\(log N\)/gi, 'Big O of log N')
    .replace(/O\(1\)/gi, 'Big O of 1')
    .replace(/O\(N\)/gi, 'Big O of N')
    .replace(/```[\s\S]*?```/g, '') // remove large code blocks
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*_#~]/g, '')
    .replace(/->/g, 'yields')
    .replace(/<=/g, 'less than or equal to')
    .replace(/>=/g, 'greater than or equal to')
    .replace(/==/g, 'equals')
    .replace(/!=/g, 'does not equal')
    .trim();

  if (!cleanText) {
    options?.onEnd?.();
    return () => {};
  }

  try {
    const utterance = new SpeechSynthesisUtterance(cleanText);
    currentUtterance = utterance;

    const voice = getNovaVoice();
    if (voice) {
      utterance.voice = voice;
    }

    // Nova's personality: slightly higher pitch for cheerful, crisp robotic feel
    utterance.pitch = options?.pitch ?? 1.15;
    utterance.rate = options?.rate ?? 1.05;
    utterance.volume = 1.0;

    activeEndCallback = () => {
      currentUtterance = null;
      activeEndCallback = null;
      options?.onEnd?.();
    };

    utterance.onstart = () => {
      options?.onStart?.();
    };

    utterance.onend = () => {
      if (activeEndCallback) {
        activeEndCallback();
      }
    };

    utterance.onerror = () => {
      currentUtterance = null;
      activeEndCallback = null;
      options?.onError?.();
    };

    // Ensure voices are loaded in Chrome/Safari
    if (window.speechSynthesis.getVoices().length === 0) {
      window.speechSynthesis.onvoiceschanged = () => {
        const updatedVoice = getNovaVoice();
        if (updatedVoice) utterance.voice = updatedVoice;
        window.speechSynthesis.speak(utterance);
      };
    } else {
      window.speechSynthesis.speak(utterance);
    }
  } catch (err) {
    console.warn('Speech synthesis error:', err);
    options?.onError?.();
  }

  return stopNovaSpeech;
}

/**
 * Stop any active Nova speech immediately
 */
export function stopNovaSpeech() {
  if (isSpeechSupported()) {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  }
  if (activeEndCallback) {
    activeEndCallback();
    activeEndCallback = null;
  }
  currentUtterance = null;
}

/**
 * Check if Nova is currently speaking
 */
export function isNovaSpeaking(): boolean {
  if (!isSpeechSupported()) return false;
  return window.speechSynthesis.speaking;
}
