/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { getCurrentUser, logout, loginAsGuest } from './api/gameApi.js';
import { getMuted, toggleMute } from './utils/audio.ts';
import { HomeScreen } from './screens/HomeScreen.tsx';
import { AuthScreen } from './screens/AuthScreen.tsx';
import { CharacterSelectScreen } from './screens/CharacterSelectScreen.tsx';
import { RealmSelectScreen } from './screens/RealmSelectScreen.tsx';
import { WorldMapScreen } from './screens/WorldMapScreen.tsx';
import { ObjectKingdomScreen } from './screens/ObjectKingdomScreen.tsx';
import { GameScreen } from './screens/GameScreen.tsx';
import { AdminScreen } from './screens/AdminScreen.tsx';
import { LeaderboardModal } from './components/LeaderboardModal.tsx';

type ScreenState =
  | 'HOME'
  | 'AUTH'
  | 'CHARACTER_SELECT'
  | 'REALM_SELECT'
  | 'WORLD_MAP'
  | 'OBJECT_KINGDOM'
  | 'GAME'
  | 'ADMIN';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenState>('HOME');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeWorldId, setActiveWorldId] = useState<string>('loop_forest');
  const [activeLevelId, setActiveLevelId] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);

  // Initialize user session & mute state on mount
  useEffect(() => {
    setIsMuted(getMuted());

    const handleHash = () => {
      if (typeof window !== 'undefined' && window.location.hash.includes('admin')) {
        setCurrentScreen('ADMIN');
      }
    };

    // Check if URL specifies admin mode
    if (typeof window !== 'undefined') {
      const p = window.location.pathname;
      const h = window.location.hash;
      const s = window.location.search;
      if (p.includes('/admin') || h.includes('admin') || s.includes('admin')) {
        setCurrentScreen('ADMIN');
      }
      window.addEventListener('hashchange', handleHash);
    }

    const initSession = async () => {
      try {
        const user = await getCurrentUser();
        if (user) {
          setCurrentUser(user);
        }
      } catch (e) {
        console.error('Session init error', e);
      } finally {
        setIsLoading(false);
      }
    };
    initSession();

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('hashchange', handleHash);
      }
    };
  }, []);

  const handleToggleMute = () => {
    const nextMuted = toggleMute();
    setIsMuted(nextMuted);
  };

  const handleStartAdventure = async () => {
    if (currentUser) {
      if (!currentUser.progress?.characterId) {
        setCurrentScreen('CHARACTER_SELECT');
      } else {
        setCurrentScreen('REALM_SELECT');
      }
    } else {
      try {
        const guest = await loginAsGuest();
        setCurrentUser(guest);
        setCurrentScreen('CHARACTER_SELECT');
      } catch (e) {
        console.error('Adventure start error', e);
        setCurrentScreen('CHARACTER_SELECT');
      }
    }
  };

  const handlePickAvatarFromHome = async (charId: string) => {
    if (currentUser?.username) {
      handleCharacterConfirmed(charId);
    } else {
      try {
        const guest = await loginAsGuest();
        if (guest) {
          guest.progress = { ...guest.progress, characterId: charId };
          setCurrentUser(guest);
        }
        setCurrentScreen('REALM_SELECT');
      } catch (e) {
        console.error('Avatar selection error', e);
        setCurrentScreen('REALM_SELECT');
      }
    }
  };

  const handleAuthSuccess = (user: any) => {
    setCurrentUser(user);
    if (!user.progress?.characterId) {
      setCurrentScreen('CHARACTER_SELECT');
    } else {
      setCurrentScreen('REALM_SELECT');
    }
  };

  const handleCharacterConfirmed = (charId: string) => {
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        progress: {
          ...currentUser.progress,
          characterId: charId
        }
      });
    }
    // As requested: After avatar selection, give the user the choice between World Map and Object Kingdom!
    setCurrentScreen('REALM_SELECT');
  };

  const handleSelectLevel = (worldId: string, levelId: number) => {
    if (worldId === 'object_kingdom') {
      setCurrentScreen('WORLD_MAP');
      return;
    }
    setActiveWorldId(worldId);
    setActiveLevelId(levelId);
    setCurrentScreen('GAME');
  };

  const handleLogout = async () => {
    await logout();
    setCurrentUser(null);
    setCurrentScreen('HOME');
  };

  const handleGuestPlayDirect = async () => {
    try {
      const guest = await loginAsGuest();
      setCurrentUser(guest);
      setCurrentScreen('CHARACTER_SELECT');
    } catch (e) {
      console.error('Guest play error', e);
      setCurrentScreen('CHARACTER_SELECT');
    }
  };

  const handleGoHome = () => {
    setCurrentScreen('HOME');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-[#0b071a] text-cyan-400 font-mono text-sm">
        Initializing Algoria Engine...
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-[#0b071a] font-sans antialiased selection:bg-cyan-500 selection:text-slate-950">
      {currentScreen === 'HOME' && (
        <HomeScreen
          onStartAdventure={handleStartAdventure}
          onOpenAuth={() => setCurrentScreen('AUTH')}
          onPlayAsGuest={handleGuestPlayDirect}
          onOpenCharacterSelect={() => setCurrentScreen('CHARACTER_SELECT')}
          onSelectAvatar={handlePickAvatarFromHome}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          onOpenLearningPaths={() => setCurrentScreen('REALM_SELECT')}
          onSelectMode={(worldId) => handleSelectLevel(worldId, 1)}
          onOpenAdmin={() => setCurrentScreen('ADMIN')}
          onLogout={handleLogout}
          currentUser={currentUser}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {currentScreen === 'AUTH' && (
        <AuthScreen
          onSuccess={handleAuthSuccess}
          onBack={() => setCurrentScreen('HOME')}
        />
      )}

      {currentScreen === 'CHARACTER_SELECT' && (
        <CharacterSelectScreen
          currentUser={currentUser}
          onCharacterConfirmed={handleCharacterConfirmed}
          onBack={() => setCurrentScreen('REALM_SELECT')}
          onGoHome={handleGoHome}
        />
      )}

      {currentScreen === 'REALM_SELECT' && (
        <RealmSelectScreen
          currentUser={currentUser}
          onSelectRealm={(realm) => setCurrentScreen(realm)}
          onChangeAvatar={() => setCurrentScreen('CHARACTER_SELECT')}
          onGoHome={handleGoHome}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {currentScreen === 'WORLD_MAP' && (
        <WorldMapScreen
          currentUser={currentUser}
          onSelectLevel={handleSelectLevel}
          onChangeCharacter={() => setCurrentScreen('CHARACTER_SELECT')}
          onLogout={handleLogout}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onOpenAdmin={() => setCurrentScreen('ADMIN')}
          onUserDataUpdated={(updatedUser) => setCurrentUser(updatedUser)}
          onOpenObjectKingdom={() => setCurrentScreen('OBJECT_KINGDOM')}
          onOpenRealmSelect={() => setCurrentScreen('REALM_SELECT')}
          onGoHome={handleGoHome}
        />
      )}

      {currentScreen === 'OBJECT_KINGDOM' && (
        <ObjectKingdomScreen
          currentUser={currentUser}
          onSelectLevel={handleSelectLevel}
          onBackToRealmSelect={() => setCurrentScreen('REALM_SELECT')}
          onSwitchToWorldMap={() => setCurrentScreen('WORLD_MAP')}
          onChangeCharacter={() => setCurrentScreen('CHARACTER_SELECT')}
          onLogout={handleLogout}
          onGoHome={handleGoHome}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {currentScreen === 'GAME' && (
        <GameScreen
          worldId={activeWorldId}
          levelId={activeLevelId}
          currentUser={currentUser}
          onExitToMap={() => {
            if (activeWorldId === 'object_kingdom') {
              setCurrentScreen('OBJECT_KINGDOM');
            } else {
              setCurrentScreen('WORLD_MAP');
            }
          }}
          onGoHome={handleGoHome}
          onNextLevel={(nextWorldId, nextId) => {
            setActiveWorldId(nextWorldId);
            setActiveLevelId(nextId);
          }}
          onUserDataUpdated={(updatedUser) => setCurrentUser(updatedUser)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {currentScreen === 'ADMIN' && (
        <AdminScreen
          currentUser={currentUser}
          onExit={() => setCurrentScreen('WORLD_MAP')}
          onGoHome={handleGoHome}
          onUserDataUpdated={(updatedUser) => setCurrentUser(updatedUser)}
        />
      )}

      {/* Global Leaderboard Modal accessible from Home and Navigation */}
      <LeaderboardModal
        isOpen={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
        currentUser={currentUser}
      />
    </div>
  );
}
